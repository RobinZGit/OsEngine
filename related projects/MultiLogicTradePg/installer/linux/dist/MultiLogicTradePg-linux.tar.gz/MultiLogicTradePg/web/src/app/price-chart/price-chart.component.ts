import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ChartEquityPoint,
  ChartIndicatorSeries,
  ChartShadedRange,
  ChartStopMarker,
  ChartTradeMarker,
  ChartVisibleRange,
  PriceCandle,
} from '../models/market.model';
import { TechLogService } from '../services/tech-log.service';

@Component({
  selector: 'app-price-chart',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './price-chart.component.html',
  styleUrl: './price-chart.component.css',
})
export class PriceChartComponent implements AfterViewInit, OnChanges, OnDestroy {
  @ViewChild('canvas') canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('chartBody') chartBodyRef!: ElementRef<HTMLDivElement>;

  @Input() candles: PriceCandle[] = [];
  @Input() indicatorSeries: ChartIndicatorSeries[] = [];
  /** Маркеры входов/выходов (бэктест). */
  @Input() tradeMarkers: ChartTradeMarker[] = [];
  /** Линии стоп-лосс / тейк-профит с подписью типа. */
  @Input() stopMarkers: ChartStopMarker[] = [];
  /** Периоды отключения бумаги (blur/shade). */
  @Input() shadedRanges: ChartShadedRange[] = [];
  /** Кумулятивный PnL по бумаге (отдельная панель под ценой). */
  @Input() equityPoints: ChartEquityPoint[] = [];
  /**
   * Прокрутить окно так, чтобы эта дата была видна.
   * Нужно для бэктеста: сделки часто не в последних 200 свечах.
   */
  @Input() focusDt: string | null = null;
  /**
   * Положение focusDt в видимом окне:
   * start ≈ 20% слева (начало сделок/теста), end ≈ 65% (как раньше).
   */
  @Input() focusAlign: 'start' | 'end' = 'end';
  @Input() loading = false;
  /** Фоновая подгрузка истории — не блокирует перемотку. */
  @Input() loadingOlder = false;
  @Input() error: string | null = null;
  @Input() title = '';
  /** Кнопка ↻ пересчёта индикаторов (на графиках бумаг теста не нужна). */
  @Input() showRecalcButton = true;
  /** Для app_tech_log (sec:N). */
  @Input() securityId: number | null = null;
  /**
   * Компактный режим (терминал): узкая панель кнопок (только «полный экран»),
   * маленькие поля и подписи, без легенды/футера. Полноэкранный режим всегда полный.
   */
  @Input() compact = false;

  /**
   * Терминал: после первой загрузки и после полной перезагрузки графика
   * показывать последнюю свечу (двигаться к концу истории), а не от самого начала.
   */
  /** ???????? ??????? ????? ????? ? ???????. */
  @Input() showToolbarCandleTime = false;
  @Input() followLast = false;

  /** Режим отображения цены: свечи или линия по Close (#835). */
  viewMode: 'candles' | 'line' = 'candles';
  /** Направление графика: false = новые справа, true = новые слева. */
  chartReversed = false;

  toggleChartDirection(event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.chartReversed === !this.chartReversed) return;
    this.chartReversed = !this.chartReversed;
    this.scheduleRedraw();
  }

  get toolbarCandleDt(): string | null {
    if (!this.showToolbarCandleTime || !this.candles?.length) return null;
    return this.candles[this.candles.length - 1]?.dt ?? null;
  }

  get toolbarCandleTimeLabel(): string {
    const dt = this.toolbarCandleDt;
    if (!dt) return '';
    const d = new Date(dt);
    if (Number.isNaN(d.getTime())) return String(dt);
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    const mo = String(d.getMonth() + 1).padStart(2, '0');
    return `${dd}.${mo} ${hh}:${mm}`;
  }

  get toolbarCandleTimeStyle(): { [k: string]: string } {
    const dt = this.toolbarCandleDt;
    if (!dt) return {};
    const d = new Date(dt);
    if (Number.isNaN(d.getTime())) return {};
    const h = d.getHours() + d.getMinutes() / 60 + d.getSeconds() / 3600;
    return this.candleTimeOfDayStyle(h);
  }

  private candleTimeOfDayStyle(hour: number): { [k: string]: string } {
    // 0..24, smooth keyframes: night dark blue -> dawn -> bright noon -> dusk -> night
    const keys: Array<[number, number, number, number]> = [
      [0, 15, 35, 71],      // 00:00 deep night
      [4, 22, 51, 95],      // 04:00 late night
      [5.5, 70, 110, 170],  // 05:30 dawn
      [7, 255, 214, 102],   // 07:00 morning yellow
      [12, 255, 247, 178],  // 12:00 brightest yellow-white
      [17, 255, 214, 102],  // 17:00 afternoon
      [19, 70, 110, 170],   // 19:00 dusk
      [21, 22, 51, 95],     // 21:00 evening
      [24, 15, 35, 71],     // 24:00 deep night
    ];
    const h = ((hour % 24) + 24) % 24;
    let a = keys[0], b = keys[keys.length - 1];
    for (let i = 0; i < keys.length - 1; i++) {
      if (h >= keys[i][0] && h <= keys[i + 1][0]) { a = keys[i]; b = keys[i + 1]; break; }
    }
    const span = b[0] - a[0] || 1;
    const t = Math.max(0, Math.min(1, (h - a[0]) / span));
    const s = t * t * (3 - 2 * t); // smoothstep
    const r = Math.round(a[1] + (b[1] - a[1]) * s);
    const g = Math.round(a[2] + (b[2] - a[2]) * s);
    const bl = Math.round(a[3] + (b[3] - a[3]) * s);
    const lum = (0.2126 * r + 0.7152 * g + 0.0722 * bl) / 255;
    const text = lum > 0.62 ? '#1e293b' : '#f8fafc';
    const border = lum > 0.62 ? 'rgba(15,23,42,.18)' : 'rgba(255,255,255,.22)';
    return {
      backgroundColor: `rgb(${r},${g},${bl})`,
      color: text,
      borderBottomColor: border,
    };
  }

  private xIndex(i: number, count: number): number {
    return this.chartReversed ? (count - 1 - i) : i;
  }

  setViewMode(mode: 'candles' | 'line', event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.viewMode === mode) return;
    this.viewMode = mode;
    this.scheduleRedraw();
  }

  private readonly techLog = inject(TechLogService);

  @Output() loadOlder = new EventEmitter<void>();
  @Output() visibleRangeChange = new EventEmitter<ChartVisibleRange>();
  @Output() recalcIndicators = new EventEmitter<ChartVisibleRange>();

  fullscreen = false;

  private viewStart = 0;
  private readonly baseCandleWidth = 7;
  private zoom = 1;

  private dragging = false;
  private dragStartX = 0;
  private dragStartView = 0;
  private resizeObserver: ResizeObserver | null = null;
  private prevCandlesLen = 0;
  private loadOlderPending = false;
  private emitRangeTimer: ReturnType<typeof setTimeout> | null = null;
  private redrawScheduled = false;
  private redrawRafId: number | null = null;
  private seriesPointIndex = new Map<ChartIndicatorSeries, Map<string, number>>();
  private panStartedAt = 0;

  private pinchActive = false;
  private pinchStartDist = 0;
  private pinchStartZoom = 1;
  /** Последний размер тела графика — чтобы ResizeObserver не крутил бесконечный redraw. */
  private lastBodyW = -1;
  private lastBodyH = -1;
  private ignoreResizeUntil = 0;
  private resizeDebounce: ReturnType<typeof setTimeout> | null = null;

  /** Масштаб подписей осей, легенды и даты в полноэкранном режиме */
  private get labelScale(): number {
    return this.fullscreen ? 1.55 : this.compact ? 0.85 : 1;
  }

  private chartPadding(): { top: number; right: number; bottom: number; left: number } {
    if (this.compact && !this.fullscreen) {
      return this.chartReversed
        ? { top: 4, right: 60, bottom: 16, left: 6 }
        : { top: 4, right: 6, bottom: 16, left: 60 };
    }
    const s = this.labelScale;
    const yAxis = Math.round(60 * s);
    return this.chartReversed
      ? { top: Math.round(28 * s), right: yAxis, bottom: Math.round(22 * s), left: 10 }
      : { top: Math.round(28 * s), right: 10, bottom: Math.round(22 * s), left: yAxis };
  }

  get hasTradeNav(): boolean {
    return this.tradeMarkers.length > 0;
  }

  /** Нормализация dt для сопоставления свечи и маркера. */
  private static dtKey(dt: string): string {
    return String(dt || '')
      .replace('T', ' ')
      .replace(/Z$/i, '')
      .replace(/\.\d+/, '')
      .slice(0, 19);
  }

  /** Epoch (мс) локальной «YYYY-MM-DD HH:MM:SS» — для доли бара (обе стороны в UTC). */
  private static dtToMs(key: string): number {
    const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/.exec(key);
    if (!m) return 0;
    return Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
  }

  /**
   * Доля времени сделки внутри бара (0..1) — маркер ставится «в своё время»,
   * а не в центр бара. За границами — clamp к краю.
   */
  private static fxInBar(dtKey: string, barStartKey: string, barEndKey: string): number {
    const a = PriceChartComponent.dtToMs(barStartKey);
    const b = PriceChartComponent.dtToMs(barEndKey);
    const span = b - a;
    if (!(span > 0)) return 0.5;
    const t = PriceChartComponent.dtToMs(dtKey);
    return Math.max(0, Math.min(1, (t - a) / span));
  }

  private px(base: number): number {
    return Math.round(base * this.labelScale);
  }

  ngAfterViewInit(): void {
    const body = this.chartBodyRef?.nativeElement;
    if (!body) return;
    this.resizeObserver = new ResizeObserver(() => {
      if (performance.now() < this.ignoreResizeUntil) return;
      const w = body.clientWidth;
      const h = body.clientHeight;
      if (w === this.lastBodyW && h === this.lastBodyH) return;
      if (this.resizeDebounce) clearTimeout(this.resizeDebounce);
      // Debounce: иначе flex/scrollbar даёт петлю resize→redraw→resize и блокирует UI.
      this.resizeDebounce = setTimeout(() => {
        this.resizeDebounce = null;
        this.scheduleRedraw();
      }, 80);
    });
    this.resizeObserver.observe(body);
    this.scheduleRedraw();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['indicatorSeries']) {
      this.rebuildSeriesPointIndex();
    }
    if (changes['candles']) {
      const added = this.candles.length - this.prevCandlesLen;
      if (this.followLast) {
        // followLast: всегда держим последнюю свечу в видимой области.
        this.viewStart = Math.max(0, this.candles.length - this.viewCount());
      } else if (added > 0 && this.prevCandlesLen > 0 && this.viewStart > 0) {
        this.viewStart += added;
      }
      this.prevCandlesLen = this.candles.length;
      this.loadOlderPending = false;
      this.clampViewStart();
      // visibleRange emit только по жесту пользователя — иначе лишние HTTP/CD.
    }
    if (
      (changes['focusDt'] || changes['candles']) &&
      this.focusDt &&
      this.candles.length > 0
    ) {
      this.scrollToFocusDt(this.focusDt);
    }
    // Poll родителя часто приносит новые ссылки на overlays — не redraw, если длина та же.
    const overlaysRefOnly =
      !changes['candles'] &&
      !changes['indicatorSeries'] &&
      !changes['loading'] &&
      !changes['loadingOlder'] &&
      !changes['error'] &&
      !changes['focusDt'] &&
      !changes['title'] &&
      this.overlayArraysSameLength(changes);
    if (overlaysRefOnly) {
      return;
    }
    const meaningful =
      changes['candles'] ||
      changes['indicatorSeries'] ||
      changes['loading'] ||
      changes['loadingOlder'] ||
      changes['error'] ||
      changes['tradeMarkers'] ||
      changes['stopMarkers'] ||
      changes['shadedRanges'] ||
      changes['equityPoints'] ||
      changes['focusDt'] ||
      changes['title'];
    if (meaningful) {
      queueMicrotask(() => this.scheduleRedraw());
      if (changes['candles'] && this.candles.length > 0) {
        requestAnimationFrame(() => {
          requestAnimationFrame(() => this.scheduleRedraw());
        });
      }
    }
  }

  private overlayArraysSameLength(changes: SimpleChanges): boolean {
    const keys = ['tradeMarkers', 'stopMarkers', 'shadedRanges', 'equityPoints'] as const;
    let saw = false;
    for (const k of keys) {
      const ch = changes[k];
      if (!ch || ch.firstChange) continue;
      saw = true;
      const prev = ch.previousValue as unknown[] | null | undefined;
      const cur = ch.currentValue as unknown[] | null | undefined;
      if ((prev?.length ?? -1) !== (cur?.length ?? -2)) return false;
    }
    return saw;
  }

  /** Сдвинуть окно так, чтобы dt была в нужной части видимой области. */
  private scrollToFocusDt(dt: string): void {
    const key = PriceChartComponent.dtKey(dt);
    let idx = -1;
    for (let i = 0; i < this.candles.length; i++) {
      if (PriceChartComponent.dtKey(this.candles[i].dt) <= key) idx = i;
      else break;
    }
    if (idx < 0) idx = 0;
    const count = this.viewCount();
    const maxStart = Math.max(0, this.candles.length - count);
    const bias = this.focusAlign === 'start' ? 0.2 : 0.65;
    this.viewStart = Math.max(0, Math.min(idx - Math.floor(count * bias), maxStart));
  }

  ngOnDestroy(): void {
    this.resizeObserver?.disconnect();
    if (this.resizeDebounce) {
      clearTimeout(this.resizeDebounce);
      this.resizeDebounce = null;
    }
    if (this.redrawRafId != null) {
      cancelAnimationFrame(this.redrawRafId);
    }
    if (this.emitRangeTimer) clearTimeout(this.emitRangeTimer);
    if (this.fullscreen) {
      document.body.style.overflow = '';
    }
  }

  @HostListener('document:keydown.escape')
  onEscape(): void {
    if (this.fullscreen) this.closeFullscreen();
  }

  get candleWidth(): number {
    return Math.min(24, Math.max(3, this.baseCandleWidth * this.zoom));
  }

  openFullscreen(): void {
    this.fullscreen = true;
    document.body.style.overflow = 'hidden';
    queueMicrotask(() => {
      this.clampViewStart();
      this.scheduleRedraw();
      requestAnimationFrame(() => this.scheduleEmitVisibleRange(false));
    });
  }

  closeFullscreen(): void {
    this.fullscreen = false;
    document.body.style.overflow = '';
    queueMicrotask(() => {
      this.clampViewStart();
      this.scheduleRedraw();
      requestAnimationFrame(() => this.scheduleEmitVisibleRange(false));
    });
  }

  onRecalcClick(event: Event): void {
    event.stopPropagation();
    this.recalcIndicators.emit({
      ...this.currentVisibleRange(),
      userInitiated: true,
    });
  }

  panLeft(event: Event): void {
    event.stopPropagation();
    const step = Math.max(5, Math.floor(this.viewCount() / 4));
    this.shiftView(this.chartReversed ? step : -step);
  }

  panRight(event: Event): void {
    event.stopPropagation();
    const step = Math.max(5, Math.floor(this.viewCount() / 4));
    this.shiftView(this.chartReversed ? -step : step);
  }

  /** Предыдущая сделка (open/close — одинаково). */
  gotoPrevTrade(event: Event): void {
    event.stopPropagation();
    const target = this.findTradeDt(-1);
    if (!target) return;
    this.scrollToFocusDt(target);
    this.scheduleRedraw();
    this.scheduleEmitVisibleRange(true);
  }

  /** Следующая сделка (open/close — одинаково). */
  gotoNextTrade(event: Event): void {
    event.stopPropagation();
    const target = this.findTradeDt(1);
    if (!target) return;
    this.scrollToFocusDt(target);
    this.scheduleRedraw();
    this.scheduleEmitVisibleRange(true);
  }

  /** Уникальные dt сделок по возрастанию. */
  private tradeNavDts(): string[] {
    const set = new Set<string>();
    for (const m of this.tradeMarkers) {
      const k = PriceChartComponent.dtKey(m.dt);
      if (k) set.add(k);
    }
    return [...set].sort();
  }

  /** direction -1 = назад, +1 = вперёд относительно центра видимого окна. */
  private findTradeDt(direction: -1 | 1): string | null {
    const dts = this.tradeNavDts();
    if (dts.length === 0 || this.candles.length === 0) return null;
    const count = this.viewCount();
    const visible = this.candles.slice(this.viewStart, this.viewStart + count);
    if (visible.length === 0) return null;
    const anchor = PriceChartComponent.dtKey(
      visible[Math.floor(visible.length * 0.65)].dt
    );
    if (direction < 0) {
      let prev: string | null = null;
      for (const d of dts) {
        if (d < anchor) prev = d;
        else break;
      }
      return prev;
    }
    for (const d of dts) {
      if (d > anchor) return d;
    }
    return null;
  }

  zoomIn(event: Event): void {
    event.stopPropagation();
    this.applyZoom(this.zoom * 1.2);
  }

  zoomOut(event: Event): void {
    event.stopPropagation();
    this.applyZoom(this.zoom / 1.2);
  }

  onWheel(event: WheelEvent): void {
    if (!this.canInteract()) return;
    event.preventDefault();
    const factor = event.deltaY < 0 ? 1.12 : 1 / 1.12;
    this.applyZoom(this.zoom * factor);
  }

  onPointerDown(event: PointerEvent): void {
    if (!this.canInteract()) return;
    if (this.pinchActive) return;

    this.dragging = true;
    this.panStartedAt = performance.now();
    this.dragStartX = event.clientX;
    this.dragStartView = this.viewStart;
    (event.target as HTMLElement).setPointerCapture(event.pointerId);
    this.logChartEvent('chart.pan.start', 'pointer down', {
      viewStart: this.viewStart,
      candles: this.candles.length,
    });
  }

  onPointerMove(event: PointerEvent): void {
    if (this.pinchActive) return;
    if (!this.dragging) return;

    const delta = event.clientX - this.dragStartX;
    const shift = Math.round(-delta / this.candleWidth);
    const maxStart = Math.max(0, this.candles.length - this.viewCount());
    this.viewStart = Math.min(maxStart, Math.max(0, this.dragStartView + shift));

    if (this.viewStart <= 8 && !this.loadOlderPending) {
      this.loadOlderPending = true;
      this.loadOlder.emit();
    }
    this.scheduleRedraw();
  }

  onPointerUp(event: PointerEvent): void {
    const moved = this.dragging && this.viewStart !== this.dragStartView;
    const panMs = this.panStartedAt > 0 ? Math.round(performance.now() - this.panStartedAt) : 0;
    this.dragging = false;
    try {
      (event.target as HTMLElement).releasePointerCapture(event.pointerId);
    } catch {
      /* ignore */
    }
    if (moved) {
      this.logChartEvent('chart.pan.end', `shift ${this.viewStart - this.dragStartView} bars`, {
        panMs,
        viewStart: this.viewStart,
        loadingOlder: this.loadingOlder,
      });
      this.scheduleEmitVisibleRange(true);
    } else if (this.panStartedAt > 0) {
      this.logChartEvent('chart.pan.cancel', 'no movement', { panMs });
    }
    this.panStartedAt = 0;
  }

  onPointerLeave(event: PointerEvent): void {
    if (!this.dragging) return;
    this.onPointerUp(event);
  }

  onTouchStart(event: TouchEvent): void {
    if (event.touches.length === 2) {
      this.pinchActive = true;
      this.dragging = false;
      this.pinchStartDist = this.touchDistance(event.touches);
      this.pinchStartZoom = this.zoom;
      event.preventDefault();
    }
  }

  onTouchMove(event: TouchEvent): void {
    if (!this.pinchActive || event.touches.length < 2) return;
    event.preventDefault();
    const dist = this.touchDistance(event.touches);
    if (this.pinchStartDist <= 0) return;
    const ratio = dist / this.pinchStartDist;
    this.applyZoom(this.pinchStartZoom * ratio, false);
  }

  onTouchEnd(event: TouchEvent): void {
    if (event.touches.length < 2) {
      this.pinchActive = false;
      this.scheduleEmitVisibleRange(true);
    }
  }

  private touchDistance(touches: TouchList): number {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.hypot(dx, dy);
  }

  private applyZoom(next: number, emit = true): void {
    const prev = this.zoom;
    this.zoom = Math.min(3.5, Math.max(0.45, next));
    if (Math.abs(this.zoom - prev) < 0.001) return;
    this.clampViewStart();
    this.scheduleRedraw();
    if (emit) this.scheduleEmitVisibleRange(true);
  }

  private shiftView(delta: number): void {
    const maxStart = Math.max(0, this.candles.length - this.viewCount());
    this.viewStart = Math.min(maxStart, Math.max(0, this.viewStart + delta));
    if (this.viewStart <= 8 && !this.loadOlderPending) {
      this.loadOlderPending = true;
      this.loadOlder.emit();
    }
    this.scheduleRedraw();
    this.scheduleEmitVisibleRange(true);
  }

  private canInteract(): boolean {
    return !this.loading && this.candles.length > 0;
  }

  private scheduleRedraw(): void {
    if (this.redrawScheduled) return;
    this.redrawScheduled = true;
    this.redrawRafId = requestAnimationFrame(() => {
      this.redrawScheduled = false;
      this.redrawRafId = null;
      this.redrawNow();
    });
  }

  private rebuildSeriesPointIndex(): void {
    this.seriesPointIndex.clear();
    for (const series of this.indicatorSeries) {
      const byDt = new Map<string, number>();
      for (const point of series.points) {
        // #836: ключ — момент времени (epoch ms). /api/prices отдаёт dt строкой
        // "YYYY-MM-DD HH:MM:SS", /api/indicator-values — ISO с UTC-сдвигом;
        // точное строковое сравнение не сходится никогда.
        const t = Date.parse(point.dt);
        byDt.set(Number.isFinite(t) ? `@${t}` : String(point.dt), point.value);
      }
      this.seriesPointIndex.set(series, byDt);
    }
  }

  private logChartEvent(
    operation: string,
    message: string,
    payload?: Record<string, unknown>
  ): void {
    if (!this.techLog.enabled || this.securityId == null) return;
    this.techLog.event(
      this.techLog.threadKey(this.securityId, null, 'chart'),
      operation,
      message,
      { securityId: this.securityId, payload }
    );
  }

  private clampViewStart(): void {
    const maxStart = Math.max(0, this.candles.length - this.viewCount());
    if (this.viewStart + this.viewCount() > this.candles.length) {
      this.viewStart = maxStart;
    }
    if (this.viewStart > maxStart) {
      this.viewStart = maxStart;
    }
  }

  private viewCount(): number {
    const body = this.chartBodyRef?.nativeElement;
    if (!body) return 60;
    const pad = this.chartPadding();
    const w = body.clientWidth || 400;
    return Math.max(10, Math.floor((w - pad.left - pad.right) / this.candleWidth));
  }

  currentVisibleRange(): ChartVisibleRange {
    const count = this.viewCount();
    const visible = this.candles.slice(this.viewStart, this.viewStart + count);
    if (visible.length === 0) {
      return { startDt: '', endDt: '', count: 0, viewStart: this.viewStart };
    }
    return {
      startDt: visible[0].dt,
      endDt: visible[visible.length - 1].dt,
      count: visible.length,
      viewStart: this.viewStart,
    };
  }

  private scheduleEmitVisibleRange(userInitiated = false): void {
    if (this.emitRangeTimer) clearTimeout(this.emitRangeTimer);
    this.emitRangeTimer = setTimeout(() => {
      const range = this.currentVisibleRange();
      if (range.count > 0) {
        this.visibleRangeChange.emit({ ...range, userInitiated });
      }
    }, 300);
  }

  private hasOscillatorPanel(): boolean {
    return this.indicatorSeries.some((s) => !s.on_price_scale);
  }

  /** Индикаторы на шкале цены, для которых нужна явная линия y=0 (вторая разность и т.п.). */
  private priceScaleAnchorsZero(): boolean {
    return this.indicatorSeries.some(
      (s) =>
        s.on_price_scale &&
        !s.is_threshold &&
        ['PACC', 'MOM', 'ROC'].includes(s.indicator_code)
    );
  }

  private drawReferenceLevel(
    ctx: CanvasRenderingContext2D,
    yScale: (v: number) => number,
    value: number,
    minV: number,
    maxV: number,
    left: number,
    right: number,
    label: string
  ): void {
    if (value < minV || value > maxV) return;
    const y = yScale(value);
    const axisSize = this.px(10);
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    ctx.setLineDash([]);
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(right, y);
    ctx.stroke();
    ctx.fillStyle = '#4b5563';
    ctx.font = `800 ${axisSize}px system-ui, sans-serif`;
    ctx.fillText(label, 4, y + Math.round(axisSize * 0.35));
  }

  private valueAtDt(series: ChartIndicatorSeries, dt: string): number | null {
    const byDt = this.seriesPointIndex.get(series);
    if (!byDt) return null;
    const t = Date.parse(dt);
    const value =
      byDt.get(Number.isFinite(t) ? `@${t}` : String(dt)) ??
      byDt.get(String(dt));
    return value != null ? value : null;
  }

  private redrawNow(): void {
    const t0 = performance.now();
    const canvas = this.canvasRef?.nativeElement;
    const body = this.chartBodyRef?.nativeElement;
    if (!canvas || !body) return;

    const cssW = body.clientWidth;
    const cssH = body.clientHeight;
    if (cssW <= 0 || cssH <= 0) return;

    // Пока меняем canvas — игнор ResizeObserver (иначе петля и зависание UI).
    this.ignoreResizeUntil = performance.now() + 120;
    this.lastBodyW = cssW;
    this.lastBodyH = cssH;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(cssW * dpr);
    canvas.height = Math.floor(cssH * dpr);
    canvas.style.width = `${cssW}px`;
    canvas.style.height = `${cssH}px`;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, cssW, cssH);

    const pad = this.chartPadding();
    const msgSize = this.px(13);

    if (this.error) {
      ctx.fillStyle = '#b45309';
      ctx.font = `${msgSize}px system-ui, sans-serif`;
      ctx.fillText(this.error, 12, pad.top + 8);
      return;
    }
    if (this.loading && this.candles.length === 0) {
      ctx.fillStyle = '#6b7280';
      ctx.font = `${msgSize}px system-ui, sans-serif`;
      ctx.fillText('Загрузка свечей…', 12, pad.top + 8);
      return;
    }
    if (this.candles.length === 0) {
      ctx.fillStyle = '#6b7280';
      ctx.font = `${msgSize}px system-ui, sans-serif`;
      ctx.fillText('Нет цен для выбранного таймфрейма', 12, pad.top + 8);
      return;
    }

    const cw = this.candleWidth;
    const count = this.viewCount();
    const visible = this.candles.slice(this.viewStart, this.viewStart + count);
    if (visible.length === 0) return;

    const offGroups: { key: string; series: ChartIndicatorSeries[] }[] = [];
    {
      const m = new Map<string, ChartIndicatorSeries[]>();
      for (const s of this.indicatorSeries) {
        if (s.on_price_scale) continue;
        const k = s.uid || s.indicator_code || s.line_code;
        if (!m.has(k)) m.set(k, []);
        m.get(k)!.push(s);
      }
      for (const [key, series] of m) offGroups.push({ key, series });
    }
    const showPnl = this.equityPoints.length > 0;
    const pnlRatio = showPnl ? (offGroups.length ? 0.18 : 0.26) : 0;
    const indRatio = offGroups.length > 0 ? 0.34 : 0;
    const usableBottom = cssH - pad.bottom;
    const priceTop = pad.top;
    const priceBottom = usableBottom - cssH * (indRatio + pnlRatio);
    const priceH = Math.max(this.px(80), priceBottom - priceTop);
    const indTop = priceTop + priceH + (offGroups.length ? 4 : 0);
    const indBottom = showPnl ? usableBottom - cssH * pnlRatio : usableBottom;
    const indTotalH = Math.max(0, indBottom - indTop);
    const paneGap = 3;
    const paneH = offGroups.length
      ? Math.max(this.px(28), Math.floor((indTotalH - paneGap * (offGroups.length - 1)) / offGroups.length))
      : 0;
    const pnlTop = showPnl
      ? (offGroups.length ? indTop + paneH * offGroups.length + paneGap * Math.max(0, offGroups.length - 1) + 4 : priceTop + priceH + 4)
      : usableBottom;
    const pnlBottom = usableBottom;
    const pnlH = Math.max(0, pnlBottom - pnlTop);

    let minP = Infinity;
    let maxP = -Infinity;
    for (const c of visible) {
      if (this.viewMode === 'line') {
        // Линейный режим строится по Close — шкала по нему же.
        const v = Number(c.close_price);
        if (Number.isFinite(v)) {
          minP = Math.min(minP, v);
          maxP = Math.max(maxP, v);
        }
        continue;
      }
      minP = Math.min(minP, Number(c.low_price));
      maxP = Math.max(maxP, Number(c.high_price));
    }

    const priceSeries = this.indicatorSeries.filter(
      (s) => s.on_price_scale && !s.is_threshold
    );
    for (const s of priceSeries) {
      for (const c of visible) {
        const v = this.valueAtDt(s, c.dt);
        if (v != null && Number.isFinite(v)) {
          minP = Math.min(minP, v);
          maxP = Math.max(maxP, v);
        }
      }
    }

    if (this.priceScaleAnchorsZero()) {
      minP = Math.min(minP, 0);
      maxP = Math.max(maxP, 0);
    }

    const pricePad = (maxP - minP) * 0.06 || maxP * 0.001 || 1;
    minP -= pricePad;
    maxP += pricePad;
    const yScale = (p: number) => priceTop + priceH - ((p - minP) / (maxP - minP)) * priceH;

    const axisSize = this.px(10);
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const p = minP + ((maxP - minP) * i) / 4;
      const y = yScale(p);
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(cssW - pad.right, y);
      ctx.stroke();
      ctx.fillStyle = '#0f172a';
      ctx.font = `900 ${this.px(11)}px system-ui, sans-serif`;
      if (this.chartReversed) {
        ctx.textAlign = 'left';
        ctx.fillText(p.toFixed(2), cssW - pad.right + 4, y + Math.round(axisSize * 0.35));
      } else {
        ctx.textAlign = 'right';
        ctx.fillText(p.toFixed(2), pad.left - 4, y + Math.round(axisSize * 0.35));
      }
      ctx.textAlign = 'left';
    }

    this.drawReferenceLevel(
      ctx,
      yScale,
      0,
      minP,
      maxP,
      pad.left,
      cssW - pad.right,
      '0'
    );

    this.drawShadedRanges(
      ctx,
      visible,
      pad.left,
      cssW - pad.right,
      priceTop,
      priceBottom,
      cw
    );

    if (this.viewMode === 'line') {
      // Линейный график цены: ломанная по Close каждой свечи (стандарт для
      // не-свечных графиков). Индикаторы/маркеры/зоны рисуются как обычно.
      ctx.strokeStyle = '#2563eb';
      ctx.lineWidth = Math.max(1.25, this.px(1.4));
      ctx.beginPath();
      visible.forEach((c, i) => {
        const x = pad.left + this.xIndex(i, visible.length) * cw + cw / 2;
        const y = yScale(Number(c.close_price));
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    } else {
      visible.forEach((c, i) => {
        const x = pad.left + this.xIndex(i, visible.length) * cw + cw / 2;
        const open = Number(c.open_price);
        const close = Number(c.close_price);
        const high = Number(c.high_price);
        const low = Number(c.low_price);
        const up = close >= open;
        ctx.strokeStyle = up ? '#16a34a' : '#dc2626';
        ctx.fillStyle = up ? '#16a34a' : '#dc2626';

        const yHigh = yScale(high);
        const yLow = yScale(low);
        ctx.beginPath();
        ctx.moveTo(x, yHigh);
        ctx.lineTo(x, yLow);
        ctx.stroke();

        const yOpen = yScale(open);
        const yClose = yScale(close);
        const top = Math.min(yOpen, yClose);
        const bodyH = Math.max(1, Math.abs(yClose - yOpen));
        ctx.fillRect(x - cw * 0.35, top, cw * 0.7, bodyH);
      });
    }

    for (const s of priceSeries) {
      this.drawLineSeries(ctx, visible, s, yScale, pad.left, cw);
    }

    this.drawStopMarkers(ctx, visible, yScale, pad.left, cw, priceTop, priceBottom);
    this.drawTradeMarkers(ctx, visible, yScale, pad.left, cw, priceTop, priceBottom);

    for (let gi = 0; gi < offGroups.length; gi++) {
      const g = offGroups[gi];
      const pTop = indTop + gi * (paneH + paneGap);
      const pBottom = pTop + paneH;
      if (paneH < this.px(20)) continue;

      ctx.fillStyle = '#fafafa';
      ctx.fillRect(pad.left, pTop, cssW - pad.left - pad.right, paneH);
      ctx.strokeStyle = '#e2e8f0';
      ctx.strokeRect(pad.left, pTop, cssW - pad.left - pad.right, paneH);

      let oMin = Infinity;
      let oMax = -Infinity;
      for (const s of g.series) {
        for (const c of visible) {
          const v = this.valueAtDt(s, c.dt);
          if (v != null && Number.isFinite(v)) {
            if (v < oMin) oMin = v;
            if (v > oMax) oMax = v;
          }
        }
      }
      if (!Number.isFinite(oMin) || !Number.isFinite(oMax)) { oMin = 0; oMax = 1; }
      if (oMin === oMax) { oMin -= 1; oMax += 1; }
      const oPad = (oMax - oMin) * 0.08 || 1;
      oMin -= oPad; oMax += oPad;
      const yOsc = (v: number) => pTop + paneH - ((v - oMin) / (oMax - oMin)) * paneH;

      ctx.strokeStyle = '#eef2f7';
      ctx.lineWidth = 1;
      for (let k = 0; k <= 2; k++) {
        const yy = pTop + (paneH * k) / 2;
        ctx.beginPath();
        ctx.moveTo(pad.left, yy);
        ctx.lineTo(cssW - pad.right, yy);
        ctx.stroke();
      }

      this.drawReferenceLevel(ctx, yOsc, 0, oMin, oMax, pad.left, cssW - pad.right, '0');

      const wm = g.series[0]?.description || g.series[0]?.shortLabel || g.series[0]?.indicator_code || g.series[0]?.line_name || '';
      if (wm) {
        ctx.save();
        ctx.fillStyle = 'rgba(71,85,105,0.24)';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const maxW = Math.max(40, cssW - pad.left - pad.right - 24);
        let fontSize = Math.max(this.px(18), Math.floor(paneH * 0.34));
        const lineHFactor = 1.25;
        const words = wm.split(/\s+/).filter(Boolean);
        const wrap = (fs: number): string[] => {
          ctx.font = `bold ${fs}px system-ui, sans-serif`;
          const lines: string[] = [];
          let line = '';
          for (const w of words) {
            const test = line ? line + ' ' + w : w;
            if (ctx.measureText(test).width <= maxW || !line) line = test;
            else { lines.push(line); line = w; }
          }
          if (line) lines.push(line);
          return lines;
        };
        let lines = wrap(fontSize);
        while (lines.length * fontSize * lineHFactor > paneH * 0.86 && fontSize > this.px(11)) {
          fontSize -= 1;
          lines = wrap(fontSize);
        }
        ctx.font = `bold ${fontSize}px system-ui, sans-serif`;
        const totalH = lines.length * fontSize * lineHFactor;
        let y = pTop + paneH / 2 - totalH / 2 + (fontSize * lineHFactor) / 2;
        const cx = pad.left + (cssW - pad.left - pad.right) / 2;
        for (const ln of lines) { ctx.fillText(ln, cx, y, maxW); y += fontSize * lineHFactor; }
        ctx.restore();
      }

      for (const s of g.series.filter((x) => x.is_threshold)) {
        this.drawThresholdLine(ctx, s, yOsc, pad.left, cssW - pad.right);
      }
      for (const s of g.series.filter((x) => !x.is_threshold)) {
        this.drawLineSeries(ctx, visible, s, yOsc, pad.left, cw);
      }

      ctx.fillStyle = '#0f172a';
      ctx.font = `900 ${this.px(10)}px system-ui, sans-serif`;
      ctx.textBaseline = 'alphabetic';
      if (this.chartReversed) {
        ctx.textAlign = 'right';
        ctx.fillText(oMax.toFixed(2), pad.left - 4, pTop + this.px(10));
        ctx.fillText(oMin.toFixed(2), pad.left - 4, pBottom - 3);
      } else {
        ctx.textAlign = 'left';
        ctx.fillText(oMax.toFixed(2), cssW - pad.right + 4, pTop + this.px(10));
        ctx.fillText(oMin.toFixed(2), cssW - pad.right + 4, pBottom - 3);
      }
      ctx.textAlign = 'left';

      let plx = pad.left + 4;
      const ply = pTop + this.px(10);
      for (const s of g.series) {
        ctx.fillStyle = s.color;
        ctx.fillRect(plx, ply - this.px(3), this.px(8), this.px(3));
        ctx.fillStyle = '#334155';
        ctx.font = `${this.px(9)}px system-ui, sans-serif`;
        ctx.fillText(s.line_name, plx + this.px(11), ply);
        plx += ctx.measureText(s.line_name).width + this.px(20);
        if (plx > cssW - pad.right - 30) break;
      }
    }

    if (showPnl && pnlH > 24) {
      this.drawEquityPanel(
        ctx,
        visible,
        pad.left,
        cssW - pad.right,
        pnlTop,
        pnlBottom,
        cw
      );
    }

    this.drawLegend(ctx, cssW, pad);

    const last = visible[visible.length - 1];
      ctx.fillStyle = '#111827';
      const footerSize = this.px(11);
      ctx.font = `800 ${footerSize}px system-ui, sans-serif`;
      const dtLabel = new Date(last.dt).toLocaleString('ru-RU', {
        dateStyle: 'short',
        timeStyle: 'short',
      });
      let footer = dtLabel;
      if (last.contract_prefix) {
        footer += ` · ${last.contract_prefix}`;
        if (last.group_prefix && last.group_prefix !== last.contract_prefix) {
          footer += ` (гр. ${last.group_prefix})`;
        }
      }
      ctx.fillText(footer, pad.left, cssH - Math.round(pad.bottom * 0.25));

    if (this.loading && this.candles.length === 0) {
      ctx.fillStyle = 'rgba(255,255,255,0.7)';
      ctx.fillRect(0, 0, cssW, cssH);
      ctx.fillStyle = '#374151';
      ctx.font = `${this.px(12)}px system-ui, sans-serif`;
      ctx.fillText('Загрузка свечей…', cssW / 2 - this.px(48), cssH / 2);
    } else if (this.loadingOlder) {
      ctx.fillStyle = 'rgba(255,255,255,0.55)';
      ctx.fillRect(0, 0, Math.min(120, cssW * 0.35), this.px(22));
      ctx.fillStyle = '#374151';
      ctx.font = `${this.px(10)}px system-ui, sans-serif`;
      ctx.fillText('История…', 8, this.px(14));
    }

    const drawMs = performance.now() - t0;
    if (drawMs > 32) {
      this.logChartEvent('chart.redraw.slow', `${Math.round(drawMs)}ms`, {
        drawMs: Math.round(drawMs),
        visible: visible.length,
        series: this.indicatorSeries.length,
        dragging: this.dragging,
      });
    }
  }

  /**
   * Индекс в полном this.candles.
   * Не искать только в visible: иначе сделки «правее» окна прилипают к последней свече кадра.
   */
  private indexInAllCandles(dt: string): number {
    if (this.candles.length === 0) return -1;
    const key = PriceChartComponent.dtKey(dt);
    for (let i = 0; i < this.candles.length; i++) {
      if (PriceChartComponent.dtKey(this.candles[i].dt) === key) return i;
    }
    let best = -1;
    for (let i = 0; i < this.candles.length; i++) {
      if (PriceChartComponent.dtKey(this.candles[i].dt) <= key) best = i;
      else break;
    }
    return best;
  }

  /**
   * Индекс внутри visible[] только если сделка реально в этом окне.
   * Вне окна → -1 (не рисовать на краю).
   */
  private indexInVisible(visible: PriceCandle[], dt: string): number {
    if (visible.length === 0) return -1;
    const fullIdx = this.indexInAllCandles(dt);
    if (fullIdx < 0) return -1;
    const first = this.viewStart;
    const last = this.viewStart + visible.length - 1;
    if (fullIdx < first || fullIdx > last) return -1;
    return fullIdx - this.viewStart;
  }

  /** Для shade: индекс в visible с clamp к краям окна (полоса может начинаться за кадром). */
  private indexForDt(visible: PriceCandle[], dt: string): number {
    if (visible.length === 0) return -1;
    const fullIdx = this.indexInAllCandles(dt);
    if (fullIdx < 0) {
      const key = PriceChartComponent.dtKey(dt);
      if (key < PriceChartComponent.dtKey(visible[0].dt)) return 0;
      return visible.length - 1;
    }
    const first = this.viewStart;
    const last = this.viewStart + visible.length - 1;
    if (fullIdx < first) return 0;
    if (fullIdx > last) return visible.length - 1;
    return fullIdx - this.viewStart;
  }

  private drawShadedRanges(
    ctx: CanvasRenderingContext2D,
    visible: PriceCandle[],
    left: number,
    right: number,
    top: number,
    bottom: number,
    candleWidth: number
  ): void {
    if (!this.shadedRanges.length || visible.length === 0) return;
    const firstKey = PriceChartComponent.dtKey(visible[0].dt);
    const lastKey = PriceChartComponent.dtKey(visible[visible.length - 1].dt);
    for (const range of this.shadedRanges) {
      const startKey = PriceChartComponent.dtKey(range.startDt);
      const endKey = PriceChartComponent.dtKey(range.endDt);
      if (endKey < firstKey || startKey > lastKey) continue;
      let i0 = this.indexForDt(visible, range.startDt);
      let i1 = this.indexForDt(visible, range.endDt);
      if (i0 < 0) i0 = 0;
      if (i1 < 0) i1 = visible.length - 1;
      if (i1 < i0) [i0, i1] = [i1, i0];
      const xi0 = this.xIndex(i0, visible.length);
      const xi1 = this.xIndex(i1, visible.length);
      const x0 = left + Math.min(xi0, xi1) * candleWidth;
      const x1 = left + (Math.max(xi0, xi1) + 1) * candleWidth;
      const kind = range.kind ?? 'normal';
      // Бледные зоны: green = обычная логика; gray = shadow; pink = инверсия.
      const fill =
        kind === 'inverted'
          ? 'rgba(251, 207, 232, 0.45)'
          : kind === 'shadow' || kind === 'paused'
            ? 'rgba(203, 213, 225, 0.5)'
            : 'rgba(187, 247, 208, 0.4)';
      const stroke =
        kind === 'inverted'
          ? 'rgba(244, 114, 182, 0.4)'
          : kind === 'shadow' || kind === 'paused'
            ? 'rgba(148, 163, 184, 0.55)'
            : 'rgba(74, 222, 128, 0.4)';
      const labelColor =
        kind === 'inverted'
          ? 'rgba(157, 23, 77, 0.9)'
          : kind === 'shadow' || kind === 'paused'
            ? 'rgba(51, 65, 85, 0.95)'
            : 'rgba(21, 128, 61, 0.9)';
      ctx.fillStyle = fill;
      ctx.fillRect(x0, top, Math.max(3, x1 - x0), bottom - top);
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.strokeRect(x0 + 0.5, top + 0.5, Math.max(3, x1 - x0) - 1, bottom - top - 1);
      ctx.setLineDash([]);
      if (range.label) {
        ctx.fillStyle = labelColor;
        ctx.font = `600 ${this.px(10)}px system-ui, sans-serif`;
        ctx.fillText(range.label, x0 + 4, top + this.px(14));
      }
    }
  }

  /**
   * Отдельная панель PnL под ценой: своя шкала, заливка, разрывы в зоне «выкл.».
   * Не конкурирует с ценой (HYDR ~0.35 / PnL в рублях).
   */
  private drawEquityPanel(
    ctx: CanvasRenderingContext2D,
    visible: PriceCandle[],
    left: number,
    right: number,
    top: number,
    bottom: number,
    candleWidth: number
  ): void {
    if (!this.equityPoints.length || visible.length === 0) return;

    ctx.fillStyle = '#f5f3ff';
    ctx.fillRect(left, top, right - left, bottom - top);
    ctx.strokeStyle = '#ddd6fe';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(left, top);
    ctx.lineTo(right, top);
    ctx.stroke();
    // Бледные зоны «выкл.» под линией PnL
    this.drawShadedRanges(ctx, visible, left, right, top, bottom, candleWidth);

    let minE = Infinity;
    let maxE = -Infinity;
    const samples: { i: number; v: number; gapBefore: boolean }[] = [];
    const sorted = [...this.equityPoints].sort((a, b) =>
      PriceChartComponent.dtKey(a.dt).localeCompare(PriceChartComponent.dtKey(b.dt))
    );

    let last: number | null = null;
    let j = 0;
    const firstVis = PriceChartComponent.dtKey(visible[0].dt);
    const equityStart = PriceChartComponent.dtKey(sorted[0].dt);
    // До якоря нуля (начало теста) линию не рисуем; с якоря — step-функция от 0
    while (j < sorted.length && PriceChartComponent.dtKey(sorted[j].dt) <= firstVis) {
      const v = Number(sorted[j].value);
      if (Number.isFinite(v)) last = v;
      j += 1;
    }
    // Если окно начинается после якоря, но точка якоря ещё не попала в last — 0
    if (last == null && firstVis >= equityStart) {
      last = 0;
    }

    let gapPending = false;
    for (let i = 0; i < visible.length; i++) {
      const key = PriceChartComponent.dtKey(visible[i].dt);
      if (key < equityStart) {
        continue;
      }
      while (j < sorted.length && PriceChartComponent.dtKey(sorted[j].dt) <= key) {
        const v = Number(sorted[j].value);
        if (Number.isFinite(v)) last = v;
        j += 1;
      }
      if (last == null) last = 0;
      if (this.isEquityDtInDisabledInterior(key)) {
        gapPending = true;
        continue;
      }
      if (Number.isFinite(last)) {
        samples.push({ i, v: last, gapBefore: gapPending });
        gapPending = false;
        minE = Math.min(minE, last);
        maxE = Math.max(maxE, last);
      }
    }
    if (samples.length === 0) {
      const onRight = this.chartReversed;
      ctx.fillStyle = '#5b21b6';
      ctx.font = `800 ${this.px(10)}px system-ui, sans-serif`;
      ctx.textAlign = onRight ? 'left' : 'right';
      ctx.fillText('PnL', onRight ? right + 4 : left - 4, top + this.px(14));
      ctx.fillStyle = '#a78bfa';
      ctx.font = `${this.px(9)}px system-ui, sans-serif`;
      ctx.textAlign = onRight ? 'left' : 'right';
      ctx.fillText('нет закрытий в окне', onRight ? right + 4 : left - 4, top + this.px(26));
      ctx.textAlign = 'left';
      return;
    }

    minE = Math.min(minE, 0);
    maxE = Math.max(maxE, 0);
    // Минимальный размах, чтобы линия у нуля не схлопывалась в точку
    const span = maxE - minE;
    const padE = Math.max(span * 0.12, Math.abs(maxE) * 0.05, Math.abs(minE) * 0.05, 1);
    minE -= padE;
    maxE += padE;
    const h = bottom - top;
    const yEq = (v: number) => top + h - ((v - minE) / (maxE - minE)) * h;

    // Нулевая линия
    const y0 = yEq(0);
    ctx.strokeStyle = 'rgba(124, 58, 237, 0.35)';
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(left, y0);
    ctx.lineTo(right, y0);
    ctx.stroke();
    ctx.setLineDash([]);

    const eqX = (i: number) => left + this.xIndex(i, visible.length) * candleWidth + candleWidth / 2;
    // Заливка под ступенями
    ctx.fillStyle = 'rgba(124, 58, 237, 0.14)';
    let seg: { i: number; v: number }[] = [];
    const flushFill = () => {
      if (seg.length === 0) return;
      const pts = (this.chartReversed ? [...seg].reverse() : seg).map(s => ({ x: eqX(s.i), y: yEq(s.v) }));
      ctx.beginPath();
      ctx.moveTo(pts[0].x, y0);
      for (const p of pts) ctx.lineTo(p.x, p.y);
      ctx.lineTo(pts[pts.length - 1].x, y0);
      ctx.closePath();
      ctx.fill();
      seg = [];
    };
    for (const s of samples) {
      if (s.gapBefore) flushFill();
      seg.push(s);
    }
    flushFill();

    // Линия PnL (ступень)
    ctx.strokeStyle = '#7c3aed';
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    let started = false;
    let prevY: number | null = null;
    let prevX: number | null = null;
    const drawSamples = this.chartReversed ? [...samples].reverse() : samples;
    for (const s of drawSamples) {
      const x = eqX(s.i);
      const y = yEq(s.v);
      if (!started || s.gapBefore) {
        ctx.moveTo(x, y);
        started = true;
      } else {
        // Горизонталь предыдущего значения, затем вертикальный шаг
        if (prevY != null && Math.abs(prevY - y) > 0.5) {
          ctx.lineTo(x, prevY);
        }
        ctx.lineTo(x, y);
      }
      prevY = y;
      prevX = x;
    }
    ctx.stroke();

    const onRight = this.chartReversed;
    ctx.fillStyle = '#5b21b6';
    ctx.font = `800 ${this.px(10)}px system-ui, sans-serif`;
    ctx.textAlign = onRight ? 'left' : 'right';
    const ax = onRight ? right + 4 : left - 4;
    ctx.fillText('PnL', ax, top + this.px(12));
    ctx.font = `900 ${this.px(10)}px system-ui, sans-serif`;
    ctx.fillText(this.formatPnlAxis(maxE), ax, top + this.px(22));
    ctx.fillText(this.formatPnlAxis(minE), ax, bottom - 2);
    const lastV = samples[samples.length - 1].v;
    ctx.textAlign = onRight ? 'right' : 'left';
    ctx.fillText(this.formatPnlAxis(lastV), onRight ? left - 4 : right + 4, top + this.px(12));
    ctx.textAlign = 'left';
  }

  private formatPnlAxis(v: number): string {
    if (!Number.isFinite(v)) return '—';
    const abs = Math.abs(v);
    if (abs >= 1000) return v.toFixed(0);
    if (abs >= 10) return v.toFixed(1);
    return v.toFixed(2);
  }

  /** Строго внутри shadedRanges — не на границах (там рисуем шаг PnL). */
  private isEquityDtInDisabledInterior(dtKey: string): boolean {
    for (const r of this.shadedRanges) {
      if (r.kind === 'inverted') continue;
      const a = PriceChartComponent.dtKey(r.startDt);
      const b = PriceChartComponent.dtKey(r.endDt);
      if (dtKey > a && dtKey < b) return true;
    }
    return false;
  }

  private drawStopMarkers(
    ctx: CanvasRenderingContext2D,
    visible: PriceCandle[],
    yScale: (v: number) => number,
    left: number,
    candleWidth: number,
    priceTop: number,
    priceBottom: number
  ): void {
    if (!this.stopMarkers.length) return;
    const labelSize = this.px(10);
    for (const m of this.stopMarkers) {
      const i = this.indexInVisible(visible, m.dt);
      if (i < 0) continue;
      const x = left + this.xIndex(i, visible.length) * candleWidth + candleWidth / 2;
      const y = yScale(Number(m.price));
      const color = m.ruleKind === 'take_profit' ? '#059669' : '#dc2626';
      // Вертикальная полоса — где сработал стоп/тейк
      ctx.strokeStyle = color;
      ctx.globalAlpha = 0.35;
      ctx.lineWidth = Math.max(2, candleWidth * 0.45);
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.moveTo(x, priceTop);
      ctx.lineTo(x, priceBottom);
      ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([5, 3]);
      ctx.beginPath();
      ctx.moveTo(left, y);
      ctx.lineTo(left + visible.length * candleWidth, y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = color;
      ctx.font = `600 ${labelSize}px system-ui, sans-serif`;
      const tag = m.ruleKind === 'take_profit' ? 'TP' : 'SL';
      ctx.fillText(`${tag} ${m.label || ''}`.trim(), x + 4, Math.max(priceTop + labelSize, y - 4));
    }
  }

  private drawTradeMarkers(
    ctx: CanvasRenderingContext2D,
    visible: PriceCandle[],
    yScale: (v: number) => number,
    left: number,
    candleWidth: number,
    priceTop: number,
    priceBottom: number
  ): void {
    if (!this.tradeMarkers.length) return;
    const labelSize = this.px(10);
    const right = left + visible.length * candleWidth;
    // Каждая сделка ставится в своё время внутри бара (по секундам исполнения),
    // а не в центр. Несколько сделок в одну секунду — небольшой разброс по X.
    const slotByKey = new Map<string, number>();
    for (const m of this.tradeMarkers) {
      const i = this.indexInVisible(visible, m.dt);
      if (i < 0) continue;
      const key = PriceChartComponent.dtKey(m.dt);
      const slot = slotByKey.get(key) ?? 0;
      slotByKey.set(key, slot + 1);
      // «Своё время»: сделка на реальный момент исполнения внутри бара, а не в центр.
      const barStart = PriceChartComponent.dtKey(visible[i].dt);
      const barEnd =
        i + 1 < visible.length
          ? PriceChartComponent.dtKey(visible[i + 1].dt)
          : i - 1 >= 0
            ? PriceChartComponent.dtKey(visible[i - 1].dt)
            : null;
      const frac = barEnd
        ? PriceChartComponent.fxInBar(key, barStart, barEnd)
        : 0.5;
      const offset =
        slot === 0
          ? 0
          : (slot % 2 ? 1 : -1) *
            Math.ceil((slot + 1) / 2) *
            Math.max(2, candleWidth * 0.18);
      const xi = this.xIndex(i, visible.length);
      const f = this.chartReversed ? (1 - Math.min(1, Math.max(0, frac))) : Math.min(1, Math.max(0, frac));
      const x = left + xi * candleWidth + f * candleWidth + (this.chartReversed ? -offset : offset);
      const y = yScale(Number(m.price));
      const isLong = m.side === 'long';
      const isOpen = m.kind === 'open';
      const isSignal = m.kind === 'signal';
      const color = m.color ?? (m.isShadow
        ? '#94a3b8'
        : isSignal
          ? (isLong ? '#16a34a' : '#dc2626')
          : isOpen
            ? isLong
              ? '#16a34a'
              : '#dc2626'
            : isLong
              ? '#15803d'
              : '#b91c1c');
      // Вертикальная полоса входа/выхода/сигнала
      ctx.strokeStyle = color;
      ctx.globalAlpha = m.isShadow ? 0.22 : isSignal ? 0.28 : 0.4;
      ctx.lineWidth = Math.max(isSignal ? 1.5 : 2, candleWidth * (isSignal ? 0.35 : 0.45));
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.moveTo(x, priceTop);
      ctx.lineTo(x, priceBottom);
      ctx.stroke();

      if (isSignal) {
        const text = (m.topLabel || m.label || '').trim();
        if (text) {
          ctx.font = `700 ${Math.max(9, this.px(9))}px system-ui, sans-serif`;
          const padX = 4;
          const th = Math.max(12, this.px(12));
          const tw = ctx.measureText(text).width + padX * 2;
          const tx = Math.min(right - tw - 2, Math.max(left + 2, x - tw / 2));
          const ty = priceTop + 2;
          ctx.globalAlpha = 0.92;
          ctx.fillStyle = color;
          ctx.fillRect(tx, ty, tw, th);
          ctx.strokeStyle = 'rgba(15,23,42,0.18)';
          ctx.lineWidth = 1;
          ctx.strokeRect(tx, ty, tw, th);
          ctx.fillStyle = '#ffffff';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'middle';
          ctx.fillText(text, tx + padX, ty + th / 2);
          ctx.textBaseline = 'alphabetic';
        }
        ctx.globalAlpha = 1;
        continue;
      }

      ctx.globalAlpha = m.isShadow ? 0.6 : 1;
      ctx.fillStyle = color;
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1;
      const size = Math.max(9, candleWidth * 1.15);
      ctx.beginPath();
      if (isOpen) {
        ctx.moveTo(x, y - size);
        ctx.lineTo(x - size, y + size * 0.65);
        ctx.lineTo(x + size, y + size * 0.65);
      } else {
        ctx.moveTo(x, y + size);
        ctx.lineTo(x - size, y - size * 0.65);
        ctx.lineTo(x + size, y - size * 0.65);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Горизонтальная черта по фактической цене исполнения + подпись цены у правого края
      ctx.strokeStyle = color;
      ctx.globalAlpha = m.isShadow ? 0.16 : 0.45;
      ctx.lineWidth = 1;
      ctx.setLineDash([5, 3]);
      ctx.beginPath();
      ctx.moveTo(left, y);
      ctx.lineTo(right, y);
      ctx.stroke();
      ctx.setLineDash([]);

      if (!m.isShadow) {
        const text = Number(m.price).toFixed(2).replace('.', ',');
        const tx = Math.max(left, right - 4);
        const ty = Math.min(priceBottom - 2, Math.max(priceTop + labelSize, y - 4));
        ctx.font = `600 ${labelSize}px system-ui, sans-serif`;
        ctx.textAlign = 'right';
        ctx.globalAlpha = 0.9;
        ctx.lineWidth = 3;
        ctx.strokeStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.strokeText(text, tx, ty);
        ctx.fillStyle = color;
        ctx.fillText(text, tx, ty);
        ctx.textAlign = 'left';
      }
      ctx.globalAlpha = 1;
    }
  }

  private drawLineSeries(
    ctx: CanvasRenderingContext2D,
    visible: PriceCandle[],
    series: ChartIndicatorSeries,
    yScale: (v: number) => number,
    left: number,
    candleWidth: number
  ): void {
    ctx.strokeStyle = series.color;
    ctx.lineWidth = series.is_threshold ? 1 : 1.5;
    ctx.setLineDash(series.is_threshold ? [4, 4] : []);
    ctx.beginPath();
    let started = false;
    visible.forEach((c, i) => {
      const v = this.valueAtDt(series, c.dt);
      if (v == null || !Number.isFinite(v)) {
        started = false;
        return;
      }
      const x = left + this.xIndex(i, visible.length) * candleWidth + candleWidth / 2;
      const y = yScale(v);
      if (!started) {
        ctx.moveTo(x, y);
        started = true;
      } else {
        ctx.lineTo(x, y);
      }
    });
    ctx.stroke();
    ctx.setLineDash([]);
  }

  private drawThresholdLine(
    ctx: CanvasRenderingContext2D,
    series: ChartIndicatorSeries,
    yScale: (v: number) => number,
    left: number,
    right: number
  ): void {
    const v = series.points[0]?.value;
    if (v == null || !Number.isFinite(v)) return;
    ctx.strokeStyle = series.color;
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 4]);
    const y = yScale(v);
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(right, y);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  private drawLegend(
    ctx: CanvasRenderingContext2D,
    cssW: number,
    pad: { left: number }
  ): void {
    if (this.compact && !this.fullscreen) return;
    const drawn = this.indicatorSeries.filter((s) => !s.is_threshold && !s.on_price_scale);
    let x = pad.left;
    const y = this.px(18);
    const legendSize = this.px(9);
    const swatchW = this.px(10);
    const swatchH = Math.max(3, this.px(3));
    ctx.font = `${legendSize}px system-ui, sans-serif`;
    if (this.equityPoints.length > 0) {
      ctx.fillStyle = '#7c3aed';
      ctx.fillRect(x, y - swatchH - 2, swatchW, swatchH);
      ctx.fillStyle = '#374151';
      ctx.fillText('PnL', x + swatchW + 3, y);
      x += ctx.measureText('PnL').width + this.px(22);
    }
    for (const s of drawn.slice(0, 8)) {
      const label = `${s.indicator_code}.${s.line_code}`;
      ctx.fillStyle = s.color;
      ctx.fillRect(x, y - swatchH - 2, swatchW, swatchH);
      ctx.fillStyle = '#374151';
      ctx.fillText(label, x + swatchW + 3, y);
      x += ctx.measureText(label).width + this.px(22);
      if (x > cssW - 80) break;
    }
  }
}
