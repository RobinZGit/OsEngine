/** Режим торговых периодов: off — не учитывать; trading — только торговые; non_trading — только неторговые. */
export type NonTradingPeriodsMode = 'off' | 'trading' | 'non_trading';

export interface LogicRow {
  id: number;
  name: string;
  account_id: number;
  broker_id: number;
  is_enabled: boolean;
  /** Если true — логика дополнительно выдаёт сигналы покупки/продажи в терминал
      (при выключенном бое тоже работает как источник сигналов). */
  use_as_terminal_signal?: boolean;
  note?: string | null;
  /** Короткая формальная запись включённых сигналов логики (вычисляется API при загрузке списка). */
  signals_summary?: string | null;
  timeframe?: string;
  /** free_cash | portfolio | portfolio_incl_fund — база % для расчёта лота */
  position_size_base?: 'free_cash' | 'portfolio' | 'portfolio_incl_fund';
  position_size_pct: number;
  max_open_positions: number;
  /** Потолок номинала одной покупки, ₽; null/undefined = без лимита */
  max_order_amount?: number | null;
  initial_balance: number | null;
  current_balance: number | null;
  /** Стартовый остаток ТОЛЬКО для бэктеста; null = не задан (берётся initial_balance). */
  test_initial_balance?: number | null;
  commission_pct?: number;
  cost_method?: 'FIFO' | 'AVERAGE';
  stop_loss_timeframe?: string;
  base_annual_rate_pct?: number;
  rating_lookback_days?: number;
  /** Инверсия логики: условия наоборот и Long↔Short. */
  inversion?: boolean;
  /** portfolio_resume / portfolio_ltp_renew: весь портфель в shadow до восстановления. */
  portfolio_trading_paused?: boolean;
  /** Цель equity для возобновления реала (до срабатывания pause). */
  portfolio_stop_resume_equity?: number | null;
  /** Equity после закрытия реала при pause (baseline + shadow_pnl ≥ target). */
  portfolio_stop_resume_baseline?: number | null;
  /** Момент входа в тень портфеля (shadow PnL считается с этой метки). */
  portfolio_stop_resume_at?: string | null;
  /** Активен линейный TP по портфелю с возобновлением (для подписи бейджа). */
  has_portfolio_ltp_renew?: boolean;
  /** Активен стоп-лосс portfolio_resume (для подписи бейджа). */
  has_portfolio_resume_sl?: boolean;
  /** Перед включением боя: предварительный тест для stop resume / inversion states. */
  warmup_pretest?: boolean;
  /** Авто оптимизация: по закрытию позиции подстраивает главный период (period) сигналов входа. */
  auto_optimize?: boolean;
  /**
   * security_resume: при повторном стопе цель возобновления не ниже прежнего максимума (HWM).
   * По умолчанию выкл.
   */
  resume_sl_no_reduce?: boolean;
  /** Денежный фонд для парковки кэша: '' | TMON | LQDT | SBMM (runner later). */
  cash_fund_code?: string;
  /** Порог equity портфеля (₽): парковать min(кэш, equity−порог−уже_в_фонде). */
  cash_fund_threshold?: number;
  /** Учитывать неторговые периоды при открытии сделок (устаревший флаг). */
  use_non_trading_periods?: boolean;
  /** Режим торговых периодов (приоритетнее use_non_trading_periods). */
  non_trading_periods_mode?: NonTradingPeriodsMode;
  /** Закрывать позиции в конце дня (кроме денежных фондов). */
  close_positions_eod?: boolean;
  /** Продавать фьючерсы за N дней до экспирации (EOD). */
  sell_futures_before_expiry?: boolean;
  /** Порог дней до экспирации для принудительной продажи. */
  sell_futures_days_before_expiry?: number;
  /** Тип исполнения боевых заявок: market (по умолчанию) | limit. */
  order_execution?: 'market' | 'limit';
  /** Окно promote OPT: число закрытых свечей TF (по умолчанию 200). */
  opt_eval_candles?: number;
  account_code: string;
  account_name: string;
  account_type: 'real' | 'fake';
  /** Дата последнего прогона теста (logic_backtest_runs.created_at) — для сортировки списка. */
  last_test_at?: string | null;
  account_is_active: boolean;
  broker_code: string;
  broker_name: string;
}

export interface LogicTradingParamsPayload {
  timeframe?: string;
  position_size_base?: 'free_cash' | 'portfolio' | 'portfolio_incl_fund';
  position_size_pct?: number;
  max_open_positions?: number;
  max_order_amount?: number | null;
  order_gap_buffer_pct?: number | null;
  max_open_gap_pct?: number | null;
  initial_balance?: number | null;
  test_initial_balance?: number | null;
  reset_balance?: boolean;
  commission_pct?: number;
  cost_method?: 'FIFO' | 'AVERAGE';
  stop_loss_timeframe?: string;
  base_annual_rate_pct?: number;
  rating_lookback_days?: number;
  inversion?: boolean;
  warmup_pretest?: boolean;
  auto_optimize?: boolean;
  resume_sl_no_reduce?: boolean;
  cash_fund_code?: string;
  cash_fund_threshold?: number;
  use_non_trading_periods?: boolean;
  non_trading_periods_mode?: NonTradingPeriodsMode;
  close_positions_eod?: boolean;
  sell_futures_before_expiry?: boolean;
  sell_futures_days_before_expiry?: number;
  order_execution?: 'market' | 'limit';
  opt_eval_candles?: number;
}

export interface LogicTradingParamsResponse {
  timeframe: string;
  position_size_base: 'free_cash' | 'portfolio' | 'portfolio_incl_fund';
  position_size_pct: number;
  max_open_positions: number;
  max_order_amount: number | null;
  order_gap_buffer_pct: number | null;
  max_open_gap_pct: number | null;
  initial_balance: number | null;
  current_balance: number | null;
  commission_pct: number;
  cost_method: 'FIFO' | 'AVERAGE';
  stop_loss_timeframe: string;
  base_annual_rate_pct: number;
  rating_lookback_days: number;
  inversion: boolean;
  warmup_pretest: boolean;
  auto_optimize: boolean;
  resume_sl_no_reduce: boolean;
  cash_fund_code: string;
  cash_fund_threshold: number;
  use_non_trading_periods: boolean;
  non_trading_periods_mode: NonTradingPeriodsMode;
  close_positions_eod: boolean;
  sell_futures_before_expiry: boolean;
  sell_futures_days_before_expiry: number;
  order_execution: 'market' | 'limit';
  opt_eval_candles: number;
}

export interface LogicNonTradingIntervalRow {
  id: number;
  logic_id: number;
  day_of_week: number;
  time_from: string;
  time_to: string;
  note?: string | null;
  display_order: number;
  is_active: boolean;
}

export interface LogicNonTradingIntervalPayload {
  day_of_week?: number;
  time_from?: string;
  time_to?: string;
  note?: string | null;
  is_active?: boolean;
}

export interface LogicNonTradingPeriodsResponse {
  logic_id: number;
  non_trading_periods_mode?: NonTradingPeriodsMode;
  use_non_trading_periods: boolean;
  intervals: LogicNonTradingIntervalRow[];
  applied?: number;
}

export interface LogicParamRow {
  id: number;
  logic_id: number;
  param_key: string;
  param_value: string;
  value_type: 'number' | 'integer' | 'money' | 'boolean' | 'text';
  updated_at?: string;
  name_ru?: string;
  description?: string;
}

export interface LogicParamsResponse {
  logic_id: number;
  trading: LogicTradingParamsResponse;
  params: LogicParamRow[];
}

export interface LogicIndicatorSignalRow {
  id: number;
  logic_id: number;
  indicator_id: number;
  position_event: 'open' | 'close';
  position_side: 'long' | 'short';
  signal_kind: 'trend' | 'counter';
  /** security = бумага; base_asset = база; contango = ряд (фьючерс − база) */
  signal_acts_on?: 'security' | 'base_asset' | 'contango' | 'portfolio';
  /** #972: секунды подтверждения типа сигнала (0 = не подтверждать; 10/20/30/40/50/60/120). */
  signal_confirm_sec?: number;
  formula: string;
  /** Боевой рейтинг сигнала на логике (не справочник indicators). */
  rating: number;
  /** Тестовый рейтинг (бэктест), не смешивается с rating. */
  rating_test?: number;
  display_order: number;
  is_active: boolean;
  indicator_code: string;
  indicator_name: string;
}

export interface LogicStopRow {
  id: number;
  logic_id: number;
  rule_kind: 'stop_loss' | 'take_profit';
  scope_type:
    | 'security'
    | 'security_resume'
    | 'security_inversion'
    | 'portfolio'
    | 'portfolio_resume'
    | 'portfolio_ltp_renew'
    | 'security_ltp_renew';
  value: number;
  /** @deprecated unused; security_inversion uses value only */
  inversion_value?: number | null;
  value_unit: 'percent' | 'atr';
  display_order: number;
  is_active: boolean;
  created_at?: string;
}

export interface LogicSecurityRow {
  id: number;
  logic_id: number;
  security_id: number;
  display_order: number;
  is_active: boolean;
  created_at?: string;
  security_name: string;
  lot_size?: number;
  security_type: string;
  prefix: string | null;
  instrument_market: string | null;
  underlying_security_id?: number | null;
  underlying_security_name?: string | null;
  underlying_prefix?: string | null;
  exchange_id: number | null;
  exchange_name: string | null;
  real_trading_paused?: boolean;
  real_trading_paused_long?: boolean;
  real_trading_paused_short?: boolean;
  real_trading_inverted?: boolean;
  stop_resume_equity?: number | null;
  stop_resume_baseline?: number | null;
  stop_resume_triggered_at?: string | null;
  stop_resume_equity_long?: number | null;
  stop_resume_baseline_long?: number | null;
  stop_resume_triggered_at_long?: string | null;
  stop_resume_equity_short?: number | null;
  stop_resume_baseline_short?: number | null;
  stop_resume_triggered_at_short?: string | null;
}
