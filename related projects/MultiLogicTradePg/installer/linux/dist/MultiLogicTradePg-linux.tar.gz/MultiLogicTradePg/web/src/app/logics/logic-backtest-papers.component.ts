import { CommonModule } from '@angular/common';
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  OnChanges,
  OnDestroy,
  SimpleChanges,
  inject,
} from '@angular/core';
import { Subscription, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { PriceChartComponent } from '../price-chart/price-chart.component';
import { LogicBacktestRatingsComponent } from './logic-backtest-ratings.component';
import {
  ChartEquityPoint,
  ChartIndicatorSeries,
  ChartShadedRange,
  ChartStopMarker,
  ChartTradeMarker,
  ChartVisibleRange,
  IndicatorValueRow,
  PriceCandle,
} from '../models/market.model';
import { SecuritiesService } from '../services/securities.service';
import { TechLogService } from '../services/tech-log.service';
import { LogicsService } from '../services/logics.service';
import { LogicTradeRow } from '../shared/logic-trade';
import {
  applyPaperMarkValue,
  buildEquityPoints,
  buildShadowEquityPoints,
  buildShadedDisabledRanges,
  buildStopMarkers,
  buildTradeMarkers,
  clipCandlesForBacktest,
  dtKey,
  PaperListRow,
  papersWithTrades,
  tradeDtWindow,
  tradesForSecurity,
} from './backtest-chart-overlays';

export type BacktestPaperRow = PaperListRow;

/** Сервер отдаёт свечи DESC (новые → старые); графику нужен порядок ASC. */
function sortCandlesAsc(candles: PriceCandle[]): PriceCandle[] {
  return [...candles].sort(
    (a, b) => new Date(a.dt).getTime() - new Date(b.dt).getTime()
  );
}

function humanizeChartLoadError(err: unknown): string {
  const e = err as { name?: string; message?: string; error?: { error?: string } };
  if (
    e?.name === 'TimeoutError' ||
    /timeout/i.test(e?.message || '') ||
    /timeout/i.test(e?.error?.error || '')
  ) {
    return 'Сервер не ответил вовремя — раскройте бумагу ещё раз';
  }
  return e?.error?.error || e?.message || 'Не удалось загрузить цены';
}

/** Дешёвый отпечаток списка сделок бумаги — early-return без build markers. */
function paperTradesFingerprint(trades: LogicTradeRow[]): string {
  if (trades.length === 0) return '0';
  const first = trades[0];
  const last = trades[trades.length - 1];
  const remHint = trades
    .filter((t) => t.side_name === 'Open')
    .reduce((s, t) => s + Number(t.remaining_qty ?? t.quantity ?? 0), 0);
  return `${trades.length}:${first.id}:${last.id}:${last.bar_dt}:${last.financial_result ?? ''}:${remHint}`;
}

interface PaperOverlays {
  markers: ChartTradeMarker[];
  stops: ChartStopMarker[];
  shaded: ChartShadedRange[];
  equity: ChartEquityPoint[];
  equityLong: ChartEquityPoint[];
  equityShort: ChartEquityPoint[];
  equityShadow: ChartEquityPoint[];
}

interface PaperChartState {
  candles: PriceCandle[];
  loading: boolean;
  loadingOlder: boolean;
  hasMore: boolean;
  error: string | null;
  status: string | null;
  focusDt: string | null;
  indicatorSeries: ChartIndicatorSeries[];
  suppressIndicators: boolean;
  syncGen: number;
  lastRangeKey: string;
  /** ��������� ��� ���������� ����� ������ ������� ������. */
  indicatorsBootstrapped: boolean;
  sliderIndex: number;
  playSpeed: number;
  playTimer: ReturnType<typeof setInterval> | null;
  popup: PaperPopup | null;
  popupTimer: ReturnType<typeof setTimeout> | null;
}

interface PaperPopup {
  kind: 'open' | 'close';
  side: 'long' | 'short';
  title: string;
  detail: string;
  finRes?: number;
  accumulatedFinRes: number;
}

const EMPTY_SERIES: ChartIndicatorSeries[] = [];
const SERIES_COLORS = [
  '#2563eb',
  '#9333ea',
  '#ea580c',
  '#0891b2',
  '#ca8a04',
  '#db2777',
  '#059669',
  '#4f46e5',
];
const PRICE_SCALE_CODES = new Set(['SMA', 'EMA', 'WMA', 'PACC', 'SMAT3']);
/** Первая порция на развороте — без длинной догрузки истории. */
const INITIAL_CANDLES = 120;
const MAX_CANDLES = 400;

@Component({
  selector: 'app-logic-backtest-papers',
  standalone: true,
  imports: [CommonModule, PriceChartComponent, LogicBacktestRatingsComponent],
  templateUrl: './logic-backtest-papers.component.html',
  styleUrl: './logic-backtest-papers.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogicBacktestPapersComponent implements OnChanges, OnDestroy {
  private readonly securitiesApi = inject(SecuritiesService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly techLog = inject(TechLogService);
  private readonly logicsApi = inject(LogicsService);

  /** test — бэктест; live — боевые сделки (те же lazy/OnPush ограничения). */
  @Input() mode: 'test' | 'live' = 'test';
  @Input() logicId: number | null = null;
  @Input() runId: number | null = null;
  @Input() reloadToken: string | number | null = null;
  @Input() trades: LogicTradeRow[] = [];
  @Input() dateFrom: string | null = null;
  @Input() dateTo: string | null = null;
  @Input() timeframeId: number | null = null;
  @Input() signalIndicatorIds: number[] = [];
  /** Начальный депозит логики — для % у PnL бумаги. */
  @Input() initialBalance: number | null = null;
  /** Денежный фонд (TMON/LQDT/SBMM) — всегда первой строкой в списке бумаг. */
  @Input() pinnedPaper: BacktestPaperRow | null = null;
  /** Мета бумаг логики (underlying для фьючерсов → второй график; активность → чекбокс). */
  @Input() logicSecurities: Array<{
    id: number;
    security_id: number;
    is_active: boolean;
    underlying_security_id?: number | null;
    underlying_security_name?: string | null;
    underlying_prefix?: string | null;
  }> = [];

  get isLive(): boolean {
    return this.mode === 'live';
  }

  expandedPapers = false;
  expandedSecurityIds = new Set<number>();
  /** Инкремент при готовности графика — чтобы OnPush/@if точно перерисовались. */
  chartTick = 0;

  paperRows: BacktestPaperRow[] = [];
  private overlaysBySec = new Map<number, PaperOverlays>();
  private overlayFingerprintBySec = new Map<number, string>();
  private charts = new Map<number, PaperChartState>();
  private rangeTimers = new Map<number, ReturnType<typeof setTimeout>>();
  private chartLoadSubs = new Map<number, Subscription>();
  private subs = new Subscription();
  private markPriceSubs = new Subscription();
  private uniqueIndicatorIds: number[] = [];

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['signalIndicatorIds']) {
      this.uniqueIndicatorIds = [
        ...new Set(this.signalIndicatorIds.filter((id) => id != null).map(Number)),
      ];
    }
    const periodChanged =
      !!changes['dateFrom'] || !!changes['dateTo'] || !!changes['runId'];
    if (
      changes['trades'] ||
      periodChanged ||
      changes['pinnedPaper'] ||
      changes['logicSecurities']
    ) {
      this.rebuildPaperCache({ reloadCharts: periodChanged });
    } else if (changes['reloadToken'] && this.expandedPapers) {
      // Бой: poll обновляет token — подтянуть текущие цены для «сум.» / «цена».
      this.refreshOpenMarkValues();
    }
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
    this.markPriceSubs.unsubscribe();
    for (const t of this.rangeTimers.values()) clearTimeout(t);
    for (const st of this.charts.values()) {
      if (st.playTimer) clearInterval(st.playTimer);
      if (st.popupTimer) clearTimeout(st.popupTimer);
    }
  }

  togglePapersBlock(event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    this.expandedPapers = !this.expandedPapers;
    if (this.expandedPapers && this.paperRows.length === 0) {
      this.rebuildPaperCache({ reloadCharts: false });
    } else if (this.expandedPapers) {
      this.refreshOpenMarkValues();
    }
  }

  isPaperExpanded(securityId: number): boolean {
    return this.expandedSecurityIds.has(securityId);
  }

  togglePaper(event: Event, securityId: number): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.expandedSecurityIds.has(securityId)) {
      this.expandedSecurityIds.delete(securityId);
      this.cancelChartLoad(securityId);
      const st = this.charts.get(securityId);
      if (st) {
        st.loading = false;
        st.loadingOlder = false;
        this.paperStopPlay(securityId);
        this.paperHidePopup(securityId);
      }
      this.techLog.event(
        this.techLog.logicThreadKey(this.logicId ?? 0, 'paper'),
        'paper.collapse',
        `Свернули бумагу sec=${securityId}`,
        { logicId: this.logicId ?? undefined, securityId }
      );
      this.cdr.markForCheck();
      return;
    }
    this.expandedSecurityIds.add(securityId);
    // Сбросить залипший loading от прошлого разворота — иначе ensureChartLoaded сразу return.
    this.cancelChartLoad(securityId);
    {
      const st = this.chartState(securityId);
      st.loading = false;
      st.loadingOlder = false;
      st.error = null;
      st.status = 'Загрузка графика…';
      if (st.candles.length === 0) {
        st.indicatorsBootstrapped = false;
        st.lastRangeKey = '';
      }
    }
    this.techLog.event(
      this.techLog.logicThreadKey(this.logicId ?? 0, 'paper'),
      'paper.expand',
      `Раскрыли бумагу sec=${securityId}`,
      {
        logicId: this.logicId ?? undefined,
        securityId,
        force: true,
        payload: {
          run_id: this.runId,
          candles: this.charts.get(securityId)?.candles.length ?? 0,
        },
      }
    );
    this.chartTick++;
    this.cdr.detectChanges();
    setTimeout(() => {
      this.ensureChartLoaded(securityId);
      const undId = this.paperRows.find((p) => p.security_id === securityId)
        ?.underlying_security_id;
      if (undId != null && Number(undId) > 0 && Number(undId) !== securityId) {
        this.ensureChartLoaded(Number(undId));
      }
    }, 0);
  }

  /** Есть строчка логики (логическая бумага с признаком is_active) — показываем чекбокс. */
  isPaperToggleable(securityId: number): boolean {
    return this.logicSecurities.some(
      (s) => Number(s.security_id) === Number(securityId)
    );
  }

  isPaperActive(securityId: number): boolean {
    return (
      this.logicSecurities.find(
        (s) => Number(s.security_id) === Number(securityId)
      )?.is_active ?? false
    );
  }

  private savingPaperIds = new Set<number>();

  isPaperActiveSaving(securityId: number): boolean {
    return this.savingPaperIds.has(Number(securityId));
  }

  togglePaperActive(paper: BacktestPaperRow, event: Event): void {
    event.stopPropagation();
    const row = this.logicSecurities.find(
      (s) => Number(s.security_id) === Number(paper.security_id)
    );
    if (!row || this.savingPaperIds.has(row.id)) return;
    const next = !row.is_active;
    this.savingPaperIds.add(row.id);
    this.logicsApi.updateLogicSecurity(row.id, { is_active: next }).subscribe({
      next: (updated) => {
        this.savingPaperIds.delete(row.id);
        this.patchLogicSecurity(updated);
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.savingPaperIds.delete(row.id);
        this.cdr.markForCheck();
        alert(err?.error?.error || 'Не удалось изменить активность бумаги');
      },
    });
  }

  private patchLogicSecurity(updated: {
    id: number;
    is_active: boolean;
  }): void {
    const idx = this.logicSecurities.findIndex((s) => s.id === updated.id);
    if (idx >= 0) {
      this.logicSecurities[idx] = { ...this.logicSecurities[idx], ...updated };
    }
  }

  /** Есть свечи — для @if (OnPush стабильнее, чем читать Map в шаблоне много раз). */
  hasChartCandles(securityId: number): boolean {
    return (this.charts.get(securityId)?.candles.length ?? 0) > 0;
  }

  isChartLoading(securityId: number): boolean {
    const st = this.charts.get(securityId);
    return !!st && st.loading && st.candles.length === 0;
  }

  private cancelChartLoad(securityId: number): void {
    const prev = this.chartLoadSubs.get(securityId);
    if (prev) {
      prev.unsubscribe();
      this.chartLoadSubs.delete(securityId);
    }
  }

  private bumpChartView(): void {
    this.chartTick++;
    this.cdr.markForCheck();
    this.cdr.detectChanges();
  }

  // --- Paper playback slider ---
  paperSliderMax(securityId: number): number {
    return Math.max(0, this.chartState(securityId).candles.length - 1);
  }

  paperSliderValue(securityId: number): number {
    const st = this.chartState(securityId);
    return Math.max(0, Math.min(this.paperSliderMax(securityId), st.sliderIndex));
  }

  paperCurrentDt(securityId: number): string {
    const st = this.chartState(securityId);
    const c = st.candles[this.paperSliderValue(securityId)];
    return c ? this.fmtPaperDt(c.dt) : '-';
  }

  paperCurrentPrice(securityId: number): string {
    const st = this.chartState(securityId);
    const c = st.candles[this.paperSliderValue(securityId)];
    return c ? Number(c.close_price).toFixed(2) : '-';
  }

  paperAccumulatedFinRes(securityId: number): number {
    const st = this.chartState(securityId);
    const idx = this.paperSliderValue(securityId);
    const dt = st.candles[idx]?.dt;
    if (!dt) return 0;
    const key = this.dtNum(dt);
    const pts = this.overlays(securityId).equity;
    let last = 0;
    for (const p of pts) {
      if (this.dtNum(p.dt) <= key) last = Number(p.value) || 0;
      else break;
    }
    if (pts.length === 0) {
      // fallback from markers - no finres amount, keep 0
      return 0;
    }
    return last;
  }

  formatFinRes(value: number): string {
    const sign = value > 0 ? '+' : '';
    return `${sign}${Number(value).toFixed(2)}`;
  }

  finResClass(value: number): string {
    if (value > 0) return 'finres-pos';
    if (value < 0) return 'finres-neg';
    return 'finres-zero';
  }

  private fmtPaperDt(dt: string): string {
    return String(dt || '').replace('T', ' ').slice(0, 16);
  }

  private dtNum(dt: string): number {
    const t = new Date(dt).getTime();
    return Number.isFinite(t) ? t : 0;
  }

  paperOnSliderChange(securityId: number, value: number): void {
    const st = this.chartState(securityId);
    const prev = this.paperSliderValue(securityId);
    st.sliderIndex = Math.max(0, Math.min(this.paperSliderMax(securityId), Number(value)));
    this.paperSyncSlider(securityId, prev);
  }

  paperStep(securityId: number, delta: number): void {
    this.paperStopPlay(securityId);
    const st = this.chartState(securityId);
    const prev = this.paperSliderValue(securityId);
    st.sliderIndex = Math.max(0, Math.min(this.paperSliderMax(securityId), prev + delta));
    this.paperSyncSlider(securityId, prev);
  }

  paperToStart(securityId: number): void {
    this.paperStopPlay(securityId);
    const st = this.chartState(securityId);
    const prev = this.paperSliderValue(securityId);
    st.sliderIndex = 0;
    this.paperSyncSlider(securityId, prev);
  }

  paperToEnd(securityId: number): void {
    this.paperStopPlay(securityId);
    const st = this.chartState(securityId);
    const prev = this.paperSliderValue(securityId);
    st.sliderIndex = this.paperSliderMax(securityId);
    this.paperSyncSlider(securityId, prev);
  }

  paperTogglePlay(securityId: number): void {
    const st = this.chartState(securityId);
    if (st.playSpeed > 0) {
      this.paperStopPlay(securityId);
      this.bumpChartView();
      return;
    }
    st.playSpeed = 1;
    st.playTimer = setInterval(() => {
      const cur = this.paperSliderValue(securityId);
      const max = this.paperSliderMax(securityId);
      if (cur >= max) {
        this.paperStopPlay(securityId);
        this.bumpChartView();
        return;
      }
      st.sliderIndex = cur + 1;
      this.paperSyncSlider(securityId, cur, false);
    }, 220);
    this.bumpChartView();
  }

  paperStopPlay(securityId: number): void {
    const st = this.chartState(securityId);
    st.playSpeed = 0;
    if (st.playTimer) {
      clearInterval(st.playTimer);
      st.playTimer = null;
    }
  }

  paperHidePopup(securityId: number): void {
    const st = this.chartState(securityId);
    st.popup = null;
    if (st.popupTimer) {
      clearTimeout(st.popupTimer);
      st.popupTimer = null;
    }
  }

  private paperSyncSlider(securityId: number, prevIndex?: number, detect = true): void {
    const st = this.chartState(securityId);
    const idx = this.paperSliderValue(securityId);
    st.sliderIndex = idx;
    st.focusDt = st.candles[idx]?.dt ?? st.focusDt;
    if (detect && prevIndex !== undefined && prevIndex !== idx) {
      this.paperShowPopupForIndex(securityId, idx, prevIndex);
    } else if (prevIndex === undefined) {
      this.paperHidePopup(securityId);
    }
    this.bumpChartView();
  }

  private paperShowPopupForIndex(securityId: number, index: number, prevIndex?: number): void {
    const st = this.chartState(securityId);
    const dt = st.candles[index]?.dt;
    if (!dt) return;
    const key = this.dtNum(dt);
    const markers = this.overlays(securityId).markers.filter((m) => this.dtNum(m.dt) === key);
    if (markers.length === 0) return;
    const e = prevIndex != null && index < prevIndex ? markers[0] : markers[markers.length - 1];
    if (e.kind === 'signal') return;
    const isOpen = e.kind === 'open';
    const sideText = e.side === 'long' ? 'LONG' : 'SHORT';
    const acc = this.paperAccumulatedFinRes(securityId);
    // estimate trade finres as equity delta around close
    let finRes: number | undefined;
    if (!isOpen) {
      const eq = this.overlays(securityId).equity;
      const at = eq.findIndex((p) => this.dtNum(p.dt) === key);
      if (at > 0) finRes = Number(eq[at].value) - Number(eq[at - 1].value);
      else if (at === 0) finRes = Number(eq[0].value);
      else finRes = undefined;
    }
    st.popup = {
      kind: e.kind,
      side: e.side,
      title: isOpen ? `Бац! Вошли в сделку ${sideText}` : `Бац! Вышли из сделки ${sideText}`,
      detail: isOpen
        ? `${e.label || (e.side === 'long' ? 'Вход L' : 'Вход S')} · ${this.fmtPaperDt(dt)}`
        : `${e.label || (e.side === 'long' ? 'Выход L' : 'Выход S')} · Финрез: ${this.formatFinRes(Number(finRes ?? 0))}`,
      finRes,
      accumulatedFinRes: acc,
    };
    if (st.popupTimer) clearTimeout(st.popupTimer);
    st.popupTimer = setTimeout(() => {
      st.popup = null;
      st.popupTimer = null;
      this.bumpChartView();
    }, 2600);
  }

  paperVisibleMarkers(securityId: number): ChartTradeMarker[] {
    const st = this.chartState(securityId);
    const dt = st.candles[this.paperSliderValue(securityId)]?.dt;
    if (!dt) return this.overlays(securityId).markers;
    const key = this.dtNum(dt);
    return this.overlays(securityId).markers.filter((m) => this.dtNum(m.dt) <= key);
  }

  paperVisibleStops(securityId: number): ChartStopMarker[] {
    const st = this.chartState(securityId);
    const dt = st.candles[this.paperSliderValue(securityId)]?.dt;
    if (!dt) return this.overlays(securityId).stops;
    const key = this.dtNum(dt);
    return this.overlays(securityId).stops.filter((m) => this.dtNum(m.dt) <= key);
  }

  paperVisibleEquity(securityId: number): ChartEquityPoint[] {
    const st = this.chartState(securityId);
    const dt = st.candles[this.paperSliderValue(securityId)]?.dt;
    if (!dt) return this.overlays(securityId).equity;
    const key = this.dtNum(dt);
    return this.overlays(securityId).equity.filter((p) => this.dtNum(p.dt) <= key);
  }

  paperVisibleEquityLong(securityId: number): ChartEquityPoint[] {
    const st = this.chartState(securityId);
    const dt = st.candles[this.paperSliderValue(securityId)]?.dt;
    if (!dt) return this.overlays(securityId).equityLong;
    const key = this.dtNum(dt);
    return this.overlays(securityId).equityLong.filter((p) => this.dtNum(p.dt) <= key);
  }

  paperVisibleEquityShort(securityId: number): ChartEquityPoint[] {
    const st = this.chartState(securityId);
    const dt = st.candles[this.paperSliderValue(securityId)]?.dt;
    if (!dt) return this.overlays(securityId).equityShort;
    const key = this.dtNum(dt);
    return this.overlays(securityId).equityShort.filter((p) => this.dtNum(p.dt) <= key);
  }

  paperVisibleEquityShadow(securityId: number): ChartEquityPoint[] {
    const st = this.chartState(securityId);
    const dt = st.candles[this.paperSliderValue(securityId)]?.dt;
    if (!dt) return this.overlays(securityId).equityShadow;
    const key = this.dtNum(dt);
    return this.overlays(securityId).equityShadow.filter((p) => this.dtNum(p.dt) <= key);
  }

  paperFocusDt(securityId: number): string | null {
    const st = this.chartState(securityId);
    const c = st.candles[this.paperSliderValue(securityId)];
    return c?.dt ?? st.focusDt;
  }

  paperSliderActive(securityId: number): boolean {
    return this.chartState(securityId).candles.length > 0;
  }


  chartState(securityId: number): PaperChartState {
    let st = this.charts.get(securityId);
    if (!st) {
      st = {
        candles: [],
        loading: false,
        loadingOlder: false,
        hasMore: true,
        error: null,
        status: null,
        focusDt: null,
        indicatorSeries: [],
        suppressIndicators: false,
        syncGen: 0,
        lastRangeKey: '',
        indicatorsBootstrapped: false,
        sliderIndex: 0,
        playSpeed: 0,
        playTimer: null,
        popup: null,
        popupTimer: null,
      };
      this.charts.set(securityId, st);
    }
    return st;
  }

  chartIndicatorsForDisplay(securityId: number): ChartIndicatorSeries[] {
    const st = this.chartState(securityId);
    if (st.suppressIndicators) return EMPTY_SERIES;
    return st.indicatorSeries;
  }

  overlays(securityId: number): PaperOverlays {
    let o = this.overlaysBySec.get(securityId);
    if (!o) {
      o = {
        markers: [],
        stops: [],
        shaded: [],
        equity: [],
        equityLong: [],
        equityShort: [],
        equityShadow: [],
      };
      this.overlaysBySec.set(securityId, o);
    }
    return o;
  }

  // #836: переключатель «График / Эквити» убран — цена всегда свечи/линия
  // (тумблер в тулбаре графика), PnL бумаги — полосой под ценой.


  paperPnlPct(pnl: number): number | null {
    const initial = Number(this.initialBalance);
    if (!Number.isFinite(initial) || initial <= 0) return null;
    return (pnl / initial) * 100;
  }

  formatPnlPct(value: number | null | undefined): string {
    if (value == null || !Number.isFinite(Number(value))) return '—';
    const n = Number(value);
    const sign = n > 0 ? '+' : n < 0 ? '−' : '';
    return `${sign}${Math.abs(n).toFixed(2)}%`;
  }

  formatPnl(value: number): string {
    const sign = value > 0 ? '+' : '';
    return `${sign}${value.toFixed(2)}`;
  }

  formatMoney(value: number | null | undefined): string {
    const n = Number(value);
    if (!Number.isFinite(n)) return '0.00';
    return n.toFixed(2);
  }

  formatOpenQty(value: number | null | undefined): string {
    const n = Number(value);
    if (!Number.isFinite(n) || n === 0) return '0';
    const sign = n > 0 ? '+' : '−';
    const abs = Math.abs(n);
    const text = Number.isInteger(abs) ? String(abs) : abs.toFixed(4).replace(/\.?0+$/, '');
    return `${sign}${text}`;
  }

  onLoadOlder(securityId: number): void {
    const tfId = this.resolveTimeframeId(securityId);
    const st = this.chartState(securityId);
    if (!tfId || st.loadingOlder || !st.hasMore || st.candles.length === 0) return;
    const before = st.candles[0].dt;
    st.loadingOlder = true;
    // Timeout/сеть — тихо; не пишем на график и не режем hasMore.
    let softFail = false;
    const sub = this.securitiesApi
      .getPrices(securityId, tfId, INITIAL_CANDLES, before)
      .pipe(
        catchError(() => {
          softFail = true;
          return of([] as PriceCandle[]);
        }),
        finalize(() => {
          st.loadingOlder = false;
          this.cdr.detectChanges();
        })
      )
      .subscribe({
        next: (rows) => {
          if (rows.length === 0) {
            if (!softFail) st.hasMore = false;
            return;
          }
          const merged = sortCandlesAsc([...rows, ...st.candles]);
          st.candles = merged.length > MAX_CANDLES ? merged.slice(-MAX_CANDLES) : merged;
          // Маркеры / PnL / стопы — из кэша overlays, перерисуются со свечами.
          this.cdr.detectChanges();
        },
      });
    this.subs.add(sub);
  }

  onVisibleRange(securityId: number, range: ChartVisibleRange): void {
    // Только жест пользователя (pan); auto-emit при mount отключён.
    if (!range.userInitiated) {
      return;
    }
    const st = this.chartState(securityId);
    st.suppressIndicators = true;
    this.cdr.detectChanges();
    const prev = this.rangeTimers.get(securityId);
    if (prev) clearTimeout(prev);
    const timer = setTimeout(() => this.loadIndicatorValues(securityId, range), 650);
    this.rangeTimers.set(securityId, timer);
  }

  private resolveTimeframeId(securityId: number): number | null {
    if (this.timeframeId != null && Number.isFinite(Number(this.timeframeId))) {
      return Number(this.timeframeId);
    }
    const fromTrade = this.trades.find((t) => t.security_id === securityId)?.timeframe_id;
    if (fromTrade != null && Number.isFinite(Number(fromTrade))) {
      return Number(fromTrade);
    }
    const any = this.trades.find((t) => t.timeframe_id != null)?.timeframe_id;
    return any != null ? Number(any) : null;
  }

  private rebuildPaperCache(opts: { reloadCharts: boolean } = { reloadCharts: false }): void {
    this.paperRows = papersWithTrades(
      this.trades,
      this.dateFrom,
      this.dateTo,
      this.pinnedPaper
    );
    const undMap = new Map(
      (this.logicSecurities || [])
        .filter((s) => s.underlying_security_id != null)
        .map((s) => [
          Number(s.security_id),
          {
            underlying_security_id: Number(s.underlying_security_id),
            underlying_security_name: s.underlying_security_name ?? null,
            underlying_prefix: s.underlying_prefix ?? null,
          },
        ])
    );
    for (const paper of this.paperRows) {
      const und = undMap.get(Number(paper.security_id));
      if (!und) continue;
      paper.underlying_security_id = und.underlying_security_id;
      paper.underlying_security_name = und.underlying_security_name;
      paper.underlying_prefix = und.underlying_prefix;
    }
    if (this.expandedPapers) {
      this.refreshOpenMarkValues();
    }
    for (const paper of this.paperRows) {
      const secTrades = tradesForSecurity(
        this.trades,
        paper.security_id,
        this.dateFrom,
        this.dateTo
      );
      const fingerprint = paperTradesFingerprint(secTrades);
      const prevFp = this.overlayFingerprintBySec.get(paper.security_id);
      const prev = this.overlaysBySec.get(paper.security_id);
      if (prev && prevFp === fingerprint && !opts.reloadCharts) {
        continue;
      }
      const next = {
        markers: buildTradeMarkers(secTrades),
        stops: buildStopMarkers(secTrades),
        shaded: buildShadedDisabledRanges(secTrades, this.dateFrom, this.dateTo),
        equity: buildEquityPoints(secTrades, this.dateFrom),
        equityLong: buildEquityPoints(secTrades, this.dateFrom, 'long'),
        equityShort: buildEquityPoints(secTrades, this.dateFrom, 'short'),
        equityShadow: buildShadowEquityPoints(secTrades, this.dateFrom),
      };
      this.overlayFingerprintBySec.set(paper.security_id, fingerprint);
      // Poll ~2с не должен подменять ссылки overlays → лишний redraw / ResizeObserver.
      if (
        prev &&
        prev.markers.length === next.markers.length &&
        prev.stops.length === next.stops.length &&
        prev.shaded.length === next.shaded.length &&
        prev.equity.length === next.equity.length &&
        prev.equityLong.length === next.equityLong.length &&
        prev.equityShort.length === next.equityShort.length &&
        prev.equityShadow.length === next.equityShadow.length &&
        prevFp === fingerprint
      ) {
        continue;
      }
      this.overlaysBySec.set(paper.security_id, next);
    }
    // Во время прогона poll обновляет trades каждые ~2с — график не сбрасываем,
    // иначе UI «зависает», а тест выглядит остановленным.
    for (const securityId of this.expandedSecurityIds) {
      const st = this.charts.get(securityId);
      if (!st) continue;
      if (opts.reloadCharts) {
        this.paperStopPlay(securityId);
        this.paperHidePopup(securityId);
        st.candles = [];
        st.indicatorSeries = EMPTY_SERIES;
        st.lastRangeKey = '';
        st.focusDt = null;
        st.error = null;
        st.loading = false;
        st.indicatorsBootstrapped = false;
        st.sliderIndex = 0;
        this.ensureChartLoaded(securityId);
        continue;
      }
      // Обновить статус-строку по новым маркерам без повторного HTTP
      if (st.candles.length > 0 && !st.loading) {
        const ov = this.overlays(securityId);
        st.status = `${st.candles.length} свечей · сделок: ${ov.markers.length} · стопов: ${ov.stops.length}`;
      }
    }
  }

  /** Подтянуть close свечи периода/рынка → «в портф.» = |ост.| × цена. */
  private refreshOpenMarkValues(): void {
    this.markPriceSubs.unsubscribe();
    this.markPriceSubs = new Subscription();
    const before = this.markPriceBeforeExclusive();
    for (const paper of this.paperRows) {
      if (paper.open_qty === 0) continue;
      const secId = paper.security_id;
      const tfId = this.resolveTimeframeId(secId);
      if (tfId == null) continue;
      const sub = this.securitiesApi
        .getPrices(secId, tfId, 1, before ?? undefined)
        .pipe(catchError(() => of([] as PriceCandle[])))
        .subscribe((candles) => {
          const px = Number(candles[candles.length - 1]?.close_price);
          if (!Number.isFinite(px) || px <= 0) return;
          const row = this.paperRows.find((r) => r.security_id === secId);
          if (!row || row.open_qty === 0) return;
          applyPaperMarkValue(row, px);
          this.cdr.markForCheck();
        });
      this.markPriceSubs.add(sub);
    }
  }

  /** Upper bound for GET /prices (dt < before): конец периода теста или null (live/latest). */
  private markPriceBeforeExclusive(): string | null {
    if (!this.isLive && this.dateTo) {
      const day = String(this.dateTo).trim().slice(0, 10);
      if (/^\d{4}-\d{2}-\d{2}$/.test(day)) {
        const d = new Date(`${day}T00:00:00.000Z`);
        if (!Number.isNaN(d.getTime())) {
          d.setUTCDate(d.getUTCDate() + 1);
          return `${d.toISOString().slice(0, 10)} 00:00:00`;
        }
      }
    }
    return null;
  }

  private ensureChartLoaded(securityId: number): void {
    const st = this.chartState(securityId);
    const tfId = this.resolveTimeframeId(securityId);
    const t0 = performance.now();
    this.techLog.event(
      this.techLog.logicThreadKey(this.logicId ?? 0, 'paper'),
      'chart.load.start',
      `Старт загрузки графика sec=${securityId} tf=${tfId ?? 'null'}`,
      {
        logicId: this.logicId ?? undefined,
        securityId,
        force: true,
        payload: { tfId, run_id: this.runId },
      }
    );
    if (!tfId) {
      st.error = 'Не задан таймфрейм логики (и нет timeframe_id в сделках)';
      st.status = null;
      st.loading = false;
      this.bumpChartView();
      return;
    }
    // Уже показали свечи — не перезапрашиваем.
    if (st.candles.length > 0) {
      st.loading = false;
      this.bumpChartView();
      return;
    }

    const secTrades = tradesForSecurity(
      this.trades,
      securityId,
      this.dateFrom,
      this.dateTo
    );
    const win = tradeDtWindow(secTrades);
    // Якорь before — конец сделок, не date_to теста (иначе пустой ответ / лишний retry).
    const coverTo = win?.to ?? this.periodCoverTo(null);
    const before = coverTo ? coverTo.replace(' ', 'T') : undefined;
    st.focusDt = win?.from ?? this.dateFrom ?? null;
    const coverFrom = this.periodCoverFrom(win?.from ?? null);

    this.cancelChartLoad(securityId);
    st.loading = true;
    st.error = null;
    st.status = win
      ? `Загрузка свечей ${win.from.slice(0, 10)}…${win.to.slice(0, 10)}`
      : `Загрузка свечей (tf=${tfId})…`;
    this.bumpChartView();

    const sub = this.securitiesApi
      .getPrices(securityId, tfId, INITIAL_CANDLES, before)
      .pipe(
        catchError((err) => {
          st.error = humanizeChartLoadError(err);
          st.loading = false;
          this.techLog.event(
            this.techLog.logicThreadKey(this.logicId ?? 0, 'paper'),
            'chart.load.error',
            st.error || 'error',
            {
              logicId: this.logicId ?? undefined,
              securityId,
              force: true,
              payload: { ms: Math.round(performance.now() - t0) },
            }
          );
          this.bumpChartView();
          return of([] as PriceCandle[]);
        })
      )
      .subscribe({
        next: (rows) => {
          this.techLog.event(
            this.techLog.logicThreadKey(this.logicId ?? 0, 'paper'),
            'chart.load.prices',
            `Получено ${rows.length} свечей`,
            {
              logicId: this.logicId ?? undefined,
              securityId,
              force: true,
              payload: {
                n: rows.length,
                ms: Math.round(performance.now() - t0),
                before: before ?? null,
              },
            }
          );
          if (rows.length === 0 && before) {
            st.status = 'Повторная загрузка свечей без фильтра даты…';
            this.bumpChartView();
            const retry = this.securitiesApi
              .getPrices(securityId, tfId, INITIAL_CANDLES)
              .subscribe({
                next: (retryRows) =>
                  this.finishCandleLoad(
                    securityId,
                    st,
                    retryRows,
                    coverFrom,
                    coverTo,
                    win,
                    t0
                  ),
                error: (err) => {
                  st.loading = false;
                  st.error = humanizeChartLoadError(err);
                  st.status = null;
                  this.bumpChartView();
                },
              });
            this.chartLoadSubs.set(securityId, retry);
            this.subs.add(retry);
            return;
          }
          this.finishCandleLoad(securityId, st, rows, coverFrom, coverTo, win, t0);
        },
        error: () => {
          st.loading = false;
          this.bumpChartView();
        },
      });
    this.chartLoadSubs.set(securityId, sub);
    this.subs.add(sub);
  }

  /** Начало покрытия свечей: первая сделка (не весь date_from теста — иначе десятки HTTP). */
  private periodCoverFrom(firstTradeDt: string | null): string | null {
    return firstTradeDt;
  }

  /** Конец покрытия: date_to или последняя сделка. */
  private periodCoverTo(lastTradeDt: string | null): string | null {
    if (this.dateTo) {
      const d = String(this.dateTo).trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(d)) return `${d} 23:59:59`;
      return d;
    }
    return lastTradeDt;
  }

  /** Показать первую порцию свечей; длинную догрузку не запускаем (она подвешивала UI). */
  private finishCandleLoad(
    securityId: number,
    st: PaperChartState,
    rows: PriceCandle[],
    coverFrom: string | null,
    coverTo: string | null,
    win: { from: string; to: string } | null,
    t0: number
  ): void {
    if (rows.length === 0) {
      st.loading = false;
      st.error = st.error || 'В БД нет свечей для этой бумаги / таймфрейма';
      st.status = null;
      this.bumpChartView();
      return;
    }

    this.applyCandles(securityId, st, rows, coverFrom, coverTo, win, {
      loadIndicators: false,
    });
    this.techLog.event(
      this.techLog.logicThreadKey(this.logicId ?? 0, 'paper'),
      'chart.load.done',
      `График готов: ${st.candles.length} свечей`,
      {
        logicId: this.logicId ?? undefined,
        securityId,
        force: true,
        payload: {
          candles: st.candles.length,
          ms: Math.round(performance.now() - t0),
          chartTick: this.chartTick,
        },
      }
    );
    // Индикаторы не грузим автоматически при развороте — только по жесту pan (userInitiated).
    // Авто-GET + redraw + ResizeObserver подвешивали UI (нельзя свернуть бумагу).
  }

  private applyCandles(
    securityId: number,
    st: PaperChartState,
    rows: PriceCandle[],
    coverFrom: string | null,
    coverTo: string | null,
    win: { from: string; to: string } | null,
    opts: { loadIndicators: boolean } = { loadIndicators: false }
  ): void {
    const clipped = clipCandlesForBacktest(sortCandlesAsc(rows), {
      coverFrom,
      coverTo,
      tradeFrom: win?.from ?? null,
      tradeTo: win?.to ?? null,
      maxCandles: MAX_CANDLES,
    });
    st.candles = clipped;
    st.hasMore = rows.length >= INITIAL_CANDLES - 5;
    st.loading = false;
    st.loadingOlder = false;
    st.sliderIndex = Math.max(0, clipped.length - 1);
    this.paperHidePopup(securityId);
    const ov = this.overlays(securityId);
    st.error = clipped.length === 0 ? 'В БД нет свечей для этой бумаги / таймфрейма' : null;
    st.status =
      clipped.length > 0
        ? `${clipped.length} свечей · сделки: ${ov.markers.length} · стопы: ${ov.stops.length}`
        : null;
    if (!st.focusDt && ov.markers.length > 0) {
      st.focusDt = ov.markers[0].dt;
    }
    st.focusDt = st.candles[st.sliderIndex]?.dt ?? st.focusDt;
    this.charts.set(securityId, st);
    this.bumpChartView();
    if (opts.loadIndicators && clipped.length > 0 && !st.indicatorsBootstrapped) {
      st.indicatorsBootstrapped = true;
      const n = Math.min(clipped.length, 80);
      const startIdx = Math.max(
        0,
        clipped.findIndex((c) => dtKey(c.dt) >= dtKey(st.focusDt || clipped[0].dt)) - 10
      );
      const endIdx = Math.min(clipped.length - 1, startIdx + n - 1);
      this.loadIndicatorValues(securityId, {
        startDt: clipped[Math.max(0, startIdx)].dt,
        endDt: clipped[endIdx].dt,
        count: endIdx - Math.max(0, startIdx) + 1,
        viewStart: Math.max(0, startIdx),
        userInitiated: false,
      });
    }
  }

  /** Только GET indicator-values — без sync POST (не блокируем UI). */
  private loadIndicatorValues(securityId: number, range: ChartVisibleRange): void {
    const tfId = this.resolveTimeframeId(securityId);
    if (!tfId || this.uniqueIndicatorIds.length === 0) {
      const st = this.chartState(securityId);
      st.suppressIndicators = false;
      st.indicatorSeries = EMPTY_SERIES;
      return;
    }
    if (!range.startDt || !range.endDt) return;
    const st = this.chartState(securityId);
    if (st.candles.length === 0) return;

    const rangeKey = `${range.startDt}|${range.endDt}|${this.uniqueIndicatorIds.join(',')}`;
    if (rangeKey === st.lastRangeKey && st.indicatorSeries.length > 0 && !range.userInitiated) {
      st.suppressIndicators = false;
      return;
    }

    const syncGen = ++st.syncGen;
    const approxLines = Math.max(2, this.uniqueIndicatorIds.length * 3);
    const rowBudget = Math.min(4000, Math.max(400, (range.count || 120) * approxLines));
    const sub = this.securitiesApi
      .getIndicatorValues(
        securityId,
        tfId,
        this.uniqueIndicatorIds,
        range.startDt,
        range.endDt,
        rowBudget
      )
      .pipe(
        // Timeout при перемотке — тихо, без баннера на графике
        catchError(() => of([] as IndicatorValueRow[]))
      )
      .subscribe({
        next: (values) => {
          if (syncGen !== st.syncGen) return;
          if (values.length > 0) {
            st.indicatorSeries = this.buildChartSeries(values);
            st.lastRangeKey = rangeKey;
          }
          st.suppressIndicators = false;
          this.bumpChartView();
        },
      });
    this.subs.add(sub);
  }

  private buildChartSeries(values: IndicatorValueRow[]): ChartIndicatorSeries[] {
    const groups = new Map<string, IndicatorValueRow[]>();
    for (const v of values) {
      if (!this.uniqueIndicatorIds.includes(v.indicator_id)) continue;
      const key = `${v.indicator_id}:${v.line_code}`;
      const list = groups.get(key) ?? [];
      list.push(v);
      groups.set(key, list);
    }
    const series: ChartIndicatorSeries[] = [];
    let colorIdx = 0;
    for (const key of groups.keys()) {
      const rows = groups.get(key)!;
      const sample = rows[0];
      const onPrice =
        (PRICE_SCALE_CODES.has(sample.indicator_code) && sample.line_code === 'VALUE') ||
        // Канальные индикаторы (BB, LINREG, SQUARE) — линии вокруг цены (#836).
        ['UPPER', 'MIDDLE', 'LOWER'].includes(sample.line_code);
      series.push({
        indicator_code: sample.indicator_code,
        line_code: sample.line_code,
        line_name: sample.line_name,
        color: SERIES_COLORS[colorIdx % SERIES_COLORS.length],
        on_price_scale: onPrice,
        is_threshold: sample.is_threshold,
        points: rows.map((r) => ({ dt: r.dt, value: Number(r.value) })),
      });
      if (!sample.is_threshold) colorIdx += 1;
    }
    return series;
  }
}
