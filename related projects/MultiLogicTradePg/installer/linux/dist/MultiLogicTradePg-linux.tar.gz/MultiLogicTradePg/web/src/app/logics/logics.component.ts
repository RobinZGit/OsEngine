import { Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Subject, exhaustMap, takeUntil, timer, forkJoin, of, timeout } from 'rxjs';
import { catchError, debounceTime, filter, finalize, map } from 'rxjs/operators';
import {
  BacktestReportListItem,
  LightningDiagnostics,
  LogicsService,
  TradeRunnerHealth,
} from '../services/logics.service';
import { ReferencesService } from '../services/references.service';
import { SecuritiesService } from '../services/securities.service';
import { SettingsService } from '../services/settings.service';
import { TechLogService } from '../services/tech-log.service';
import { BacktestUiStateService } from '../services/backtest-ui-state.service';
import { LogicIndicatorSignalRow, LogicRow, LogicSecurityRow, LogicStopRow, LogicParamsResponse, NonTradingPeriodsMode } from '../models/logic.model';
import { IndicatorRow } from '../models/lookup.model';
import { SecurityRow } from '../models/market.model';
import {
  AppConfigService,
  logicsLoadErrorMessage,
} from '../services/app-config.service';
import {
  LogicEditorComponent,
  LogicEditorMode,
} from '../logic-editor/logic-editor.component';
import { TbankTokenDialogComponent } from '../tbank-token-dialog/tbank-token-dialog.component';
import {
  applySignalTf,
  buildLogicSignalFormula,
  extractSignalTf,
  parseSignalFormula,
  positionEventLabel,
  PositionEvent,
  positionSideLabel,
  PositionSide,
  signalKindLabel,
  SignalKind,
} from '../shared/signal-formula';
import { buildSignalFormulaHelp } from '../shared/indicator-formula-help';
import {
  applyStrictnessToFormula,
  formulaParamValues,
  IndicatorParamBound,
  strictnessPositionFromFormula,
  strictnessRowBackground,
} from './signal-strictness';
import {
  LOGIC_STOP_UNITS,
  LogicStopRuleKind,
  LogicStopScopeType,
  LogicStopValueUnit,
  isStopScopeChoosable,
  ruleKindLabel,
  scopeTypeLabel,
  stopScopesForRuleKind,
  valueUnitLabel,
} from '../shared/logic-stop';
import {
  costMethodLabel,
  tradeOperationHint,
  tradeOperationLabel,
  tradeStatusLabel,
  yesNoLabel,
  LogicTradeLotRow,
  LogicTradeRow,
} from '../shared/logic-trade';
import { formatDateRangeLabel, formatHumanDate } from '../shared/date-format';
import {
  BacktestRunStatus,
  LogicPositionsPanelComponent,
} from './logic-positions-panel.component';
import { LogicCombatSignalDetailComponent } from './logic-combat-signal-detail.component';
import {
  buildImportFailureModel,
  buildImportLocalErrorModel,
  buildImportSuccessModel,
  ImportDialogModel,
} from './import-protocol';
import type {
  LogicExportBundle,
  ProcessStatusItem,
  SignalRatingPrecalcStatus,
} from '../services/logics.service';

const POLL_INTERVAL_MS = 2000;

/** Сколько ждать готовности отчёта прогона при автооткрытии после теста. */
const AUTO_REPORT_ARCHIVE_RETRIES = 10;
const AUTO_REPORT_ARCHIVE_RETRY_DELAY_MS = 1500;

type SignalPickerState = {
  logicId: number;
  positionEvent: PositionEvent;
  positionSide: PositionSide;
  signalKind: SignalKind;
  /** #1012: id редактируемого сигнала; null/undefined — режим добавления. */
  editSignalId?: number;
} | null;

type StopFormState = {
  logicId: number;
  ruleKind: LogicStopRuleKind;
} | null;

type StopFormDraft = {
  scope_type: LogicStopScopeType;
  value: string;
  value_unit: LogicStopValueUnit;
};

@Component({
  selector: 'app-logics',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    LogicEditorComponent,
    TbankTokenDialogComponent,
    LogicPositionsPanelComponent,
    LogicCombatSignalDetailComponent,
  ],
  templateUrl: './logics.component.html',
  styleUrl: './logics.component.css',
})
export class LogicsComponent implements OnInit, OnDestroy {
  @ViewChild('logicImportFile') logicImportFile?: ElementRef<HTMLInputElement>;
  @ViewChild('copyLogicNameInput') copyLogicNameInput?: ElementRef<HTMLInputElement>;

  logics: LogicRow[] = [];

  /** По умолчанию показываем все реальные + N последних протестированных; остальные скрыты до «Показать все». */
  showAllLogics = false;
  /** Сколько последних по дате теста тестовых логик показывать в свёрнутом виде. */
  readonly defaultTestLogicsVisible = 3;

  /** Активная колонка сортировки списка логик (null = сортировка по умолчанию). */
  sortColumn: 'id' | 'name' | 'enabled' | 'signal' | 'combat_pnl' | 'test_pnl' | null = null;
  /** Направление сортировки активной колонки. */
  sortDir: 'asc' | 'desc' = 'asc';

  loading = true;
  error: string | null = null;
  pollIntervalMs = POLL_INTERVAL_MS;
  /** Состояние торгового цикла (watchdog) для зелёного/красного чекбокса. */
  tradeRunnerHealth: TradeRunnerHealth | null = null;
  private tradeWatchdogNudgeAt = 0;

  /** Checkbox selection for export (right column). */
  selectedExportIds = new Set<number>();
  exportImportBusy = false;
  /** Import result dialog: summary, errors and full protocol (toggle). */
  importDialogOpen = false;
  importDialog: ImportDialogModel | null = null;
  importProtocolOpen = false;
  importProtocolCopied = false;
  /** Busy keys: `${logicId}:test` | `${logicId}:live` for trades JSON export. */
  private tradesExportBusy = new Set<string>();

  editorOpen = false;
  editorMode: LogicEditorMode = 'add';
  editorLogic: LogicRow | null = null;

  expandedLogics = new Set<number>();
  expandedParamsBlocks = new Set<number>();
  expandedSignalsBlocks = new Set<number>();
  /** key = `${logicId}:${signalId}` — раскрытие сигнала → бумаги → график боя */
  expandedCombatSignals = new Set<string>();
  ratingPrecalcByLogic = new Map<number, SignalRatingPrecalcStatus>();
  combatRatingReloadToken = new Map<number, number>();
  private ratingPrecalcPollIds = new Set<number>();
  expandedStopsBlocks = new Set<number>();
  expandedPeriodsBlocks = new Set<number>();
  expandedSecuritiesBlocks = new Set<number>();
  expandedTradesBlocks = new Set<number>();
  expandedTestTradesBlocks = new Set<number>();
  expandedOpenPositionsBlocks = new Set<number>();
  expandedClosedPositionsBlocks = new Set<number>();
  expandedTradeRows = new Set<number>();
  logicSignals = new Map<number, LogicIndicatorSignalRow[]>();
  logicStops = new Map<number, LogicStopRow[]>();
  logicSecurities = new Map<number, LogicSecurityRow[]>();
  logicTrades = new Map<number, LogicTradeRow[]>();
  /** Live rejected orders (separate from open/close list). */
  logicRejectedTrades = new Map<number, LogicTradeRow[]>();
  /** Live reject burst banner (from /logic-trades/reject-alert). */
  logicRejectAlerts = new Map<
    number,
    { warn: boolean; rejected_count: number; message: string | null }
  >();
  logicTradesTest = new Map<number, LogicTradeRow[]>();
  /**
   * Live champion equity from /equity-curve while test panel is open
   * (full trade dump is skipped mid-run).
   */
  testEquityByLogic = new Map<
    number,
    {
      total: Array<{ dt: string; value: number }>;
      long: Array<{ dt: string; value: number }>;
      short: Array<{ dt: string; value: number }>;
      run_id?: number | null;
      financial_result?: number;
    }
  >();
  private testEquityInFlight = new Set<number>();
  /** Last equity fetch start time — allow retry if hung past timeout. */
  private testEquityStartedAt = new Map<number, number>();
  /** Стабильные ссылки для шаблона (без filter на каждый CD). */
  private testTradesViewByLogic = new Map<number, LogicTradeRow[]>();
  private signalIndicatorIdsByLogic = new Map<number, number[]>();
  /** Shared with BacktestUiStateService — survives leaving /operations. */
  backtestRuns: Map<number, BacktestRunStatus>;
  private backtestPollIds: Set<number>;
  /** Пока открыт диалог периода — не дёргать тяжёлый poll (дата на input лагает). */
  uiInteractionPause = false;
  private pollTick = 0;
  private testPnlInFlight = false;
  private combatPnlInFlight = false;
  processRows: ProcessStatusItem[] = [];
  processError: string | null = null;

  /** Archived backtest reports viewer (PostgreSQL). */
  reportsOpen = false;
  reportsLoading = false;
  reportsError: string | null = null;
  reportList: BacktestReportListItem[] = [];
  currentReportId: number | null = null;
  currentReportMeta: BacktestReportListItem | null = null;
  reportHtmlSafe: SafeHtml | null = null;
  reportPrevId: number | null = null;
  reportNextId: number | null = null;
  reportNavBusy = false;
  /** Диалог копирования логики: имя и примечание новой логики. */
  copyDialogOpen = false;
  copyDialogSource: LogicRow | null = null;
  copyDialogName = '';
  copyDialogNote = '';
  copyDialogBusy = false;
  copyDialogError: string | null = null;
  /** Онлайн-сводка тестового финреза по логикам (не колонка в БД). */
  testPnlByLogic: Map<
    number,
    {
      financial_result: number;
      commission: number;
      trade_count: number;
      date_from?: string | null;
      date_to?: string | null;
    }
  >;
  /** Онлайн-сводка боевого финреза (is_test=0). */
  combatPnlByLogic = new Map<
    number,
    { financial_result: number; commission: number; trade_count: number }
  >();
  logicTradeLots = new Map<number, LogicTradeLotRow[]>();
  signalsLoading = new Set<number>();
  stopsLoading = new Set<number>();
  securitiesLoading = new Set<number>();
  periodsLoading = new Set<number>();
  periodsApplying = new Set<number>();
  nonTradingByLogic = new Map<
    number,
    {
      non_trading_periods_mode: NonTradingPeriodsMode;
      use_non_trading_periods: boolean;
      intervals: {
        id: number;
        day_of_week: number;
        time_from: string;
        time_to: string;
        note?: string | null;
      }[];
    }
  >();
  periodsSaving = new Set<number>();
  readonly weekDayLabels = [
    { dow: 1, label: 'Пн' },
    { dow: 2, label: 'Вт' },
    { dow: 3, label: 'Ср' },
    { dow: 4, label: 'Чт' },
    { dow: 5, label: 'Пт' },
    { dow: 6, label: 'Сб' },
    { dow: 7, label: 'Вс' },
  ];
  tradesLoading = new Set<number>();
  private testTradesInFlight = new Set<number>();
  private liveTradesInFlight = new Set<number>();
  tradeLotsLoading = new Set<number>();
  closeAllLoading = new Set<number>();

  readonly costMethodOptions: Array<{ value: 'FIFO' | 'AVERAGE'; label: string }> = [
    { value: 'FIFO', label: 'FIFO (первая покупка — первая продажа)' },
    { value: 'AVERAGE', label: 'Средняя цена остатка' },
  ];

  indicatorsCatalog: IndicatorRow[] = [];
  indicatorsLoaded = false;

  signalPicker: SignalPickerState = null;
  pickerSelectedIds = new Set<number>();

  securityPickerLogicId: number | null = null;
  pickerSelectedSecurityIds = new Set<number>();
  stocksCatalog: SecurityRow[] = [];
  futuresCatalog: SecurityRow[] = [];
  fundsCatalog: SecurityRow[] = [];
  securitiesCatalogLoaded = false;
  securitiesCatalogLoading = false;
  moexExchangeId: number | null = null;

  stopForm: StopFormState = null;
  stopFormDraft: StopFormDraft = {
    scope_type: 'security_resume',
    value: '',
    value_unit: 'percent',
  };

  readonly stopUnits = LOGIC_STOP_UNITS;
  stopScopesFor = stopScopesForRuleKind;
  isStopScopeChoosable = isStopScopeChoosable;

  tbankTokenDialogOpen = false;
  tbankTokenDialogContext: 'prices' | 'logic' | 'trades' = 'logic';
  tbankTokenDialogReason: 'missing' | 'invalid' = 'missing';
  /** Постоянное предупреждение у блока «Сделки», пока токен невалиден и логика включена. */
  tbankTokenAlert: { reason: 'missing' | 'invalid'; message: string } | null = null;
  private pendingEnableLogic: LogicRow | null = null;
  private pendingBacktest: {
    logicId: number;
    period: {
      date_from: string;
      date_to: string;
      slippage_pct?: number;
      opt_grid?: {
        config?: unknown;
        arms?: { lane: string; values: Record<string, number> }[];
      } | null;
    };
  } | null = null;
  private lastTbankTokenCheckAt = 0;
  private readonly tbankTokenCheckMs = 30000;

  private readonly destroy$ = new Subject<void>();
  /** Logic ids that were mid-backtest — used to detect finish after pollIds drop. */
  private backtestWasRunning = new Set<number>();
  private savingIds = new Set<number>();
  savingSignalIds = new Set<number>();
  private formulaDrafts = new Map<number, string>();
  /** #1030: границы параметров индикаторов для ползунка «строже/мягче». */
  private indicatorBoundsByCode = new Map<string, IndicatorParamBound[]>();
  private savingFormulaIds = new Set<number>();
  /** Сигналы с открытой справкой «?» по формуле. */
  private signalFormulaHelpIds = new Set<number>();
  /** Логики с открытой справкой «?» в шапке блока «Сигналы логики и стоп-лосс и тейк-профит» (#831). */
  private signalsHelpBlocks = new Set<number>();
  /** Логики с раскрытой справкой по алгоритму «Авто оптимизация». */
  private autoOptHelpBlocks = new Set<number>();
  private signalFormulaHelpCache: string | null = null;
  private savingStopIds = new Set<number>();
  private savingParamsIds = new Set<number>();
  private copyingLogicIds = new Set<number>();
  private optResettingIds = new Set<number>();
  private shadowResettingIds = new Set<number>();
  paramsDrafts = new Map<
    number,
    {
      name: string;
      timeframe: string;
      position_size_base: 'free_cash' | 'portfolio' | 'portfolio_incl_fund';
      position_size_pct: string;
      max_open_positions: string;
      max_order_amount: string;
      order_gap_buffer_pct: string;
      max_open_gap_pct: string;
      initial_balance: string;
      test_initial_balance: string;
      commission_pct: string;
      cost_method: 'FIFO' | 'AVERAGE';
      stop_loss_timeframe: string;
      base_annual_rate_pct: string;
      rating_lookback_days: string;
      inversion: boolean;
      warmup_pretest: boolean;
      auto_optimize: boolean;
      resume_sl_no_reduce: boolean;
      cash_fund_code: string;
      cash_fund_threshold: string;
      use_non_trading_periods: boolean;
      non_trading_periods_mode: NonTradingPeriodsMode;
      close_positions_eod: boolean;
      sell_futures_before_expiry: boolean;
      sell_futures_days_before_expiry: string;
      order_execution: 'market' | 'limit';
      opt_eval_candles: string;
      reset_balance: boolean;
    }
  >();
  paramsSaveErrors = new Map<number, string>();
  paramsLoading = new Set<number>();
  timeframesCatalog: { id: number; tf: string; full_name: string }[] = [];

  /** Изменяемая ширина колонок списка логик (тянуть за правый край заголовка). */
  readonly columnWidthsStorageKey = 'logics.columnWidths.v1';
  readonly columnMinWidthPx = 36;
  readonly columnMaxWidthPx = 900;
  columnWidths: Record<string, number> = this.loadColumnWidths();
  private columnResizeState: { key: string; startX: number; startWidth: number } | null =
    null;

  private loadColumnWidths(): Record<string, number> {
    try {
      const raw = localStorage.getItem('logics.columnWidths.v1');
      const parsed = raw ? JSON.parse(raw) : {};
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch {
      return {};
    }
  }

  private saveColumnWidths(): void {
    try {
      localStorage.setItem(this.columnWidthsStorageKey, JSON.stringify(this.columnWidths));
    } catch {
      /* приватный режим / нет места — ширины просто не сохранятся */
    }
  }

  thWidth(col: string): number | null {
    return this.columnWidths[col] ?? null;
  }

  startColumnResize(event: MouseEvent, col: string): void {
    event.preventDefault();
    event.stopPropagation();
    const th = (event.target as HTMLElement).closest('th') as HTMLTableCellElement | null;
    if (!th) return;
    this.columnResizeState = {
      key: col,
      startX: event.clientX,
      startWidth: th.getBoundingClientRect().width,
    };
    const onMove = (e: MouseEvent): void => this.onColumnResizeMove(e);
    const onUp = (): void => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      this.columnResizeState = null;
      this.saveColumnWidths();
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  }

  private onColumnResizeMove(e: MouseEvent): void {
    const st = this.columnResizeState;
    if (!st) return;
    const width = Math.min(
      this.columnMaxWidthPx,
      Math.max(this.columnMinWidthPx, Math.round(st.startWidth + (e.clientX - st.startX)))
    );
    this.columnWidths = { ...this.columnWidths, [st.key]: width };
  }

  resetColumnWidth(col: string): void {
    if (!(col in this.columnWidths)) return;
    const next = { ...this.columnWidths };
    delete next[col];
    this.columnWidths = next;
    this.saveColumnWidths();
  }

  readonly orderExecutionOptions: { value: 'market' | 'limit'; label: string }[] = [
    { value: 'market', label: 'По рынку' },
    { value: 'limit', label: 'Лимитная' },
  ];
  readonly cashFundOptions: { value: string; label: string }[] = [
    { value: '', label: 'Не покупать' },
    { value: 'TMON', label: 'TMON — Т-Капитал денежный рынок' },
    { value: 'LQDT', label: 'LQDT — ВИМ Ликвидность' },
    { value: 'SBMM', label: 'SBMM — Сбер Первый' },
  ];
  /** Пользователь менял черновик — poll не перезаписывает поля ввода. */
  private paramsDirtyIds = new Set<number>();

  constructor(
    private readonly logicsService: LogicsService,
    private readonly refs: ReferencesService,
    private readonly securitiesService: SecuritiesService,
    private readonly settings: SettingsService,
    private readonly techLog: TechLogService,
    private readonly appConfig: AppConfigService,
    private readonly backtestUi: BacktestUiStateService,
    private readonly sanitizer: DomSanitizer,
    private readonly cdr: ChangeDetectorRef
  ) {
    this.backtestRuns = this.backtestUi.runs;
    this.backtestPollIds = this.backtestUi.pollIds;
    this.testPnlByLogic = this.backtestUi.testPnlByLogic;
  }

  ngOnInit(): void {
    this.loadIndicatorBounds();
    this.backtestUi.attach();
    for (const logicId of this.backtestUi.expandTestBlocks) {
      this.expandedTestTradesBlocks.add(logicId);
      this.expandedLogics.add(logicId);
    }
    // Status poll owns BacktestUiStateService; here only light UI after debounced bumps.
    this.backtestUi.changes$.pipe(debounceTime(300), takeUntil(this.destroy$)).subscribe(() => {
      const watchIds = new Set<number>([
        ...this.backtestPollIds,
        ...this.backtestWasRunning,
        ...this.backtestRuns.keys(),
      ]);
      for (const logicId of watchIds) {
        const testing = this.isBacktestRunning(logicId);
        const was = this.backtestWasRunning.has(logicId);
        if (testing) {
          this.backtestWasRunning.add(logicId);
        } else if (was) {
          this.backtestWasRunning.delete(logicId);
          this.onBacktestJustFinished(logicId);
        }
        const testOpen = this.expandedTestTradesBlocks.has(logicId);
        if (!testing) {
          this.loadTestTradesForLogic(logicId, true);
          this.refreshTestPnlSummary();
          this.refreshOptGridAvailability(logicId);
        } else if (testOpen) {
          this.loadTestTradesPanelForLogic(logicId);
        }
        if (testOpen) {
          this.loadTestEquityForLogic(logicId);
        }
        this.rebuildTestTradesView(logicId);
      }
      this.cdr.markForCheck();
    });
    this.loadIndicatorsCatalog();
    this.loadMoexExchangeId();
    this.securitiesService.getTimeframes().subscribe({
      next: (rows) => {
        this.timeframesCatalog = rows.filter((r) => r.is_active !== false);
      },
    });
    timer(0, POLL_INTERVAL_MS)
      .pipe(
        takeUntil(this.destroy$),
        // Не крутить /logics+trades пока вкладка скрыта (route reuse держит компонент живым).
        filter(() => typeof document === 'undefined' || !document.hidden),
        // exhaustMap: не отменять и не накладывать GET /logics, пока предыдущий в полёте.
        exhaustMap(() => {
          // Редактор логики / диалог периода — не дергать список (иначе select «висит»).
          if (this.editorOpen || this.uiInteractionPause) {
            return of(null);
          }
          return forkJoin({
            logics: this.logicsService.getLogics().pipe(
              catchError((err) => {
                if (this.loading || this.logics.length === 0) {
                  this.error = logicsLoadErrorMessage(this.appConfig.apiUrl, err);
                }
                this.loading = false;
                return of(null);
              })
            ),
            health: this.logicsService.getTradeRunnerHealth().pipe(
              catchError(() => of(null))
            ),
          });
        })
      )
      .subscribe({
        next: (pack) => {
          // Диалог / редактор: статус теста крутит BacktestUiStateService — список не трогаем.
          if (pack == null || this.uiInteractionPause || this.editorOpen) {
            return;
          }
          const rows = pack.logics;
          if (pack.health) {
            this.tradeRunnerHealth = pack.health;
            this.maybeNudgeTradeWatchdog(pack.health);
          }
          if (rows == null) {
            return;
          }
          this.logics = rows.map((row) => {
            if (this.savingIds.has(row.id)) {
              const local = this.logics.find((x) => x.id === row.id);
              return local ? { ...row, is_enabled: local.is_enabled } : row;
            }
            if (this.savingParamsIds.has(row.id) || this.paramsDirtyIds.has(row.id)) {
              const local = this.logics.find((x) => x.id === row.id);
              return local
                ? {
                    ...row,
                    position_size_base: local.position_size_base,
                    position_size_pct: local.position_size_pct,
                    max_open_positions: local.max_open_positions,
                    max_order_amount: local.max_order_amount,
                    initial_balance: local.initial_balance,
                    base_annual_rate_pct: local.base_annual_rate_pct,
                    // current_balance — только для отображения, берём с сервера
                  }
                : row;
            }
            return row;
          });
          this.loading = false;
          this.error = null;
          // Re-sync yellow/progress from DB (covers remount / F5 / lost local map).
          if (this.pollTick % 5 === 0) {
            this.backtestUi.recoverActive();
          }
          // Сделки — read-only, обновляем; редактируемые блоки (параметры, формулы) — нет
          this.refreshAllTradesSummaries();
          this.refreshPnlSummaries();
          this.refreshProcesses();
          this.maybeCheckTbankTokenForTrades();
          this.cdr.markForCheck();
        },
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  signalKindLabel = signalKindLabel;
  positionSideLabel = positionSideLabel;
  positionEventLabel = positionEventLabel;
  ruleKindLabel = ruleKindLabel;
  scopeTypeLabel = scopeTypeLabel;
  valueUnitLabel = valueUnitLabel;
  tradeStatusLabel = tradeStatusLabel;
  yesNoLabel = yesNoLabel;

  isLogicExpanded(id: number): boolean {
    return this.expandedLogics.has(id);
  }

  isParamsBlockExpanded(id: number): boolean {
    return this.expandedParamsBlocks.has(id);
  }

  isSignalsBlockExpanded(id: number): boolean {
    return this.expandedSignalsBlocks.has(id);
  }

  isStopsBlockExpanded(id: number): boolean {
    return this.expandedStopsBlocks.has(id);
  }

  isSecuritiesBlockExpanded(id: number): boolean {
    return this.expandedSecuritiesBlocks.has(id);
  }

  isPeriodsBlockExpanded(id: number): boolean {
    return this.expandedPeriodsBlocks.has(id);
  }

  isTradesBlockExpanded(id: number): boolean {
    return this.expandedTradesBlocks.has(id);
  }

  activeProcesses(): ProcessStatusItem[] {
    const local: ProcessStatusItem[] = [];
    for (const s of this.ratingPrecalcByLogic.values()) {
      if (s.status === 'pending' || s.status === 'running') {
        local.push({
          type: 'angular',
          label: `Rating precalc logic #${s.logic_id}`,
          status: s.status,
          detail: s.phase_message,
          progress_pct: s.progress_pct,
          logic_id: s.logic_id,
        });
      }
    }
    return [...this.processRows, ...local].slice(0, 12);
  }

  hasActiveProcesses(): boolean {
    return this.activeProcesses().length > 0 || !!this.processError;
  }

  processTitle(p: ProcessStatusItem): string {
    return [p.label, p.status, p.detail, p.wait, p.age]
      .filter(Boolean)
      .join(' · ');
  }

  openTestReports(event?: Event): void {
    event?.preventDefault();
    event?.stopPropagation();
    this.reportsOpen = true;
    this.reportsLoading = true;
    this.reportsError = null;
    this.reportList = [];
    this.currentReportId = null;
    this.currentReportMeta = null;
    this.reportHtmlSafe = null;
    this.reportPrevId = null;
    this.reportNextId = null;
    this.logicsService
      .listBacktestReports({ limit: 100 })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          this.reportList = res.rows ?? [];
          this.reportsLoading = false;
          if (this.reportList.length === 0) {
            this.reportsError = 'Пока нет сохранённых отчётов. Завершите тест — отчёт появится здесь.';
            this.cdr.markForCheck();
            return;
          }
          this.loadReportById(this.reportList[0].id);
        },
        error: (err) => {
          this.reportsLoading = false;
          this.reportsError =
            err?.error?.error ?? err?.message ?? 'Не удалось загрузить список отчётов';
          this.cdr.markForCheck();
        },
      });
  }

  closeTestReports(): void {
    this.reportsOpen = false;
    this.reportHtmlSafe = null;
    this.reportNavBusy = false;
  }

  loadReportById(id: number): void {
    if (!id || this.reportNavBusy) return;
    this.reportNavBusy = true;
    this.reportsError = null;
    this.logicsService
      .getBacktestReport(id, true)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          this.currentReportId = res.row.id;
          this.currentReportMeta = res.row;
          this.reportPrevId = res.prev_id;
          this.reportNextId = res.next_id;
          const html = res.row.html_body || '<p>Пустой отчёт</p>';
          this.reportHtmlSafe = this.sanitizer.bypassSecurityTrustHtml(html);
          this.reportNavBusy = false;
          this.cdr.markForCheck();
        },
        error: (err) => {
          this.reportNavBusy = false;
          this.reportsError =
            err?.error?.error ?? err?.message ?? 'Не удалось открыть отчёт';
          this.cdr.markForCheck();
        },
      });
  }

  reportGoOlder(): void {
    if (this.reportPrevId != null) this.loadReportById(this.reportPrevId);
  }

  reportGoNewer(): void {
    if (this.reportNextId != null) this.loadReportById(this.reportNextId);
  }

  selectReportFromList(id: number): void {
    if (id === this.currentReportId) return;
    this.loadReportById(id);
  }

  formatReportListLabel(r: BacktestReportListItem): string {
    const pnl =
      r.net_pnl_pct != null && Number.isFinite(Number(r.net_pnl_pct))
        ? `${Number(r.net_pnl_pct) >= 0 ? '+' : ''}${Number(r.net_pnl_pct).toFixed(1)}%`
        : '—';
    const period =
      r.date_from && r.date_to ? `${r.date_from}…${r.date_to}` : 'без периода';
    return `${r.logic_name} · ${period} · ${pnl}`;
  }

  @HostListener('document:keydown', ['$event'])
  onReportsKeydown(ev: KeyboardEvent): void {
    if (this.importDialogOpen) {
      if (ev.key === 'Escape') {
        ev.preventDefault();
        this.closeImportDialog();
        this.cdr.markForCheck();
      }
      return;
    }
    if (!this.reportsOpen) return;
    if (ev.key === 'Escape') {
      ev.preventDefault();
      this.closeTestReports();
      return;
    }
    if (ev.key === 'ArrowLeft') {
      ev.preventDefault();
      this.reportGoOlder();
      return;
    }
    if (ev.key === 'ArrowRight') {
      ev.preventDefault();
      this.reportGoNewer();
    }
  }

  toggleLogicExpand(row: LogicRow, event: Event): void {
    const target = event.target as HTMLElement;
    if (
      target.closest('button, input, a, .col-actions, .logic-signals-panel')
    ) {
      return;
    }
    if (this.expandedLogics.has(row.id)) {
      this.collapseLogic(row.id);
      return;
    }
    this.expandedLogics.add(row.id);
    this.ensureParamsDraft(row.id);
    // Подблоки при раскрытии логики НЕ раскрываем — начинают свёрнутыми,
    // и их ручное раскрытие не сохраняется между сворачиванием/раскрытием логики.
    // Прогреть сигналы/стопы сразу — не ждать открытия блоков.
    this.loadSignalsForLogic(row.id);
    this.loadStopsForLogic(row.id);
    this.refreshOptGridAvailability(row.id);
  }

  /** Collapse expanded logic (same as clicking the row when open). */
  collapseLogic(logicId: number, event?: Event): void {
    event?.preventDefault();
    event?.stopPropagation();
    this.expandedLogics.delete(logicId);
    this.expandedParamsBlocks.delete(logicId);
    this.paramsDirtyIds.delete(logicId);
    this.expandedSignalsBlocks.delete(logicId);
    this.expandedStopsBlocks.delete(logicId);
    this.expandedSecuritiesBlocks.delete(logicId);
    this.expandedPeriodsBlocks.delete(logicId);
    this.expandedTradesBlocks.delete(logicId);
    this.expandedOpenPositionsBlocks.delete(logicId);
    this.expandedClosedPositionsBlocks.delete(logicId);
    this.expandedTestTradesBlocks.delete(logicId);
    for (const tr of this.tradesFor(logicId)) {
      this.expandedTradeRows.delete(tr.id);
    }
    this.closeSignalPicker();
    this.closeStopForm();
    this.closeSecurityPicker();
  }

  /** Name shown in expanded header / table while editing draft. */
  displayLogicName(row: LogicRow): string {
    const draft = this.paramsDrafts.get(row.id);
    const fromDraft = draft?.name?.trim();
    return fromDraft || row.name || `Логика #${row.id}`;
  }

  /**
   * Бейдж только при portfolio_trading_paused (весь портфель).
   * Пауза отдельных бумаг (теневой режим по бумаге) сюда не попадает.
   */
  portfolioShadowBadgeText(row: LogicRow): string {
    if (row.has_portfolio_ltp_renew && !row.has_portfolio_resume_sl) {
      return 'реал пауза: линейный TP портфеля → тень до возобновления';
    }
    if (row.has_portfolio_resume_sl && !row.has_portfolio_ltp_renew) {
      return 'реал пауза: стоп портфеля → тень до возобновления';
    }
    if (row.has_portfolio_ltp_renew && row.has_portfolio_resume_sl) {
      return 'реал пауза: TP/стоп портфеля → тень до возобновления';
    }
    return 'реал пауза: портфель в тени до возобновления';
  }

  portfolioShadowBadgeTitle(row: LogicRow): string {
    const parts: string[] = [
      'Весь портфель: реальные заявки остановлены, идут только теневые (бумажные) сделки до восстановления equity.',
      'Не путать с «теневой режим» у отдельных бумаг (их бейджи только в списке бумаг).',
    ];
    if (row.has_portfolio_ltp_renew) {
      parts.push(
        'Причина может быть линейный take-profit по портфелю с возобновлением (portfolio_ltp_renew).'
      );
    }
    if (row.has_portfolio_resume_sl) {
      parts.push(
        'Причина может быть стоп-лосс по портфелю с возобновлением (portfolio_resume).'
      );
    }
    return parts.join(' ');
  }

  /** Класс чекбокса «включено»: зелёный пульс (ок) / красный (цикл спит или тень портфеля). */
  enableCheckClass(row: LogicRow): Record<string, boolean> {
    if (!row.is_enabled) {
      return { 'enable-check': true };
    }
    if (row.portfolio_trading_paused) {
      return {
        'enable-check': true,
        'enable-check--stale': true,
      };
    }
    const alive = this.isLogicTradeAlive(row);
    return {
      'enable-check': true,
      'enable-check--ok': alive === true,
      'enable-check--stale': alive === false,
    };
  }

  enableCheckTitle(row: LogicRow): string {
    if (!row.is_enabled) {
      return 'Логика выключена';
    }
    if (row.portfolio_trading_paused) {
      return (
        'Реал-торговля портфеля на паузе (тень до возобновления). ' +
        'Чекбокс красный — это нормально, пока весь портфель в shadow.'
      );
    }
    const alive = this.isLogicTradeAlive(row);
    const h = this.tradeRunnerHealth;
    if (alive === true) {
      return (
        `Торговый цикл работает` +
        `${h?.last_ok_at ? ` (last OK ${h.last_ok_at})` : ''}. ` +
        `Цвет чекбокса = heartbeat runner (~15 с), не таймфрейм логики и не момент сделки.`
      );
    }
    if (h?.status === 'ui_required') {
      return 'Торговля остановлена: нужен открытый UI (APP_TRADE_RUNNER_REQUIRE_UI)';
    }
    return `Торговля остановлена или цикл спит${
      h?.age_sec != null ? ` (${Math.round(h.age_sec)} с без OK)` : ''
    }. Watchdog пытается поднять.`;
  }

  showTradeStoppedBadge(row: LogicRow): boolean {
    if (!row.is_enabled) return false;
    if (row.portfolio_trading_paused) return true;
    return this.isLogicTradeAlive(row) === false;
  }

  tradeStoppedBadgeText(row: LogicRow): string {
    const acc = row.account_type === 'real' ? 'бой' : 'фейк';
    if (row.portfolio_trading_paused) {
      return `торговля остановлена: тень портфеля (${acc})`;
    }
    const h = this.tradeRunnerHealth;
    if (h?.status === 'ui_required') {
      return 'торговля остановлена: нет UI';
    }
    return `торговля остановлена (${acc})`;
  }

  /**
   * Green/red = trade-runner heartbeat (~15s), NOT logic timeframe / last trade.
   * M15 (and slower TFs) may wait many minutes between bars — that must not paint red.
   */
  private isLogicTradeAlive(row: LogicRow): boolean | null {
    if (!row.is_enabled) return null;
    const h = this.tradeRunnerHealth;
    if (!h) return null;
    if (h.status === 'idle') return null;
    if (h.node_running) return true;
    if (h.status === 'ok') return true;
    if (h.status === 'ui_required') return false;
    if (h.status === 'stale' || h.stale) {
      // Fallback only when global LAST_OK lagged: recent cycle touch on this logic.
      const per = this.logicHealthEntry(row);
      if (per && per.stale === false) return true;
      return false;
    }
    return null;
  }

  private logicHealthEntry(row: LogicRow): {
    stale?: boolean;
    last_trade_check_at?: string | null;
  } | null {
    const logics = this.tradeRunnerHealth?.logics;
    if (!logics) return null;
    if (Array.isArray(logics)) {
      return (
        (
          logics as Array<{
            id?: number;
            stale?: boolean;
            last_trade_check_at?: string | null;
          }>
        ).find((x) => Number(x.id) === row.id) ?? null
      );
    }
    return logics[String(row.id)] ?? null;
  }

  private maybeNudgeTradeWatchdog(health: TradeRunnerHealth): void {
    if (!health.stale && health.status !== 'stale') return;
    if ((health.enabled_count ?? 0) <= 0) return;
    if (health.status === 'ui_required') return;
    const now = Date.now();
    // Не чаще раза в 45 с — Node watchdog и так крутится; UI только подталкивает.
    if (now - this.tradeWatchdogNudgeAt < 45000) return;
    this.tradeWatchdogNudgeAt = now;
    this.logicsService.raiseTradeRunnerWatchdog().subscribe({ error: () => {} });
  }

  onParamsNameChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).name = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  /** Черновик параметров — всегда объект из Map (не временный литерал). */
  getParamsDraft(logicId: number) {
    this.ensureParamsDraft(logicId);
    return this.paramsDrafts.get(logicId)!;
  }

  paramsSaveError(logicId: number): string | null {
    return this.paramsSaveErrors.get(logicId) ?? null;
  }

  onParamsTimeframeChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).timeframe = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsStopLossTimeframeChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).stop_loss_timeframe = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  private normalizePositionSizeBase(
    value: string | null | undefined
  ): 'free_cash' | 'portfolio' | 'portfolio_incl_fund' {
    if (value === 'portfolio') return 'portfolio';
    if (value === 'portfolio_incl_fund') return 'portfolio_incl_fund';
    return 'free_cash';
  }

  onParamsSizeBaseChange(
    logicId: number,
    value: 'free_cash' | 'portfolio' | 'portfolio_incl_fund'
  ): void {
    this.getParamsDraft(logicId).position_size_base =
      this.normalizePositionSizeBase(value);
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsPctChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).position_size_pct = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsMaxOrderAmountChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).max_order_amount = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsGapBufferChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).order_gap_buffer_pct = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsMaxGapChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).max_open_gap_pct = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  /** Плечо (ед.) = макс. позиций × (% депозита / 100). 1 = весь портфель при полном наборе. */
  lotLeverageUnits(logicId: number): number | null {
    const d = this.paramsDrafts.get(logicId);
    if (!d) return null;
    const pct = this.parseDecimalInput(d.position_size_pct);
    const max = Math.round(this.parseDecimalInput(d.max_open_positions));
    if (!Number.isFinite(pct) || pct <= 0 || !Number.isInteger(max) || max <= 0) {
      return null;
    }
    return (pct / 100) * max;
  }

  formatLotLeverage(logicId: number): string {
    const v = this.lotLeverageUnits(logicId);
    if (v == null) return '—';
    const rounded = Math.round(v * 100) / 100;
    return `${rounded}×`;
  }

  onParamsBaseAnnualRateChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).base_annual_rate_pct = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsRatingLookbackChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).rating_lookback_days = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsMaxPositionsChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).max_open_positions = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsInitialBalanceChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).initial_balance = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsTestInitialBalanceChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).test_initial_balance = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsCommissionPctChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).commission_pct = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsCostMethodChange(logicId: number, value: 'FIFO' | 'AVERAGE'): void {
    this.getParamsDraft(logicId).cost_method = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsResetBalanceChange(logicId: number, value: boolean): void {
    this.getParamsDraft(logicId).reset_balance = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsInversionChange(logicId: number, value: boolean): void {
    this.getParamsDraft(logicId).inversion = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsWarmupPretestChange(logicId: number, value: boolean): void {
    this.getParamsDraft(logicId).warmup_pretest = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsAutoOptimizeChange(logicId: number, value: boolean): void {
    this.getParamsDraft(logicId).auto_optimize = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsResumeSlNoReduceChange(logicId: number, value: boolean): void {
    this.getParamsDraft(logicId).resume_sl_no_reduce = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsCashFundCodeChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).cash_fund_code = String(value ?? '')
      .trim()
      .toUpperCase();
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsCashFundThresholdChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).cash_fund_threshold = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsClosePositionsEodChange(logicId: number, value: boolean): void {
    this.getParamsDraft(logicId).close_positions_eod = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsSellFuturesBeforeExpiryChange(logicId: number, value: boolean): void {
    this.getParamsDraft(logicId).sell_futures_before_expiry = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsSellFuturesDaysBeforeExpiryChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).sell_futures_days_before_expiry = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsOrderExecutionChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).order_execution =
      value === 'limit' ? 'limit' : 'market';
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  onParamsOptEvalCandlesChange(logicId: number, value: string): void {
    this.getParamsDraft(logicId).opt_eval_candles = value;
    this.paramsDirtyIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
  }

  isOptResetting(logicId: number): boolean {
    return this.optResettingIds.has(logicId);
  }

  private optGridBestIds = new Set<number>();
  private optGridApplyingIds = new Set<number>();

  signalFormulasFor(logicId: number): string[] {
    return (this.logicSignals.get(logicId) ?? [])
      .filter((s) => s.is_active !== false)
      .map((s) => s.formula)
      .filter((f) => !!f);
  }

  hasOptGridBest(logicId: number): boolean {
    if (this.optGridBestIds.has(logicId)) return true;
    const r = this.backtestFor(logicId)?.opt_grid_results;
    return Array.isArray(r) && r.length > 0;
  }

  isOptGridApplying(logicId: number): boolean {
    return this.optGridApplyingIds.has(logicId);
  }

  refreshOptGridAvailability(logicId: number): void {
    const local = this.backtestFor(logicId)?.opt_grid_results;
    if (Array.isArray(local) && local.length > 0) {
      this.optGridBestIds.add(logicId);
      this.cdr.markForCheck();
    }
    this.logicsService.getLatestOptGridResults(logicId).subscribe({
      next: (res) => {
        if (res?.run_id && Array.isArray(res.results) && res.results.length > 0) {
          this.optGridBestIds.add(logicId);
        } else if (!(Array.isArray(local) && local.length > 0)) {
          this.optGridBestIds.delete(logicId);
        }
        this.cdr.markForCheck();
      },
      error: () => {
        /* keep local flag if status already has results */
        this.cdr.markForCheck();
      },
    });
  }

  applyOptGridBest(logicId: number, event: Event): void {
    event.stopPropagation();
    if (this.optGridApplyingIds.has(logicId)) return;
    if (!this.hasOptGridBest(logicId)) {
      alert(
        'Нет результатов оптимизации. Сначала завершите тест с галочкой «Оптимизировать».'
      );
      return;
    }
    const ok = confirm(
      'Записать в формулы сигналов лучшие параметры последнего теста с оптимизацией?'
    );
    if (!ok) return;
    this.optGridApplyingIds.add(logicId);
    this.logicsService.applyOptGridBest(logicId).subscribe({
      next: (resp) => {
        this.optGridApplyingIds.delete(logicId);
        if (resp?.ok === false) {
          alert(resp.error || 'Не удалось применить параметры');
          return;
        }
        if (Array.isArray(resp.signals)) {
          this.logicSignals.set(logicId, resp.signals);
          for (const r of resp.signals) {
            this.formulaDrafts.set(r.id, r.formula);
          }
          this.rebuildSignalIndicatorIds(logicId);
        } else {
          this.loadSignalsForLogic(logicId, true);
        }
        if (resp.message) {
          alert(resp.message);
        } else {
          alert(
            `Применено. Обновлено формул: ${resp.updated ?? 0}.`
          );
        }
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.optGridApplyingIds.delete(logicId);
        alert(err?.error?.error || 'Не удалось применить параметры');
      },
    });
  }

  /** After a run leaves active status: enable Apply OPT + refresh trades/results. */
  private onBacktestJustFinished(logicId: number): void {
    const run = this.backtestFor(logicId);
    if (Array.isArray(run?.opt_grid_results) && run!.opt_grid_results!.length > 0) {
      this.optGridBestIds.add(logicId);
    }
    this.refreshOptGridAvailability(logicId);
    this.expandedTestTradesBlocks.add(logicId);
    this.loadTestTradesForLogic(logicId, true);
    this.scheduleAutoOpenRunReport(logicId);
    this.cdr.markForCheck();
  }

  /** Закоммиченный run_id, для которого автооткрытие архива отчёта уже выполнено. */
  private autoOpenedReportRunIds = new Set<number>();

  /** После теста открыть готовый серверный отчёт прогона во встроенном модале (#855/#856). */
  private scheduleAutoOpenRunReport(logicId: number): void {
    const run = this.backtestFor(logicId);
    const runId = run?.id != null ? Number(run.id) : null;
    if (runId == null || !Number.isFinite(runId) || runId <= 0) return;
    if (this.autoOpenedReportRunIds.has(runId)) return;
    const st = String(run?.status ?? '').trim().toLowerCase();
    if (st !== 'completed' && st !== 'cancelled') return;
    this.autoOpenedReportRunIds.add(runId);
    this.openReportsAutoForRun(runId);
  }

  private openReportsAutoForRun(runId: number, attempt = 0): void {
    if (Number.isNaN(Number(runId)) || Number(runId) <= 0) return;
    this.reportsOpen = true;
    this.reportsLoading = true;
    this.reportsError = null;
    this.logicsService
      .listBacktestReports({ limit: 100 })
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (res) => {
          this.reportList = res.rows ?? [];
          this.reportsLoading = false;
          if (this.reportList.length === 0) {
            this.reportsError =
              'Пока нет сохранённых отчётов. Завершите тест — отчёт появится здесь.';
            this.cdr.markForCheck();
            return;
          }
          const found = this.reportList.find(
            (r) => Number(r.run_id) === Number(runId)
          );
          if (found) {
            this.loadReportById(found.id);
            this.cdr.markForCheck();
            return;
          }
          // Отчёт прогона пишется почти одновременно со статусом completed —
          // подождём пару попыток, затем покажем самый свежий.
          if (attempt < AUTO_REPORT_ARCHIVE_RETRIES) {
            window.setTimeout(
              () => this.openReportsAutoForRun(runId, attempt + 1),
              AUTO_REPORT_ARCHIVE_RETRY_DELAY_MS * (attempt + 1)
            );
            return;
          }
          this.loadReportById(this.reportList[0].id);
          this.cdr.markForCheck();
        },
        error: (err) => {
          this.reportsLoading = false;
          this.reportsError =
            err?.error?.error ?? err?.message ?? 'Не удалось загрузить список отчётов';
          this.cdr.markForCheck();
        },
      });
  }

  resetOptParameters(logicId: number): void {
    if (this.optResettingIds.has(logicId)) return;
    const ok = confirm(
      'Сбросить оптимизированные параметры к начальным значениям и очистить бумажную книгу OPT (opt_lane)? Чемпионские сделки не удаляются.'
    );
    if (!ok) return;
    this.optResettingIds.add(logicId);
    this.paramsSaveErrors.delete(logicId);
    this.logicsService.resetOptToInitial(logicId).subscribe({
      next: (resp) => {
        this.optResettingIds.delete(logicId);
        if (resp?.ok === false) {
          this.paramsSaveErrors.set(
            logicId,
            resp.error || resp.message || 'Сброс OPT не выполнен'
          );
          return;
        }
        if (Array.isArray(resp.signals)) {
          this.logicSignals.set(logicId, resp.signals);
          for (const r of resp.signals) {
            this.formulaDrafts.set(r.id, r.formula);
          }
          this.rebuildSignalIndicatorIds(logicId);
        } else {
          this.loadSignalsForLogic(logicId, true);
        }
        this.paramsSaveErrors.delete(logicId);
        // Soft notice via existing error slot is wrong; use empty + reload trades if panel open
        this.loadParamsForLogic(logicId, true);
        const msg = resp.message || 'OPT сброшен';
        window.alert(msg);
      },
      error: (err) => {
        this.optResettingIds.delete(logicId);
        this.paramsSaveErrors.set(
          logicId,
          err?.error?.error || err?.message || 'Ошибка сброса OPT'
        );
      },
    });
  }

  isShadowResetting(logicId: number): boolean {
    return this.shadowResettingIds.has(logicId);
  }

  /** Clear live shadow trades, unpause papers, re-activate all securities of the logic. */
  resetShadowTrading(row: LogicRow, event: Event): void {
    event.stopPropagation();
    if (this.shadowResettingIds.has(row.id) || this.isBacktestRunning(row.id)) return;
    const ok = confirm(
      `Очистить теневую историю логики «${row.name}»?\n\n` +
        '• удаляются только теневые (shadow) боевые сделки;\n' +
        '• снимаются пауза/инверсия портфеля и бумаг;\n' +
        '• все бумаги логики снова включаются (is_active);\n' +
        '• при включённой логике обновляется история рейтингов, как при старте.\n\n' +
        'Реальные (не теневые) сделки не удаляются.'
    );
    if (!ok) return;
    this.shadowResettingIds.add(row.id);
    this.logicsService.resetShadowTrading(row.id).subscribe({
      next: (resp) => {
        this.shadowResettingIds.delete(row.id);
        const idx = this.logics.findIndex((l) => l.id === row.id);
        if (idx >= 0) {
          this.logics[idx] = {
            ...this.logics[idx],
            portfolio_trading_paused: false,
          };
          this.logics = [...this.logics];
        }
        this.loadSecuritiesForLogic(row.id, true);
        this.loadTradesForLogic(row.id, true);
        this.loadSignalsForLogic(row.id, true);
        const cleared = resp.cleared_shadow_trades ?? 0;
        const secs = resp.securities_reactivated ?? 0;
        alert(
          resp.message ||
            `Теневые сделки очищены (${cleared}), бумаг обновлено: ${secs}.`
        );
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.shadowResettingIds.delete(row.id);
        alert(err?.error?.error || err?.message || 'Не удалось очистить теневую историю');
        this.cdr.markForCheck();
      },
    });
  }

  private lightningBusyIds = new Set<number>();

  isLightningBusy(logicId: number): boolean {
    return this.lightningBusyIds.has(logicId);
  }

  /** Молния (#960): проверить сигналы логики сейчас на последнем ЗАКРЫТОМ баре её ТФ (#990). */
  runLightning(row: LogicRow, event: Event): void {
    event.stopPropagation();
    if (this.lightningBusyIds.has(row.id) || this.isBacktestRunning(row.id)) return;
    const ok = confirm(
      `Молния: проверить сигналы логики «${row.name}» сейчас?\n\n` +
        'Считаем на последнем ЗАКРЫТОМ баре таймфрейма логики (как боевой цикл).\n' +
        'Если боевой цикл сейчас занят, покажу сигналы, уже посчитанные им на этом баре.\n' +
        'Если сигнал есть, по настройкам логики будет:\n' +
        '  • включённая — создана сделка;\n' +
        '  • «сигнал в терминал» — выдан сигнал в терминал.\n\n' +
        'Повторное нажатие не создаёт дублей (та же бумага/бар/сторона).'
    );
    if (!ok) return;
    this.lightningBusyIds.add(row.id);
    this.logicsService.runLightning(row.id).subscribe({
      next: (resp) => {
        const lines: string[] = [];
        if (resp.busy) {
          lines.push('Боевой цикл сейчас занят — показаны сигналы с последнего закрытого бара.');
        } else if (resp.reason && resp.reason !== 'ok') {
          lines.push(`Причина: ${resp.reason}`);
        }
        // #1022: сигнал считается на «сдвинутом» ТФ — показываем его бар
        // (правый край = последняя закрытая минута), а не только сетку.
        if (resp.shifted_bar_dt) {
          lines.push(`Сдвинутый бар: ${resp.shifted_bar_dt}`);
        } else if (resp.bar_dt) {
          lines.push(`Закрытый бар: ${resp.bar_dt}`);
        }
        lines.push(
          `Сделка: ${resp.trade_created ?? 0}` +
            `, сигналов на баре: ${resp.terminal_signals_on_bar ?? resp.terminal_signals_created ?? 0}`
        );
        const onBar = Number(resp.terminal_signals_on_bar ?? 0);
        if (resp.bar_dt && resp.use_sig) {
          if (resp.terminal_signals_created) {
            lines.push(`Новых сигналов в терминал: ${resp.terminal_signals_created}`);
          } else if (onBar > 0) {
            lines.push('Новых сигналов нет — на этом баре уже всё учтено.');
          } else {
            // #991: сигналов нет — объясняем причину (диагностика с сервера).
            lines.push('Сигналов на этом баре нет.');
            lines.push(...this.lightningDiagnosticsLines(resp.diagnostics, !!resp.busy, resp.bar_dt));
          }
        }
        const pending = Number(resp.pending_created ?? 0);
        if (pending > 0) {
          lines.push(
            `Найдено сигналов: ${pending} — проверяю подтверждение цены (${resp.max_confirm_sec ?? 0} с)…`
          );
        }
        alert(lines.join('\n'));
        this.loadTradesForLogic(row.id, true);
        this.loadSignalsForLogic(row.id, true);
        this.cdr.markForCheck();
        if (pending > 0) {
          const waitMs = Math.max(1500, (Number(resp.max_confirm_sec) || 0) * 1000 + 3000);
          setTimeout(() => this.finalizeLightningSignals(row.id), waitMs);
        } else {
          this.lightningBusyIds.delete(row.id);
        }
      },
      error: (err) => {
        this.lightningBusyIds.delete(row.id);
        alert(err?.error?.error || err?.message || 'Не удалось выполнить молнию');
        this.cdr.markForCheck();
      },
    });
  }

  /** #990: доводим отложенные подтверждения цены до сигналов/сделок и обновляем списки. */
  private finalizeLightningSignals(logicId: number): void {
    this.logicsService.confirmFinalize(logicId).subscribe({
      next: (r) => {
        this.lightningBusyIds.delete(logicId);
        this.loadTradesForLogic(logicId, true);
        this.loadSignalsForLogic(logicId, true);
        const created = Number(r?.created ?? 0);
        alert(
          created > 0
            ? `Подтверждение цены пройдено: создано сигналов/сделок — ${created}.`
            : 'Подтверждение цены не пройдено: сигналы не созданы.'
        );
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.lightningBusyIds.delete(logicId);
        alert(err?.error?.error || err?.message || 'Не удалось подтвердить сигналы');
        this.cdr.markForCheck();
      },
    });
  }

  /** #991: причины, почему «молния» не дала сигналов на баре (диагностика с сервера). */
  private lightningDiagnosticsLines(
    diag: LightningDiagnostics | undefined,
    busy: boolean,
    barDt: string
  ): string[] {
    const out: string[] = [];
    if (!diag) {
      if (busy) {
        out.push('Боевой цикл занят; свежий бар обрабатывается автоматически (обычно ~1 мин).');
      }
      return out;
    }
    if ((diag.active_signals ?? 0) === 0) {
      out.push('У логики нет активных open-сигналов — считать нечего.');
    }
    if ((diag.active_securities ?? 0) === 0) {
      out.push('В логике нет активных бумаг — сигналы не считаются.');
    }
    if (diag.non_trading_period) {
      out.push('Сейчас неторговый период — сигналы в терминал не выдаются.');
    }
    const lastBar = diag.last_signal_bar_dt ?? null;
    if (lastBar && lastBar !== barDt) {
      out.push(
        `На баре ${barDt} сигналов нет; последние сигналы: бар ${lastBar} (${diag.last_signal_count ?? 0} шт).`
      );
    } else if (!lastBar) {
      out.push('По этой логике сигналов в терминал ещё не было.');
    }
    if (busy) {
      out.push('Боевой цикл занят: свежий бар обрабатывается автоматически (обычно ~1 мин).');
    }
    if ((diag.price_errors ?? 0) > 0) {
      out.push(
        `Ошибки загрузки цен за 2 ч: ${diag.price_errors}. Последняя: ${diag.last_error ?? '—'}`
      );
    }
    if ((diag.signal_errors ?? 0) > 0) {
      out.push(`Ошибки расчёта сигналов за 2 ч: ${diag.signal_errors}.`);
    }
    if ((diag.pending_total ?? 0) > 0) {
      out.push(`Ожидают подтверждения цены: ${diag.pending_total}.`);
    }
    return out;
  }

  private formatPctParam(value: number | string | null | undefined): string {
    if (value == null || value === '') return '10';
    const n =
      typeof value === 'number'
        ? value
        : Number(String(value).trim().replace(/\s/g, '').replace(',', '.'));
    if (!Number.isFinite(n)) return '10';
    const rounded = Math.round(n * 10000) / 10000;
    if (Math.abs(rounded - Math.round(rounded)) < 1e-9) {
      return String(Math.round(rounded));
    }
    return String(rounded);
  }

  private formatIntParam(value: number | string | null | undefined, fallback: number): string {
    if (value == null || value === '') return String(fallback);
    const n = Number(String(value).trim().replace(/\s/g, ''));
    if (!Number.isFinite(n)) return String(fallback);
    return String(Math.round(n));
  }

  private formatBalanceDraft(value: number | string | null | undefined): string {
    if (value == null || value === '') return '';
    const n =
      typeof value === 'number'
        ? value
        : Number(String(value).trim().replace(/\s/g, '').replace(',', '.'));
    if (!Number.isFinite(n)) return '';
    return String(n);
  }

  private parseDecimalInput(raw: string): number {
    return Number(raw.trim().replace(/\s/g, '').replace(',', '.'));
  }

  isParamsLoading(logicId: number): boolean {
    return this.paramsLoading.has(logicId);
  }

  loadParamsForLogic(logicId: number, silent = false): void {
    if (silent && this.paramsDirtyIds.has(logicId)) {
      return;
    }
    if (!silent) {
      this.paramsLoading.add(logicId);
    }
    this.logicsService.getLogicParams(logicId).subscribe({
      next: (resp) => {
        this.applyTradingParamsToLogic(logicId, resp.trading);
        if (!this.paramsDirtyIds.has(logicId)) {
          const row = this.logics.find((l) => l.id === logicId);
          const draft = this.draftFromTrading(resp.trading);
          draft.name = row?.name ?? draft.name;
          this.paramsDrafts.set(logicId, draft);
        }
        this.paramsLoading.delete(logicId);
      },
      error: () => {
        this.paramsLoading.delete(logicId);
        if (!silent) {
          this.paramsSaveErrors.set(logicId, 'Не удалось загрузить параметры');
        }
      },
    });
  }

  private applyTradingParamsToLogic(
    logicId: number,
    trading: {
      timeframe?: string;
      position_size_base?: 'free_cash' | 'portfolio' | 'portfolio_incl_fund';
      position_size_pct: number;
      max_open_positions: number;
      max_order_amount?: number | null;
      initial_balance: number | null;
      current_balance: number | null;
      commission_pct?: number;
      cost_method?: 'FIFO' | 'AVERAGE';
      stop_loss_timeframe?: string;
      base_annual_rate_pct?: number;
      rating_lookback_days?: number;
      inversion?: boolean;
      warmup_pretest?: boolean;
      auto_optimize?: boolean;
      resume_sl_no_reduce?: boolean;
      cash_fund_code?: string;
      cash_fund_threshold?: number;
      use_non_trading_periods?: boolean;
      non_trading_periods_mode?: NonTradingPeriodsMode;
      close_positions_eod?: boolean;
      sell_futures_before_expiry?: boolean;
      sell_futures_days_before_expiry?: number;
      order_execution?: 'market' | 'limit';
      opt_eval_candles?: number;
    }
  ): void {
    const idx = this.logics.findIndex((l) => l.id === logicId);
    if (idx >= 0) {
      this.logics[idx] = { ...this.logics[idx], ...trading };
    }
  }

  private draftFromTrading(trading: {
    timeframe?: string;
    position_size_base?: 'free_cash' | 'portfolio' | 'portfolio_incl_fund';
    position_size_pct: number;
    max_open_positions: number;
    max_order_amount?: number | null;
    order_gap_buffer_pct?: number | null;
    max_open_gap_pct?: number | null;
    initial_balance: number | null;
    current_balance: number | null;
    test_initial_balance?: number | null;
    commission_pct?: number;
    cost_method?: 'FIFO' | 'AVERAGE';
    stop_loss_timeframe?: string;
    base_annual_rate_pct?: number;
    rating_lookback_days?: number;
    inversion?: boolean;
    warmup_pretest?: boolean;
    auto_optimize?: boolean;
    resume_sl_no_reduce?: boolean;
    cash_fund_code?: string;
    cash_fund_threshold?: number;
    use_non_trading_periods?: boolean;
    non_trading_periods_mode?: NonTradingPeriodsMode;
    close_positions_eod?: boolean;
    sell_futures_before_expiry?: boolean;
    sell_futures_days_before_expiry?: number;
    order_execution?: 'market' | 'limit';
    opt_eval_candles?: number;
  }): {
    name: string;
    timeframe: string;
    position_size_base: 'free_cash' | 'portfolio' | 'portfolio_incl_fund';
    position_size_pct: string;
    max_open_positions: string;
    max_order_amount: string;
    order_gap_buffer_pct: string;
    max_open_gap_pct: string;
    initial_balance: string;
    test_initial_balance: string;
    commission_pct: string;
    cost_method: 'FIFO' | 'AVERAGE';
    stop_loss_timeframe: string;
    base_annual_rate_pct: string;
    rating_lookback_days: string;
    inversion: boolean;
    warmup_pretest: boolean;
    auto_optimize: boolean;
    resume_sl_no_reduce: boolean;
    cash_fund_code: string;
    cash_fund_threshold: string;
    use_non_trading_periods: boolean;
    non_trading_periods_mode: NonTradingPeriodsMode;
    close_positions_eod: boolean;
    sell_futures_before_expiry: boolean;
    sell_futures_days_before_expiry: string;
    order_execution: 'market' | 'limit';
    opt_eval_candles: string;
    reset_balance: boolean;
  } {
    const method: 'FIFO' | 'AVERAGE' =
      trading.cost_method === 'AVERAGE' ? 'AVERAGE' : 'FIFO';
    const fundRaw = String(trading.cash_fund_code ?? '')
      .trim()
      .toUpperCase();
    const cash_fund_code = ['', 'TMON', 'LQDT', 'SBMM'].includes(fundRaw)
      ? fundRaw
      : '';
    return {
      name: '',
      timeframe: (trading.timeframe ?? 'M15').toUpperCase(),
      position_size_base: this.normalizePositionSizeBase(trading.position_size_base),
      position_size_pct: this.formatPctParam(trading.position_size_pct),
      max_open_positions: this.formatIntParam(trading.max_open_positions, 5),
      max_order_amount: this.formatBalanceDraft(
        trading.max_order_amount != null ? trading.max_order_amount : null
      ),
      order_gap_buffer_pct: this.formatBalanceDraft(trading.order_gap_buffer_pct),
      max_open_gap_pct: this.formatBalanceDraft(trading.max_open_gap_pct),
      initial_balance: this.formatBalanceDraft(trading.initial_balance),
      test_initial_balance: this.formatBalanceDraft(trading.test_initial_balance),
      commission_pct: this.formatPctParam(trading.commission_pct ?? 0.03),
      cost_method: method,
      stop_loss_timeframe: (trading.stop_loss_timeframe ?? 'M5').toUpperCase(),
      base_annual_rate_pct: this.formatPctParam(trading.base_annual_rate_pct ?? 20),
      rating_lookback_days: this.formatIntParam(trading.rating_lookback_days ?? 7, 7),
      inversion: !!trading.inversion,
      warmup_pretest: trading.warmup_pretest !== false,
      auto_optimize: trading.auto_optimize === true,
      resume_sl_no_reduce: trading.resume_sl_no_reduce === true,
      cash_fund_code,
      cash_fund_threshold: this.formatBalanceDraft(
        trading.cash_fund_threshold != null ? trading.cash_fund_threshold : 1000000
      ),
      use_non_trading_periods:
        this.normalizeNonTradingMode(
          trading.non_trading_periods_mode,
          trading.use_non_trading_periods
        ) === 'trading',
      non_trading_periods_mode: this.normalizeNonTradingMode(
        trading.non_trading_periods_mode,
        trading.use_non_trading_periods
      ),
      close_positions_eod: trading.close_positions_eod === true,
      sell_futures_before_expiry: trading.sell_futures_before_expiry === true,
      sell_futures_days_before_expiry: this.formatIntParam(
        trading.sell_futures_days_before_expiry ?? 3,
        3
      ),
      order_execution: trading.order_execution === 'limit' ? 'limit' : 'market',
      opt_eval_candles: this.formatIntParam(trading.opt_eval_candles ?? 200, 200),
      reset_balance: false,
    };
  }

  toggleParamsBlock(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.expandedParamsBlocks.has(logicId)) {
      this.expandedParamsBlocks.delete(logicId);
      this.paramsDirtyIds.delete(logicId);
    } else {
      this.expandedParamsBlocks.add(logicId);
      this.paramsDirtyIds.delete(logicId);
      this.loadParamsForLogic(logicId);
    }
  }

  ensureParamsDraft(logicId: number, force = false): void {
    if (!force && this.paramsDrafts.has(logicId)) return;
    const row = this.logics.find((l) => l.id === logicId);
    if (!row) return;
    this.paramsDrafts.set(logicId, this.draftFromLogicRow(row));
  }

  private draftFromLogicRow(row: LogicRow) {
    const draft = this.draftFromTrading({
      timeframe: row.timeframe ?? 'M15',
      position_size_base: row.position_size_base,
      position_size_pct: row.position_size_pct,
      max_open_positions: row.max_open_positions,
      max_order_amount: row.max_order_amount,
      initial_balance: row.initial_balance,
      current_balance: row.current_balance,
      test_initial_balance: row.test_initial_balance,
      commission_pct: row.commission_pct,
      cost_method: row.cost_method,
      stop_loss_timeframe: row.stop_loss_timeframe,
      base_annual_rate_pct: row.base_annual_rate_pct,
      rating_lookback_days: row.rating_lookback_days,
      inversion: row.inversion,
      warmup_pretest: row.warmup_pretest,
      auto_optimize: row.auto_optimize,
      resume_sl_no_reduce: row.resume_sl_no_reduce,
      cash_fund_code: row.cash_fund_code,
      cash_fund_threshold: row.cash_fund_threshold,
      use_non_trading_periods: row.use_non_trading_periods,
      non_trading_periods_mode: this.normalizeNonTradingMode(
        row.non_trading_periods_mode,
        row.use_non_trading_periods
      ),
      close_positions_eod: row.close_positions_eod,
      sell_futures_before_expiry: row.sell_futures_before_expiry,
      sell_futures_days_before_expiry: row.sell_futures_days_before_expiry,
      order_execution: row.order_execution,
      opt_eval_candles: row.opt_eval_candles,
    });
    draft.name = row.name ?? '';
    return draft;
  }

  isParamsSaving(logicId: number): boolean {
    return this.savingParamsIds.has(logicId);
  }

  saveTradingParams(row: LogicRow, event: Event): void {
    event.stopPropagation();
    const draft = this.getParamsDraft(row.id);
    const position_size_base = this.normalizePositionSizeBase(
      draft.position_size_base
    );
    const position_size_pct = this.parseDecimalInput(draft.position_size_pct);
    const max_open_positions = Math.round(this.parseDecimalInput(draft.max_open_positions));
    const maxOrderRaw = draft.max_order_amount.trim();
    const max_order_amount =
      maxOrderRaw === '' ? null : this.parseDecimalInput(maxOrderRaw.replace(',', '.'));
    const gapBufferRaw = draft.order_gap_buffer_pct.trim();
    const order_gap_buffer_pct =
      gapBufferRaw === '' ? null : this.parseDecimalInput(gapBufferRaw.replace(',', '.'));
    const maxGapRaw = draft.max_open_gap_pct.trim();
    const max_open_gap_pct =
      maxGapRaw === '' ? null : this.parseDecimalInput(maxGapRaw.replace(',', '.'));
    const initialRaw = draft.initial_balance.trim();
    const initial_balance =
      initialRaw === '' ? null : this.parseDecimalInput(initialRaw.replace(',', '.'));
    const testStartRaw = (draft.test_initial_balance ?? '').trim();
    const test_start_balance =
      testStartRaw === '' ? null : this.parseDecimalInput(testStartRaw.replace(',', '.'));
    const commission_pct = this.parseDecimalInput(draft.commission_pct);
    const base_annual_rate_pct = this.parseDecimalInput(draft.base_annual_rate_pct);
    const rating_lookback_days = Math.round(
      this.parseDecimalInput(draft.rating_lookback_days)
    );
    const opt_eval_candles = Math.round(
      this.parseDecimalInput(draft.opt_eval_candles)
    );

    if (!Number.isFinite(position_size_pct) || position_size_pct <= 0 || position_size_pct > 100) {
      this.paramsSaveErrors.set(
        row.id,
        '% депозита: число от 0.01 до 100 (без пробелов, например 10)'
      );
      return;
    }
    if (!Number.isInteger(max_open_positions) || max_open_positions <= 0) {
      this.paramsSaveErrors.set(row.id, 'Макс. позиций: целое число больше 0');
      return;
    }
    if (max_order_amount != null && (!Number.isFinite(max_order_amount) || max_order_amount < 0)) {
      this.paramsSaveErrors.set(row.id, 'Макс. сумма на сделку: число ≥ 0 или пусто');
      return;
    }
    if (order_gap_buffer_pct != null && (!Number.isFinite(order_gap_buffer_pct) || order_gap_buffer_pct < 0 || order_gap_buffer_pct > 50)) {
      this.paramsSaveErrors.set(row.id, 'Буфер цены исполнения: число от 0 до 50 или пусто');
      return;
    }
    if (max_open_gap_pct != null && (!Number.isFinite(max_open_gap_pct) || max_open_gap_pct < 0 || max_open_gap_pct > 50)) {
      this.paramsSaveErrors.set(row.id, 'Макс. гэп входа: число от 0 до 50 или пусто');
      return;
    }
    if (initial_balance != null && (!Number.isFinite(initial_balance) || initial_balance < 0)) {
      this.paramsSaveErrors.set(row.id, 'Начальный остаток (старт): число ≥ 0 или пусто');
      return;
    }
    if (
      test_start_balance != null &&
      (!Number.isFinite(test_start_balance) || test_start_balance < 0)
    ) {
      this.paramsSaveErrors.set(row.id, 'Старт теста (отдельный): число ≥ 0 или пусто');
      return;
    }
    if (!Number.isFinite(commission_pct) || commission_pct < 0 || commission_pct > 100) {
      this.paramsSaveErrors.set(row.id, '% комиссии: число от 0 до 100');
      return;
    }
    if (
      !Number.isFinite(base_annual_rate_pct) ||
      base_annual_rate_pct < 0 ||
      base_annual_rate_pct > 1000
    ) {
      this.paramsSaveErrors.set(row.id, 'Базовая ставка (% годовых): число от 0 до 1000');
      return;
    }
    if (
      !Number.isInteger(rating_lookback_days) ||
      rating_lookback_days < 1 ||
      rating_lookback_days > 90
    ) {
      this.paramsSaveErrors.set(row.id, 'Дней предрасчёта рейтинга: целое от 1 до 90');
      return;
    }
    if (
      !Number.isInteger(opt_eval_candles) ||
      opt_eval_candles < 1 ||
      opt_eval_candles > 500
    ) {
      this.paramsSaveErrors.set(row.id, 'Свечей окна OPT: целое от 1 до 500');
      return;
    }
    const sell_futures_days_before_expiry = Math.round(
      this.parseDecimalInput(draft.sell_futures_days_before_expiry)
    );
    if (
      !Number.isInteger(sell_futures_days_before_expiry) ||
      sell_futures_days_before_expiry < 0 ||
      sell_futures_days_before_expiry > 365
    ) {
      this.paramsSaveErrors.set(row.id, 'Дней до экспирации: целое от 0 до 365');
      return;
    }

    const cash_fund_threshold = this.parseDecimalInput(draft.cash_fund_threshold);
    if (!Number.isFinite(cash_fund_threshold) || cash_fund_threshold < 0) {
      this.paramsSaveErrors.set(row.id, 'Порог свободных денег: число ≥ 0');
      return;
    }
    const cash_fund_code = String(draft.cash_fund_code ?? '')
      .trim()
      .toUpperCase();
    if (!['', 'TMON', 'LQDT', 'SBMM'].includes(cash_fund_code)) {
      this.paramsSaveErrors.set(row.id, 'Денежный фонд: пусто, TMON, LQDT или SBMM');
      return;
    }

    this.paramsSaveErrors.delete(row.id);
    this.savingParamsIds.add(row.id);

    const name = String(draft.name ?? '').trim();
    if (!name) {
      this.savingParamsIds.delete(row.id);
      this.paramsSaveErrors.set(row.id, 'Имя логики не может быть пустым');
      return;
    }
    if (name.length > 100) {
      this.savingParamsIds.delete(row.id);
      this.paramsSaveErrors.set(row.id, 'Имя логики: не более 100 символов');
      return;
    }

    const saveParams = () =>
      this.logicsService.saveLogicParams(row.id, {
        timeframe: draft.timeframe,
        position_size_base,
        position_size_pct,
        max_open_positions,
        max_order_amount,
        order_gap_buffer_pct,
        max_open_gap_pct,
        initial_balance,
        test_initial_balance: test_start_balance,
        commission_pct,
        cost_method: draft.cost_method,
        stop_loss_timeframe: draft.stop_loss_timeframe,
        base_annual_rate_pct,
        rating_lookback_days,
        inversion: draft.inversion,
        warmup_pretest: draft.warmup_pretest,
        auto_optimize: draft.auto_optimize,
        resume_sl_no_reduce: draft.resume_sl_no_reduce,
        cash_fund_code,
        cash_fund_threshold,
        use_non_trading_periods: draft.use_non_trading_periods,
        non_trading_periods_mode: draft.non_trading_periods_mode,
        close_positions_eod: draft.close_positions_eod,
        sell_futures_before_expiry: draft.sell_futures_before_expiry,
        sell_futures_days_before_expiry,
        order_execution: draft.order_execution,
        opt_eval_candles,
        reset_balance: draft.reset_balance,
      });

    const afterParamsSaved = (resp: LogicParamsResponse) => {
      this.applyTradingParamsToLogic(row.id, resp.trading);
      const nextDraft = this.draftFromTrading(resp.trading);
      nextDraft.name = row.name;
      this.paramsDrafts.set(row.id, nextDraft);
      this.paramsDirtyIds.delete(row.id);
      this.savingParamsIds.delete(row.id);
      this.paramsSaveErrors.delete(row.id);
      const nt = this.nonTradingByLogic.get(row.id);
      if (nt) {
        this.nonTradingByLogic.set(row.id, {
          ...nt,
          non_trading_periods_mode: this.normalizeNonTradingMode(
            resp.trading.non_trading_periods_mode,
            resp.trading.use_non_trading_periods
          ),
          use_non_trading_periods: resp.trading.use_non_trading_periods !== false,
        });
      }
      this.loadSecuritiesForLogic(row.id, true);
      this.techLog.event(
        this.techLog.logicThreadKey(row.id, 'params'),
        'logic.params.saved',
        'Параметры логики сохранены (UI)',
        {
          logicId: row.id,
          payload: { trading: resp.trading, params: resp.params },
        }
      );
    };

    const onSaveError = (err: { error?: { error?: string } }) => {
      this.savingParamsIds.delete(row.id);
      this.paramsSaveErrors.set(
        row.id,
        err?.error?.error ?? 'Не удалось сохранить параметры'
      );
    };

    if (name !== row.name) {
      this.logicsService
        .updateLogic(row.id, {
          name,
          account_id: row.account_id,
          is_enabled: row.is_enabled,
          note: row.note ?? null,
        })
        .subscribe({
          next: (updated) => {
            row.name = updated.name;
            const local = this.logics.find((l) => l.id === row.id);
            if (local) local.name = updated.name;
            saveParams().subscribe({
              next: afterParamsSaved,
              error: onSaveError,
            });
          },
          error: onSaveError,
        });
      return;
    }

    saveParams().subscribe({
      next: afterParamsSaved,
      error: onSaveError,
    });
  }

  formatMoney(value: number | null | undefined): string {
    if (value == null || !Number.isFinite(Number(value))) return '—';
    return Number(value).toLocaleString('ru-RU', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }

  toggleSignalsBlock(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.expandedSignalsBlocks.has(logicId)) {
      this.expandedSignalsBlocks.delete(logicId);
      this.closeSignalPicker();
    } else {
      this.expandedSignalsBlocks.add(logicId);
      this.loadSignalsForLogic(logicId);
      this.refreshOptGridAvailability(logicId);
    }
  }

  toggleStopsBlock(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.expandedStopsBlocks.has(logicId)) {
      this.expandedStopsBlocks.delete(logicId);
      this.closeStopForm();
    } else {
      this.expandedStopsBlocks.add(logicId);
      this.loadStopsForLogic(logicId);
    }
  }

  toggleSecuritiesBlock(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.expandedSecuritiesBlocks.has(logicId)) {
      this.expandedSecuritiesBlocks.delete(logicId);
      this.closeSecurityPicker();
    } else {
      this.expandedSecuritiesBlocks.add(logicId);
      this.loadSecuritiesForLogic(logicId);
    }
  }

  togglePeriodsBlock(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.expandedPeriodsBlocks.has(logicId)) {
      this.expandedPeriodsBlocks.delete(logicId);
    } else {
      this.expandedPeriodsBlocks.add(logicId);
      this.loadNonTradingPeriods(logicId);
    }
  }

  isPeriodsLoading(logicId: number): boolean {
    return this.periodsLoading.has(logicId);
  }

  isPeriodsApplying(logicId: number): boolean {
    return this.periodsApplying.has(logicId);
  }

  intervalsForDay(
    logicId: number,
    dayOfWeek: number
  ): {
    id: number;
    day_of_week: number;
    time_from: string;
    time_to: string;
    note?: string | null;
  }[] {
    const row = this.nonTradingByLogic.get(logicId);
    if (!row) return [];
    return row.intervals.filter((i) => i.day_of_week === dayOfWeek);
  }

  private applyNonTradingResponse(
    logicId: number,
    resp: {
      non_trading_periods_mode?: NonTradingPeriodsMode;
      use_non_trading_periods?: boolean;
      intervals?: {
        id: number;
        day_of_week: number;
        time_from: string;
        time_to: string;
        note?: string | null;
      }[];
    }
  ): void {
    const prev = this.nonTradingByLogic.get(logicId);
    const mode = this.normalizeNonTradingMode(
      resp.non_trading_periods_mode ?? prev?.non_trading_periods_mode,
      resp.use_non_trading_periods ?? prev?.use_non_trading_periods
    );
    this.nonTradingByLogic.set(logicId, {
      non_trading_periods_mode: mode,
      use_non_trading_periods: mode === 'trading',
      intervals: resp.intervals ?? [],
    });
  }

  addNonTradingInterval(logicId: number, dayOfWeek: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.periodsSaving.has(logicId)) return;
    this.periodsSaving.add(logicId);
    const defaults =
      dayOfWeek >= 6
        ? { time_from: '00:00', time_to: '23:59' }
        : { time_from: '18:40', time_to: '23:59' };
    this.logicsService
      .addNonTradingPeriod(logicId, {
        day_of_week: dayOfWeek,
        time_from: defaults.time_from,
        time_to: defaults.time_to,
      })
      .subscribe({
        next: (resp) => {
          this.applyNonTradingResponse(logicId, resp);
          this.periodsSaving.delete(logicId);
        },
        error: (err) => {
          console.error('addNonTradingPeriod', err);
          this.periodsSaving.delete(logicId);
        },
      });
  }

  onNonTradingIntervalTimeChange(
    logicId: number,
    intervalId: number,
    field: 'time_from' | 'time_to',
    value: string
  ): void {
    const raw = String(value ?? '').trim();
    if (!/^\d{1,2}:\d{2}(:\d{2})?$/.test(raw)) return;
    const hm = raw.slice(0, 5);
    if (this.periodsSaving.has(intervalId)) return;
    this.periodsSaving.add(intervalId);
    this.logicsService
      .updateNonTradingPeriod(intervalId, { [field]: hm })
      .subscribe({
        next: (resp) => {
          this.applyNonTradingResponse(logicId, resp);
          this.periodsSaving.delete(intervalId);
        },
        error: (err) => {
          console.error('updateNonTradingPeriod', err);
          this.periodsSaving.delete(intervalId);
          this.loadNonTradingPeriods(logicId, true);
        },
      });
  }

  deleteNonTradingInterval(logicId: number, intervalId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.periodsSaving.has(intervalId)) return;
    this.periodsSaving.add(intervalId);
    this.logicsService.deleteNonTradingPeriod(intervalId).subscribe({
      next: (resp) => {
        this.applyNonTradingResponse(logicId, resp);
        this.periodsSaving.delete(intervalId);
      },
      error: (err) => {
        console.error('deleteNonTradingPeriod', err);
        this.periodsSaving.delete(intervalId);
      },
    });
  }

  private normalizeNonTradingMode(
    mode?: NonTradingPeriodsMode,
    legacyEnabled?: boolean
  ): NonTradingPeriodsMode {
    if (mode === 'off' || mode === 'trading' || mode === 'non_trading') return mode;
    return legacyEnabled !== false ? 'trading' : 'off';
  }

  nonTradingPeriodsMode(logicId: number): NonTradingPeriodsMode {
    const cached = this.nonTradingByLogic.get(logicId);
    if (cached) return cached.non_trading_periods_mode;
    const draft = this.getParamsDraft(logicId);
    return this.normalizeNonTradingMode(
      draft.non_trading_periods_mode,
      draft.use_non_trading_periods
    );
  }

  onNonTradingPeriodsModeChange(
    logicId: number,
    mode: NonTradingPeriodsMode,
    event?: Event
  ): void {
    event?.stopPropagation();
    const draft = this.getParamsDraft(logicId);
    draft.non_trading_periods_mode = mode;
    draft.use_non_trading_periods = mode === 'trading';
    const cached = this.nonTradingByLogic.get(logicId);
    if (cached) {
      this.nonTradingByLogic.set(logicId, {
        ...cached,
        non_trading_periods_mode: mode,
        use_non_trading_periods: mode === 'trading',
      });
    }
    this.logicsService
      .saveLogicParams(logicId, { non_trading_periods_mode: mode })
      .subscribe({
        next: (resp) => {
          this.applyTradingParamsToLogic(logicId, resp.trading);
          const savedMode = this.normalizeNonTradingMode(
            resp.trading.non_trading_periods_mode,
            resp.trading.use_non_trading_periods
          );
          draft.non_trading_periods_mode = savedMode;
          draft.use_non_trading_periods = savedMode === 'trading';
          if (
            mode !== 'off' &&
            (!cached || !cached.intervals || cached.intervals.length === 0)
          ) {
            this.applyMoexNonTradingPeriods(logicId, new Event('click'));
          }
        },
        error: (err) => {
          console.error('non_trading_periods_mode save', err);
        },
      });
  }

  applyMoexNonTradingPeriods(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    this.periodsApplying.add(logicId);
    this.logicsService.applyMoexNonTradingPeriods(logicId).subscribe({
      next: (resp) => {
        const mode = this.normalizeNonTradingMode(
          resp.non_trading_periods_mode,
          resp.use_non_trading_periods
        );
        this.nonTradingByLogic.set(logicId, {
          non_trading_periods_mode: mode,
          use_non_trading_periods: mode === 'trading',
          intervals: resp.intervals ?? [],
        });
        this.periodsApplying.delete(logicId);
        this.expandedPeriodsBlocks.add(logicId);
      },
      error: (err) => {
        console.error('applyMoexNonTradingPeriods', err);
        this.periodsApplying.delete(logicId);
      },
    });
  }

  private loadNonTradingPeriods(logicId: number, force = false): void {
    if (!force && this.nonTradingByLogic.has(logicId) && !this.periodsLoading.has(logicId)) {
      return;
    }
    this.periodsLoading.add(logicId);
    this.logicsService.getNonTradingPeriods(logicId).subscribe({
      next: (resp) => {
        const mode = this.normalizeNonTradingMode(
          resp.non_trading_periods_mode,
          resp.use_non_trading_periods
        );
        this.nonTradingByLogic.set(logicId, {
          non_trading_periods_mode: mode,
          use_non_trading_periods: mode === 'trading',
          intervals: resp.intervals ?? [],
        });
        const draft = this.getParamsDraft(logicId);
        draft.non_trading_periods_mode = mode;
        draft.use_non_trading_periods = mode === 'trading';
        this.periodsLoading.delete(logicId);
      },
      error: (err) => {
        console.error('getNonTradingPeriods', err);
        this.periodsLoading.delete(logicId);
      },
    });
  }

  isTestTradesBlockExpanded(id: number): boolean {
    return this.expandedTestTradesBlocks.has(id);
  }

  toggleTestTradesBlock(logicId: number, event?: Event): void {
    event?.preventDefault();
    event?.stopPropagation();
    if (this.expandedTestTradesBlocks.has(logicId)) {
      this.expandedTestTradesBlocks.delete(logicId);
    } else {
      this.expandedTestTradesBlocks.add(logicId);
      this.loadSignalsForLogic(logicId);
      // Mid-run: light panel feed (opens + recent closes); full 50k dump after finish.
      if (this.isBacktestRunning(logicId)) {
        this.loadTestTradesPanelForLogic(logicId);
      } else {
        this.loadTestTradesForLogic(logicId);
      }
      this.loadTestEquityForLogic(logicId);
      this.backtestUi.watch(logicId);
    }
  }

  toggleTradesBlock(logicId: number, event?: Event): void {
    event?.preventDefault();
    event?.stopPropagation();
    if (this.expandedTradesBlocks.has(logicId)) {
      this.expandedTradesBlocks.delete(logicId);
      this.expandedOpenPositionsBlocks.delete(logicId);
      this.expandedClosedPositionsBlocks.delete(logicId);
      for (const tr of this.tradesFor(logicId)) {
        this.expandedTradeRows.delete(tr.id);
      }
    } else {
      this.expandedTradesBlocks.add(logicId);
      this.expandedOpenPositionsBlocks.add(logicId);
      this.loadTradesForLogic(logicId);
    }
  }

  toggleOpenPositionsBlock(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.expandedOpenPositionsBlocks.has(logicId)) {
      this.expandedOpenPositionsBlocks.delete(logicId);
    } else {
      this.expandedOpenPositionsBlocks.add(logicId);
      this.loadLotsForOpenPositions(logicId);
    }
  }

  toggleClosedPositionsBlock(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.expandedClosedPositionsBlocks.has(logicId)) {
      this.expandedClosedPositionsBlocks.delete(logicId);
    } else {
      this.expandedClosedPositionsBlocks.add(logicId);
      this.loadLotsForClosedPositions(logicId);
    }
  }

  isOpenPositionsExpanded(logicId: number): boolean {
    return this.expandedOpenPositionsBlocks.has(logicId);
  }

  isClosedPositionsExpanded(logicId: number): boolean {
    return this.expandedClosedPositionsBlocks.has(logicId);
  }

  openPositionTrades(logicId: number, isTest = false): LogicTradeRow[] {
    return this.tradesFor(logicId, isTest)
      .filter((t) => this.isOpenPositionTrade(t))
      .sort(
        (a, b) =>
          new Date(b.executed_at).getTime() - new Date(a.executed_at).getTime()
      );
  }

  closePositionTrades(logicId: number): LogicTradeRow[] {
    return this.tradesFor(logicId)
      .filter(
        (t) =>
          t.side_name === 'Close' &&
          (t.status === 'filled' || t.status === 'submitted')
      )
      .sort(
        (a, b) =>
          new Date(b.executed_at).getTime() - new Date(a.executed_at).getTime()
      );
  }

  closedPartialLotsForOpen(openTradeId: number): LogicTradeLotRow[] {
    return this.tradeLotsFor(openTradeId).filter(
      (l) => l.open_trade_id === openTradeId
    );
  }

  closedLotsForClose(closeTradeId: number): LogicTradeLotRow[] {
    return this.tradeLotsFor(closeTradeId).filter(
      (l) => l.close_trade_id === closeTradeId
    );
  }

  totalFinancialResult(logicId: number, isTest = false): number {
    return this.tradesFor(logicId, isTest)
      .filter((t) => !t.is_shadow)
      .reduce(
        (sum, t) =>
          t.financial_result != null && Number.isFinite(Number(t.financial_result))
            ? sum + Number(t.financial_result)
            : sum,
        0
      );
  }

  hasTestFinancialResult(logicId: number): boolean {
    return this.testPnlByLogic.has(logicId);
  }

  testFinancialResult(logicId: number): number | null {
    const row = this.testPnlByLogic.get(logicId);
    if (!row) return null;
    return Number(row.financial_result);
  }

  testCommission(logicId: number): number | null {
    const row = this.testPnlByLogic.get(logicId);
    if (!row) return null;
    return Number(row.commission) || 0;
  }

  testFinancialResultTitle(logicId: number): string {
    const row = this.testPnlByLogic.get(logicId);
    if (!row) return '';
    const pnl = this.formatPnl(row.financial_result);
    const com = this.formatMoney(row.commission);
    const period = this.testPeriodLabel(logicId);
    const periodPart = period ? `, период ${period}` : '';
    return `Тест: финрез ${pnl}, комиссия ${com}, сделок ${row.trade_count}${periodPart}`;
  }

  /** Период последнего теста: день.месяц.год — без времени. */
  testPeriodLabel(logicId: number): string {
    const row = this.testPnlByLogic.get(logicId);
    const fromRun = this.backtestRuns.get(logicId);
    return formatDateRangeLabel(
      row?.date_from ?? fromRun?.date_from,
      row?.date_to ?? fromRun?.date_to,
    );
  }

  hasCombatFinancialResult(logicId: number): boolean {
    return this.combatPnlByLogic.has(logicId);
  }

  combatFinancialResult(logicId: number): number | null {
    const row = this.combatPnlByLogic.get(logicId);
    if (!row) return null;
    return Number(row.financial_result);
  }

  combatFinancialResultTitle(logicId: number): string {
    const row = this.combatPnlByLogic.get(logicId);
    if (!row) return '';
    const pnl = this.formatPnl(row.financial_result);
    const com = this.formatMoney(row.commission);
    return `Бой: финрез ${pnl}, комиссия ${com}, сделок ${row.trade_count}`;
  }

  hasOpenPositions(logicId: number): boolean {
    return this.openPositionTrades(logicId).length > 0;
  }

  isCloseAllLoading(logicId: number): boolean {
    return this.closeAllLoading.has(logicId);
  }

  closeAllPositionsAtMarket(logicId: number, event?: Event): void {
    event?.preventDefault();
    event?.stopPropagation();
    if (this.closeAllLoading.has(logicId) || !this.hasOpenPositions(logicId)) {
      return;
    }
    if (
      !confirm(
        'Закрыть все открытые позиции по текущим рыночным ценам? Фин. результат будет пересчитан.'
      )
    ) {
      return;
    }
    this.closeAllLoading.add(logicId);
    this.logicsService.closeAllPositionsAtMarket(logicId).subscribe({
      next: (result) => {
        this.closeAllLoading.delete(logicId);
        const closed = Number(result.closed) || 0;
        const skipped = Number(result.skipped) || 0;
        const brokerErrs = result.broker_errors ?? [];
        const detail =
          result.error ||
          brokerErrs[0]?.error ||
          (Array.isArray(result.errors) && result.errors[0]
            ? String(
                (result.errors[0] as { reason?: string }).reason ||
                  JSON.stringify(result.errors[0])
              )
            : null);
        if (closed === 0 && (skipped > 0 || brokerErrs.length > 0 || result.ok === false)) {
          alert(
            detail
              ? `Не удалось закрыть позиции: ${detail}`
              : 'Не удалось закрыть позиции: нет цен или ошибка брокера'
          );
        }
        this.logicTradeLots.clear();
        this.expandedTradeRows.clear();
        this.loadTradesForLogic(logicId);
        if (this.isClosedPositionsExpanded(logicId)) {
          this.loadLotsForClosedPositions(logicId);
        }
      },
      error: (err) => {
        this.closeAllLoading.delete(logicId);
        alert(err?.error?.error ?? err?.message ?? 'Ошибка закрытия позиций');
      },
    });
  }

  isOpenPositionTrade(trade: LogicTradeRow): boolean {
    if (trade.side_name !== 'Open') {
      return false;
    }
    const rem = trade.remaining_qty;
    if (rem == null) {
      return true;
    }
    return Number(rem) > 0;
  }

  private loadLotsForClosedPositions(logicId: number): void {
    for (const close of this.closePositionTrades(logicId)) {
      this.loadTradeLots(close.id);
    }
  }

  private loadLotsForOpenPositions(logicId: number): void {
    for (const open of this.openPositionTrades(logicId)) {
      const rem = open.remaining_qty ?? open.quantity;
      if (Number(open.quantity) > Number(rem)) {
        this.loadTradeLots(open.id);
      }
    }
  }

  toggleTradeRow(trade: LogicTradeRow, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.expandedTradeRows.has(trade.id)) {
      this.expandedTradeRows.delete(trade.id);
    } else {
      this.expandedTradeRows.add(trade.id);
      this.loadTradeLots(trade.id);
    }
  }

  isTradeRowExpanded(tradeId: number): boolean {
    return this.expandedTradeRows.has(tradeId);
  }

  isTradeLotsLoading(tradeId: number): boolean {
    return this.tradeLotsLoading.has(tradeId);
  }

  tradeLotsFor(tradeId: number): LogicTradeLotRow[] {
    return this.logicTradeLots.get(tradeId) ?? [];
  }

  tradeHasPackages(trade: LogicTradeRow): boolean {
    return trade.side_name === 'Close' || trade.side_name === 'Open';
  }

  tradeOperationLabel = tradeOperationLabel;
  tradeOperationHint = tradeOperationHint;
  costMethodLabel = costMethodLabel;

  formatPnl(value: number | null | undefined): string {
    if (value == null || !Number.isFinite(Number(value))) return '—';
    const n = Number(value);
    const formatted = this.formatMoney(Math.abs(n));
    if (n > 0) return `+${formatted}`;
    if (n < 0) return `−${formatted}`;
    return formatted;
  }

  /** % финреза от начального депозита (для колонок и скобок). */
  pnlDepositPct(
    pnl: number | null | undefined,
    initialBalance: number | null | undefined
  ): number | null {
    if (pnl == null || !Number.isFinite(Number(pnl))) return null;
    const initial = Number(initialBalance);
    if (!Number.isFinite(initial) || initial <= 0) return null;
    return (Number(pnl) / initial) * 100;
  }

  formatPnlPct(value: number | null | undefined): string {
    if (value == null || !Number.isFinite(Number(value))) return '—';
    const n = Number(value);
    const sign = n > 0 ? '+' : n < 0 ? '−' : '';
    return `${sign}${Math.abs(n).toFixed(2)}%`;
  }

  combatFinancialResultPct(logicId: number, initialBalance: number | null | undefined): number | null {
    return this.pnlDepositPct(this.combatFinancialResult(logicId), initialBalance);
  }

  testFinancialResultPct(logicId: number, initialBalance: number | null | undefined): number | null {
    // Старт теста — из test_initial_balance (если задан >0), иначе initial_balance,
    // иначе 1_000_000 — как в API бэктеста.
    let base = Number(initialBalance);
    const row = this.logics.find((l) => l.id === logicId);
    const testRaw = row ? Number(row.test_initial_balance) : 0;
    if (Number.isFinite(testRaw) && testRaw > 0) base = testRaw;
    if (!Number.isFinite(base) || base <= 0) base = 1_000_000;
    return this.pnlDepositPct(this.testFinancialResult(logicId), base);
  }

  requestTradeLots(tradeId: number): void {
    this.loadTradeLots(tradeId);
  }

  private loadTradeLots(tradeId: number): void {
    if (this.tradeLotsLoading.has(tradeId)) return;
    this.tradeLotsLoading.add(tradeId);
    this.logicsService.getLogicTradeLots(tradeId).subscribe({
      next: (rows) => {
        this.logicTradeLots.set(tradeId, rows);
        this.tradeLotsLoading.delete(tradeId);
      },
      error: () => {
        this.tradeLotsLoading.delete(tradeId);
      },
    });
  }

  tradesFor(logicId: number, isTest = false): LogicTradeRow[] {
    if (!isTest) {
      return this.logicTrades.get(Number(logicId)) ?? [];
    }
    const cached = this.testTradesViewByLogic.get(Number(logicId));
    if (cached) return cached;
    return this.logicTradesTest.get(Number(logicId)) ?? [];
  }

  rejectAlertFor(logicId: number): {
    warn: boolean;
    rejected_count: number;
    message: string | null;
  } | null {
    const row = this.logicRejectAlerts.get(Number(logicId));
    return row?.warn ? row : null;
  }

  rejectedTradesFor(logicId: number): LogicTradeRow[] {
    return this.logicRejectedTrades.get(Number(logicId)) ?? [];
  }

  onPeriodDialogOpen(open: boolean): void {
    this.uiInteractionPause = open;
  }

  /** Фильтр по run_id — один раз после HTTP, не в шаблоне на каждый CD. */
  private rebuildTestTradesView(logicId: number): void {
    const id = Number(logicId);
    const rows = this.logicTradesTest.get(id) ?? [];
    const runId = this.backtestRuns.get(id)?.id;
    let next = rows;
    if (runId != null) {
      const hasTagged = rows.some((t) => t.run_id != null);
      if (hasTagged) {
        next = rows.filter((t) => Number(t.run_id) === Number(runId));
      }
    }
    const prev = this.testTradesViewByLogic.get(id);
    if (prev && this.sameTradeListFingerprint(prev, next)) return;
    this.testTradesViewByLogic.set(id, next);
  }

  private sameTradeListFingerprint(a: LogicTradeRow[], b: LogicTradeRow[]): boolean {
    if (a === b) return true;
    if (a.length !== b.length) return false;
    if (a.length === 0) return true;
    const lastA = a[a.length - 1];
    const lastB = b[b.length - 1];
    const remA = Number(lastA.remaining_qty ?? lastA.quantity);
    const remB = Number(lastB.remaining_qty ?? lastB.quantity);
    return (
      a[0].id === b[0].id &&
      lastA.id === lastB.id &&
      Number(lastA.financial_result) === Number(lastB.financial_result) &&
      String(lastA.bar_dt) === String(lastB.bar_dt) &&
      remA === remB
    );
  }

  backtestFor(logicId: number): BacktestRunStatus | null {
    return this.backtestRuns.get(logicId) ?? null;
  }

  /** Даты периода теста из pnl-summary (для «год.%» когда прогон уже не в UI). */
  testPeriodFrom(logicId: number): string | null {
    const v = this.testPnlByLogic.get(Number(logicId))?.date_from;
    return v != null && String(v).trim() !== '' ? String(v) : null;
  }

  testPeriodTo(logicId: number): string | null {
    const v = this.testPnlByLogic.get(Number(logicId))?.date_to;
    return v != null && String(v).trim() !== '' ? String(v) : null;
  }

  timeframeIdForLogic(row: LogicRow): number | null {
    const draft = this.paramsDrafts.get(row.id);
    const tfName = (draft?.timeframe || row.timeframe || 'M15').trim();
    const byName = this.timeframesCatalog.find((t) => t.tf === tfName)?.id;
    if (byName != null) return byName;
    // fallback: M15 / первый из каталога
    return (
      this.timeframesCatalog.find((t) => t.tf === 'M15')?.id ??
      this.timeframesCatalog[0]?.id ??
      null
    );
  }

  signalIndicatorIdsFor(logicId: number): number[] {
    return this.signalIndicatorIdsByLogic.get(Number(logicId)) ?? [];
  }

  private rebuildSignalIndicatorIds(logicId: number): void {
    const ids = new Set<number>();
    for (const s of this.signalsFor(logicId)) {
      if (s.is_active && s.indicator_id != null) ids.add(Number(s.indicator_id));
    }
    const next = [...ids].sort((a, b) => a - b);
    const prev = this.signalIndicatorIdsByLogic.get(Number(logicId));
    if (prev && prev.length === next.length && prev.every((v, i) => v === next[i])) {
      return;
    }
    this.signalIndicatorIdsByLogic.set(Number(logicId), next);
  }

  isBacktestRunning(logicId: number): boolean {
    return this.backtestUi.isRunning(logicId);
  }

  /** Test run with offline OPT grid (paper lanes). */
  isBacktestOptRunning(logicId: number): boolean {
    if (!this.isBacktestRunning(logicId)) return false;
    return !!this.backtestRuns.get(logicId)?.opt_grid_enabled;
  }

  /** Plain test without OPT grid. */
  isBacktestPlainRunning(logicId: number): boolean {
    return this.isBacktestRunning(logicId) && !this.isBacktestOptRunning(logicId);
  }

  /** Bound in template so CD sees Map updates from the shared service. */
  backtestUiTick(): number {
    return this.backtestUi.uiTick;
  }

  backtestProgressPct(logicId: number): number {
    const pct = Number(this.backtestRuns.get(logicId)?.progress_pct);
    if (!Number.isFinite(pct)) return 0;
    return Math.max(0, Math.min(100, Math.round(pct)));
  }

  backtestProgressTitle(logicId: number): string {
    const run = this.backtestRuns.get(logicId);
    const opt = !!run?.opt_grid_enabled;
    if (!run) return opt ? 'Идёт тестирование с оптимизацией' : 'Идёт тестирование';
    const pct = this.backtestProgressPct(logicId);
    const phase = run.phase_message || run.status || '';
    const detail = run.phase_detail ? ` — ${run.phase_detail}` : '';
    const bar = formatHumanDate(run.current_bar_dt);
    const barPart = bar ? ` · ${bar}` : '';
    const period = formatDateRangeLabel(run.date_from, run.date_to);
    const periodPart = period ? ` (${period})` : '';
    const head = opt ? 'Тест+OPT' : 'Тест';
    return `${head} ${pct}%${barPart}: ${phase}${detail}${periodPart}`;
  }

  backtestCurrentBarLabel(logicId: number): string {
    return formatHumanDate(this.backtestRuns.get(logicId)?.current_bar_dt) || '';
  }

  isTradesLoading(logicId: number): boolean {
    return this.tradesLoading.has(logicId);
  }

  tradeActionLabel(trade: LogicTradeRow): string {
    return tradeOperationLabel(trade);
  }

  openTradeHasPartialCloses(trade: LogicTradeRow): boolean {
    const rem = trade.remaining_qty ?? trade.quantity;
    return Number(trade.quantity) > Number(rem);
  }

  formatTradeDt(iso: string): string {
    if (!iso) return '—';
    try {
      return new Date(iso).toLocaleString('ru-RU');
    } catch {
      return iso;
    }
  }

  securitiesFor(logicId: number): LogicSecurityRow[] {
    return this.logicSecurities.get(logicId) ?? [];
  }

  isSecuritiesLoading(logicId: number): boolean {
    return this.securitiesLoading.has(logicId);
  }

  securityKindLabel(row: LogicSecurityRow): string {
    return row.instrument_market === 'futures' ? 'Фьючерс' : 'Акция';
  }

  openSecurityPicker(logicId: number, event: Event): void {
    event.stopPropagation();
    this.securityPickerLogicId = logicId;
    this.pickerSelectedSecurityIds.clear();
    if (!this.expandedLogics.has(logicId)) {
      this.expandedLogics.add(logicId);
    }
    this.expandedSecuritiesBlocks.add(logicId);
    this.loadSecuritiesForLogic(logicId);
    this.ensureSecuritiesCatalogLoaded();
  }

  closeSecurityPicker(): void {
    this.securityPickerLogicId = null;
    this.pickerSelectedSecurityIds.clear();
  }

  isSecurityPickerOpen(logicId: number): boolean {
    return this.securityPickerLogicId === logicId;
  }

  toggleSecurityPickerSelection(securityId: number): void {
    if (this.pickerSelectedSecurityIds.has(securityId)) {
      this.pickerSelectedSecurityIds.delete(securityId);
    } else {
      this.pickerSelectedSecurityIds.add(securityId);
    }
  }

  isSecurityPickerSelected(securityId: number): boolean {
    return this.pickerSelectedSecurityIds.has(securityId);
  }

  pickerStocksAvailable(logicId: number): SecurityRow[] {
    const assigned = new Set(
      this.securitiesFor(logicId).map((s) => s.security_id)
    );
    return this.stocksCatalog.filter((s) => !assigned.has(s.id));
  }

  pickerFuturesAvailable(logicId: number): SecurityRow[] {
    const assigned = new Set(
      this.securitiesFor(logicId).map((s) => s.security_id)
    );
    return this.futuresCatalog.filter((s) => !assigned.has(s.id));
  }

  allStocksPickerSelected(logicId: number): boolean {
    const list = this.pickerStocksAvailable(logicId);
    return list.length > 0 && list.every((s) => this.pickerSelectedSecurityIds.has(s.id));
  }

  someStocksPickerSelected(logicId: number): boolean {
    const list = this.pickerStocksAvailable(logicId);
    const n = list.filter((s) => this.pickerSelectedSecurityIds.has(s.id)).length;
    return n > 0 && n < list.length;
  }

  allFuturesPickerSelected(logicId: number): boolean {
    const list = this.pickerFuturesAvailable(logicId);
    return list.length > 0 && list.every((s) => this.pickerSelectedSecurityIds.has(s.id));
  }

  someFuturesPickerSelected(logicId: number): boolean {
    const list = this.pickerFuturesAvailable(logicId);
    const n = list.filter((s) => this.pickerSelectedSecurityIds.has(s.id)).length;
    return n > 0 && n < list.length;
  }

  toggleAllStocksPicker(logicId: number, checked: boolean): void {
    for (const s of this.pickerStocksAvailable(logicId)) {
      if (checked) {
        this.pickerSelectedSecurityIds.add(s.id);
      } else {
        this.pickerSelectedSecurityIds.delete(s.id);
      }
    }
  }

  toggleAllFuturesPicker(logicId: number, checked: boolean): void {
    for (const s of this.pickerFuturesAvailable(logicId)) {
      if (checked) {
        this.pickerSelectedSecurityIds.add(s.id);
      } else {
        this.pickerSelectedSecurityIds.delete(s.id);
      }
    }
  }

  pickerFundsAvailable(logicId: number): SecurityRow[] {
    const assigned = new Set(
      this.securitiesFor(logicId).map((s) => s.security_id)
    );
    return this.fundsCatalog.filter((s) => !assigned.has(s.id));
  }

  allFundsPickerSelected(logicId: number): boolean {
    const list = this.pickerFundsAvailable(logicId);
    return list.length > 0 && list.every((s) => this.pickerSelectedSecurityIds.has(s.id));
  }

  someFundsPickerSelected(logicId: number): boolean {
    const list = this.pickerFundsAvailable(logicId);
    const n = list.filter((s) => this.pickerSelectedSecurityIds.has(s.id)).length;
    return n > 0 && n < list.length;
  }

  toggleAllFundsPicker(logicId: number, checked: boolean): void {
    for (const s of this.pickerFundsAvailable(logicId)) {
      if (checked) {
        this.pickerSelectedSecurityIds.add(s.id);
      } else {
        this.pickerSelectedSecurityIds.delete(s.id);
      }
    }
  }

  addSelectedSecurities(): void {
    if (this.securityPickerLogicId == null || this.pickerSelectedSecurityIds.size === 0) {
      return;
    }
    const logicId = this.securityPickerLogicId;
    const ids = [...this.pickerSelectedSecurityIds];
    this.logicsService.addLogicSecuritiesBulk(logicId, ids).subscribe({
      next: (created) => {
        const list = [...this.securitiesFor(logicId)];
        for (const row of created) {
          const idx = list.findIndex((x) => x.id === row.id);
          if (idx >= 0) {
            list[idx] = row;
          } else {
            list.push(row);
          }
        }
        this.logicSecurities.set(logicId, list);
        this.closeSecurityPicker();
      },
      error: (err) => {
        alert(err?.error?.error || 'Не удалось добавить бумаги');
      },
    });
  }

deleteLogicSecurity(row: LogicSecurityRow, event: Event): void {
    event.stopPropagation();
    this.logicsService.deleteLogicSecurity(row.id).subscribe({
      next: () => {
        const list = (this.logicSecurities.get(row.logic_id) ?? []).filter(
          (s) => s.id !== row.id
        );
        this.logicSecurities.set(row.logic_id, list);
      },
    });
  }

  private savingSecurityIds = new Set<number>();

  isSecurityActiveSaving(securityId: number): boolean {
    return this.savingSecurityIds.has(Number(securityId));
  }

  toggleSecurityActive(row: LogicSecurityRow, event: Event): void {
    event.stopPropagation();
    if (this.savingSecurityIds.has(row.id)) return;
    const next = !row.is_active;
    this.savingSecurityIds.add(row.id);
    this.logicsService.updateLogicSecurity(row.id, { is_active: next }).subscribe({
      next: (updated) => {
        this.savingSecurityIds.delete(row.id);
        const list = this.logicSecurities.get(row.logic_id) ?? [];
        const idx = list.findIndex((s) => s.id === updated.id);
        if (idx >= 0) {
          list[idx] = { ...list[idx], ...updated };
          this.logicSecurities.set(row.logic_id, [...list]);
        }
      },
      error: (err) => {
        this.savingSecurityIds.delete(row.id);
        alert(err?.error?.error || 'Не удалось изменить активность бумаги');
      },
    });
  }

  stopsFor(logicId: number): LogicStopRow[] {
    return this.logicStops.get(logicId) ?? [];
  }

  isStopsLoading(logicId: number): boolean {
    return this.stopsLoading.has(logicId);
  }

  openStopForm(logicId: number, ruleKind: LogicStopRuleKind, event: Event): void {
    event.stopPropagation();
    this.stopForm = { logicId, ruleKind };
    this.stopFormDraft = {
      // SL: по бумаге×стороне с возобновлением; TP: только по бумаге (портфельные TP недоступны)
      scope_type: ruleKind === 'stop_loss' ? 'security_resume' : 'security',
      value: '',
      value_unit: 'percent',
    };
    if (!this.expandedLogics.has(logicId)) {
      this.expandedLogics.add(logicId);
    }
    this.expandedStopsBlocks.add(logicId);
    this.loadStopsForLogic(logicId);
  }

  closeStopForm(): void {
    this.stopForm = null;
  }

  isStopFormOpen(logicId: number, ruleKind: LogicStopRuleKind): boolean {
    return (
      this.stopForm?.logicId === logicId && this.stopForm.ruleKind === ruleKind
    );
  }

  submitStopForm(): void {
    if (!this.stopForm) return;
    const value = Number(this.stopFormDraft.value.replace(',', '.'));
    if (!Number.isFinite(value) || value <= 0) {
      alert('Укажите положительное число в поле «Значение»');
      return;
    }
    const { logicId, ruleKind } = this.stopForm;
    if (!isStopScopeChoosable(this.stopFormDraft.scope_type, ruleKind)) {
      alert('Этот тип правила сейчас недоступен для выбора');
      return;
    }
    this.logicsService
      .createLogicStop({
        logic_id: logicId,
        rule_kind: ruleKind,
        scope_type: this.stopFormDraft.scope_type,
        value,
        value_unit: this.stopFormDraft.value_unit,
      })
      .subscribe({
        next: (created) => {
          const list = [...(this.logicStops.get(logicId) ?? []), created];
          this.logicStops.set(logicId, list);
          this.closeStopForm();
        },
        error: (err) => {
          alert(err?.error?.error || 'Не удалось добавить правило');
        },
      });
  }

  saveStopRow(
    stop: LogicStopRow,
    patch: {
      scope_type?: LogicStopScopeType;
      value?: number;
      value_unit?: LogicStopValueUnit;
    }
  ): void {
    if (this.savingStopIds.has(stop.id)) return;
    if (
      patch.scope_type != null &&
      !isStopScopeChoosable(patch.scope_type, stop.rule_kind)
    ) {
      return;
    }
    this.savingStopIds.add(stop.id);
    this.logicsService.updateLogicStop(stop.id, patch).subscribe({
      next: (updated) => {
        const list = this.logicStops.get(stop.logic_id) ?? [];
        this.logicStops.set(
          stop.logic_id,
          list.map((s) => (s.id === updated.id ? updated : s))
        );
        this.savingStopIds.delete(stop.id);
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.savingStopIds.delete(stop.id);
        alert(err?.error?.error || 'Не удалось сохранить правило стопа');
        // #1026: сервер отклонил изменение (например, тип TP) — возвращаем
        // в список его фактическое состояние, иначе select остаётся на
        // отвергнутом типе и выглядит как «сбилось».
        this.loadStopsForLogic(stop.logic_id, true);
      },
    });
  }

  toggleStopActive(stop: LogicStopRow, event: Event): void {
    event.stopPropagation();
    if (this.savingStopIds.has(stop.id)) return;
    const next = !stop.is_active;
    this.savingStopIds.add(stop.id);
    this.logicsService.updateLogicStop(stop.id, { is_active: next }).subscribe({
      next: (updated) => {
        const list = this.logicStops.get(stop.logic_id) ?? [];
        this.logicStops.set(
          stop.logic_id,
          list.map((s) => (s.id === updated.id ? updated : s))
        );
        this.savingStopIds.delete(stop.id);
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.savingStopIds.delete(stop.id);
        this.cdr.markForCheck();
        alert(err?.error?.error || 'Не удалось изменить активность стопа');
      },
    });
  }

  onStopFormScopeChange(scope: LogicStopScopeType): void {
    this.stopFormDraft.scope_type = scope;
  }

  onStopValueBlur(stop: LogicStopRow, raw: string): void {
    const value = Number(raw.replace(',', '.'));
    if (!Number.isFinite(value) || value <= 0 || value === stop.value) {
      return;
    }
    this.saveStopRow(stop, { value });
  }

  deleteStop(stop: LogicStopRow, event: Event): void {
    event.stopPropagation();
    this.logicsService.deleteLogicStop(stop.id).subscribe({
      next: () => {
        const list = (this.logicStops.get(stop.logic_id) ?? []).filter(
          (s) => s.id !== stop.id
        );
        this.logicStops.set(stop.logic_id, list);
      },
    });
  }

  isStopSaving(id: number): boolean {
    return this.savingStopIds.has(id);
  }

  signalsFor(logicId: number): LogicIndicatorSignalRow[] {
    return this.logicSignals.get(logicId) ?? [];
  }

  isSignalsLoading(logicId: number): boolean {
    return this.signalsLoading.has(logicId);
  }

  openSignalPicker(logicId: number, positionEvent: PositionEvent, event: Event): void {
    event.stopPropagation();
    this.signalPicker = {
      logicId,
      positionEvent,
      positionSide: 'long',
      signalKind: positionEvent === 'open' ? 'trend' : 'counter',
    };
    this.pickerSelectedIds.clear();
    if (!this.expandedLogics.has(logicId)) {
      this.expandedLogics.add(logicId);
    }
    this.expandedSignalsBlocks.add(logicId);
    this.loadSignalsForLogic(logicId);
  }

  onPickerSignalKindChange(kind: SignalKind): void {
    if (this.signalPicker) {
      this.signalPicker = { ...this.signalPicker, signalKind: kind };
    }
  }

  onPickerPositionSideChange(side: PositionSide): void {
    if (this.signalPicker) {
      this.signalPicker = { ...this.signalPicker, positionSide: side };
    }
  }

  // #1012: редактирование сигнала — карандаш в строке. Открывает тот же
  // picker, но в режиме изменения: предвыбран текущий индикатор, сохраняется
  // один сигнал, формула пересчитывается из выбранного индикатора и типа.
  openSignalEdit(signal: LogicIndicatorSignalRow, event: Event): void {
    event.stopPropagation();
    const logicId = signal.logic_id;
    this.signalPicker = {
      logicId,
      positionEvent: signal.position_event,
      positionSide: signal.position_side,
      signalKind: signal.signal_kind,
      editSignalId: signal.id,
    };
    this.pickerSelectedIds.clear();
    this.pickerSelectedIds.add(signal.indicator_id);
    if (!this.expandedLogics.has(logicId)) {
      this.expandedLogics.add(logicId);
    }
    this.expandedSignalsBlocks.add(logicId);
    this.loadSignalsForLogic(logicId);
  }

  isPickerEditing(): boolean {
    return this.signalPicker?.editSignalId != null;
  }

  pickerPreviewFormula(indicator: IndicatorRow): string {
    if (!this.signalPicker) return '';
    return buildLogicSignalFormula(indicator, this.signalPicker.signalKind);
  }

  closeSignalPicker(): void {
    this.signalPicker = null;
    this.pickerSelectedIds.clear();
  }

  isPickerOpen(logicId: number): boolean {
    return this.signalPicker?.logicId === logicId;
  }

  togglePickerSelection(indicatorId: number): void {
    if (this.signalPicker?.editSignalId != null) {
      // Режим редактирования: ровно один индикатор на сигнал.
      this.pickerSelectedIds.clear();
      this.pickerSelectedIds.add(indicatorId);
      return;
    }
    if (this.pickerSelectedIds.has(indicatorId)) {
      this.pickerSelectedIds.delete(indicatorId);
    } else {
      this.pickerSelectedIds.add(indicatorId);
    }
  }

  isPickerSelected(indicatorId: number): boolean {
    return this.pickerSelectedIds.has(indicatorId);
  }

  onPickerRowDblClick(indicator: IndicatorRow): void {
    if (!this.signalPicker) return;
    this.pickerSelectedIds.clear();
    this.pickerSelectedIds.add(indicator.id);
    this.addSelectedSignals();
  }

  addSelectedSignals(): void {
    if (!this.signalPicker || this.pickerSelectedIds.size === 0) return;
    if (this.signalPicker.editSignalId != null) {
      this.saveSignalEdit(this.signalPicker.editSignalId);
      return;
    }
    // #831: одинаковые сигналы разрешены — дубликаты не отфильтровываем.
    const { logicId, positionEvent, positionSide, signalKind } = this.signalPicker;
    const toAdd = [...this.pickerSelectedIds];
    if (toAdd.length === 0) {
      this.closeSignalPicker();
      return;
    }
    let pending = toAdd.length;
    for (const indicatorId of toAdd) {
      const ind = this.indicatorsCatalog.find((i) => i.id === indicatorId);
      if (!ind) {
        pending -= 1;
        continue;
      }
      const formula = buildLogicSignalFormula(ind, signalKind);
      this.logicsService
        .createLogicIndicatorSignal({
          logic_id: logicId,
          indicator_id: indicatorId,
          position_event: positionEvent,
          position_side: positionSide,
          signal_kind: signalKind,
          formula,
        })
        .subscribe({
          next: (created) => {
            const list = [...(this.logicSignals.get(logicId) ?? [])];
            const idx = list.findIndex((x) => x.id === created.id);
            if (idx >= 0) {
              list[idx] = created;
            } else {
              list.push(created);
            }
            this.logicSignals.set(logicId, list);
            this.formulaDrafts.set(created.id, created.formula);
            pending -= 1;
            if (pending === 0) {
              this.closeSignalPicker();
            }
          },
          error: () => {
            pending -= 1;
            if (pending === 0) {
              this.closeSignalPicker();
            }
          },
        });
    }
  }

  // #1012: сохранение отредактированного сигнала. Формула пересчитывается из
  // выбранного индикатора и типа; таймфрейм (tf=) из прежней формулы сохраняется.
  private saveSignalEdit(signalId: number): void {
    const picker = this.signalPicker;
    if (!picker) return;
    const indicatorId = [...this.pickerSelectedIds][0];
    const ind = this.indicatorsCatalog.find((i) => i.id === indicatorId);
    if (ind == null) {
      this.closeSignalPicker();
      return;
    }
    const signal = this.signalsFor(picker.logicId).find((s) => s.id === signalId);
    let formula = buildLogicSignalFormula(ind, picker.signalKind);
    if (signal) {
      const tf = extractSignalTf(this.formulaDraft(signal));
      if (tf.base) {
        formula = applySignalTf(formula, tf.base, tf.mult);
      }
    }
    this.savingFormulaIds.add(signalId);
    this.logicsService
      .updateLogicIndicatorSignal(signalId, {
        indicator_id: indicatorId,
        position_event: picker.positionEvent,
        position_side: picker.positionSide,
        signal_kind: picker.signalKind,
        formula,
      })
      .subscribe({
        next: (updated) => {
          const list = this.logicSignals.get(updated.logic_id) ?? [];
          this.logicSignals.set(
            updated.logic_id,
            list.map((s) => (s.id === updated.id ? updated : s))
          );
          this.formulaDrafts.set(updated.id, updated.formula);
          this.savingFormulaIds.delete(signalId);
          this.closeSignalPicker();
          this.cdr.markForCheck();
        },
        error: () => {
          this.savingFormulaIds.delete(signalId);
          this.cdr.markForCheck();
        },
      });
  }

  formulaDraft(signal: LogicIndicatorSignalRow): string {
    return this.formulaDrafts.get(signal.id) ?? signal.formula;
  }

  isSignalFormulaHelpOpen(signal: LogicIndicatorSignalRow): boolean {
    return this.signalFormulaHelpIds.has(signal.id);
  }

  toggleSignalFormulaHelp(signal: LogicIndicatorSignalRow, event: Event): void {
    event.stopPropagation();
    if (this.signalFormulaHelpIds.has(signal.id)) {
      this.signalFormulaHelpIds.delete(signal.id);
    } else {
      this.signalFormulaHelpIds.add(signal.id);
    }
    this.cdr.markForCheck();
  }

  signalFormulaHelpText(): string {
    if (this.signalFormulaHelpCache === null) {
      this.signalFormulaHelpCache = buildSignalFormulaHelp(this.indicatorsCatalog ?? []);
    }
    return this.signalFormulaHelpCache;
  }

  isSignalsFormulaHelpOpen(logicId: number): boolean {
    return this.signalsHelpBlocks.has(logicId);
  }

  toggleSignalsFormulaHelp(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.signalsHelpBlocks.has(logicId)) {
      this.signalsHelpBlocks.delete(logicId);
      this.cdr.markForCheck();
      return;
    }
    // Блок свёрнут — раскрыть, чтобы справка была видна.
    if (!this.expandedSignalsBlocks.has(logicId)) {
      this.expandedSignalsBlocks.add(logicId);
      this.loadSignalsForLogic(logicId);
      this.refreshOptGridAvailability(logicId);
    }
    this.signalsHelpBlocks.add(logicId);
    this.cdr.markForCheck();
  }

  isAutoOptHelpOpen(logicId: number): boolean {
    return this.autoOptHelpBlocks.has(logicId);
  }

  toggleAutoOptHelp(logicId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    if (this.autoOptHelpBlocks.has(logicId)) {
      this.autoOptHelpBlocks.delete(logicId);
    } else {
      this.autoOptHelpBlocks.add(logicId);
    }
    this.cdr.markForCheck();
  }

  autoOptimizeHelpText(): string {
    return [
      'Авто оптимизация (по умолчанию выкл.).',
      '',
      'При КАЖДОМ закрытии позиции логика подстраивает главный период (period)',
      'сигналов входа этой стороны. Работает и в бою, и в бэктесте.',
      '',
      '1. Закрытие в плюс:',
      '   Сравниваем фактическую цену входа с ценой на предыдущем баре.',
      '   Если вход на бар раньше дал бы больше прибыли для этой стороны',
      '   (лонг: цена раньше ниже входа; шорт: выше входа),',
      '   меняем period так, чтобы сигнал сработал на этом более раннем баре',
      '   (подбирается ближайший ±period, дающий срабатывание).',
      '   Если ранний вход не выгоднее — ничего не меняем.',
      '',
      '2. Закрытие в минус:',
      '   Ужесточаем требование сигнала так, чтобы на баре фактического входа',
      '   сигнал БОЛЬШЕ не срабатывал (подбирается ближайший ±period).',
      '',
      'Изменённый период сохраняется в формулу сигнала и применяется к индикатору.',
      'Действие пишется в техжурнал.',
    ].join('\n');
  }

  onFormulaInput(signal: LogicIndicatorSignalRow, value: string): void {
    this.formulaDrafts.set(signal.id, value);
  }

  /** #1030: один раз загружаем границы параметров индикаторов. */
  private loadIndicatorBounds(): void {
    this.logicsService.getIndicatorParamBounds().subscribe({
      next: (rows) => {
        const map = new Map<string, IndicatorParamBound[]>();
        for (const r of rows || []) {
          const code = String(r.indicator_code || '').toUpperCase();
          if (!code) continue;
          const list = map.get(code) ?? [];
          list.push(r);
          map.set(code, list);
        }
        this.indicatorBoundsByCode = map;
        this.cdr.markForCheck();
      },
      error: () => undefined,
    });
  }

  /** #1030: есть ли у сигнала параметры с заданными границами. */
  sigHasStrictness(sig: LogicIndicatorSignalRow): boolean {
    return this.signalBounds(sig).length > 0;
  }

  private signalBounds(sig: LogicIndicatorSignalRow): IndicatorParamBound[] {
    const code = String(sig.indicator_code || '').toUpperCase();
    const all = this.indicatorBoundsByCode.get(code) ?? [];
    if (all.length === 0) return [];
    const values = formulaParamValues(this.formulaDraft(sig));
    return all.filter((b) => values[b.param_key] != null);
  }

  /** #1033: фон полосы сигнала — розовый к «строже», голубой к «мягче». */
  signalRowBackground(sig: LogicIndicatorSignalRow): string {
    if (!this.sigHasStrictness(sig)) return '';
    return strictnessRowBackground(this.strictnessValue(sig));
  }

  /** #1030: положение ползунка вычисляется из текущих параметров формулы. */
  strictnessValue(sig: LogicIndicatorSignalRow): number {
    return strictnessPositionFromFormula(
      this.formulaDraft(sig),
      this.signalBounds(sig),
      sig.indicator_code
    );
  }

  /** Ползунок 0..100 — абсолютное положение: 0 строже, 100 мягче. */
  onStrictnessInput(sig: LogicIndicatorSignalRow, raw: number | string): void {
    const pos = Math.min(100, Math.max(0, Number(raw) || 0));
    const next = applyStrictnessToFormula(
      this.formulaDraft(sig),
      this.signalBounds(sig),
      pos,
      sig.indicator_code
    );
    this.formulaDrafts.set(sig.id, next);
  }

  /** Отпустили ползунок — сохраняем формулу; положение остаётся на месте. */
  applyStrictness(sig: LogicIndicatorSignalRow): void {
    this.saveSignalFormula(sig);
  }

  /** #1031: клик по метке в центре — сброс строгости на середину диапазона. */
  resetStrictness(sig: LogicIndicatorSignalRow, event?: Event): void {
    event?.stopPropagation();
    const next = applyStrictnessToFormula(
      this.formulaDraft(sig),
      this.signalBounds(sig),
      50,
      sig.indicator_code
    );
    this.formulaDrafts.set(sig.id, next);
    this.applyStrictness(sig);
  }

  /** Каталог базовых ТФ для tf= сигнала (#843). */
  readonly signalTfBases = [
    'M1', 'M2', 'M3', 'M5', 'M10', 'M15', 'M20', 'M30',
    'H1', 'H2', 'H4', 'H6', 'H8', 'H12', 'D1',
  ] as const;

  signalTfBase(formulaDraft: string): string {
    return extractSignalTf(formulaDraft).base;
  }

  signalTfMult(formulaDraft: string): number | null {
    return extractSignalTf(formulaDraft).mult;
  }

  private setSignalTf(
    signal: LogicIndicatorSignalRow,
    base: string,
    mult: number | null
  ): void {
    const next = applySignalTf(this.formulaDraft(signal), base, mult);
    if (next === this.formulaDraft(signal)) {
      return;
    }
    this.formulaDrafts.set(signal.id, next);
    this.saveSignalFormula(signal);
  }

  onSignalTfBaseChange(signal: LogicIndicatorSignalRow, base: string): void {
    const mult = this.signalTfMult(this.formulaDraft(signal));
    this.setSignalTf(signal, base, base ? (mult ?? 1) : null);
  }

  onSignalTfMultChange(signal: LogicIndicatorSignalRow, raw: number | string | null): void {
    const draft = this.formulaDraft(signal);
    const base = this.signalTfBase(draft);
    if (!base) {
      return; // множитель имеет смысл только с выбранной базой
    }
    if (raw === null || raw === '' || Number(raw) <= 1) {
      this.setSignalTf(signal, base, null);
      return;
    }
    const n = Math.round(Number(raw));
    this.setSignalTf(signal, base, Number.isFinite(n) && n >= 2 ? n : null);
  }

  formulaParseHint(signal: LogicIndicatorSignalRow): string | null {
    const parsed = parseSignalFormula(this.formulaDraft(signal));
    if (parsed.valid) return null;
    return parsed.errors[0] ?? 'Неверный формат';
  }

  onSignalActsOnChange(
    signal: LogicIndicatorSignalRow,
    next: 'security' | 'base_asset' | 'contango' | string
  ): void {
    const actsOn =
      next === 'base_asset' ? 'base_asset' : next === 'contango' ? 'contango' : 'security';
    if ((signal.signal_acts_on || 'security') === actsOn || this.savingFormulaIds.has(signal.id)) {
      return;
    }
    this.savingFormulaIds.add(signal.id);
    this.logicsService
      .updateLogicIndicatorSignal(signal.id, {
        formula: this.formulaDraft(signal).trim() || signal.formula,
        signal_acts_on: actsOn,
      })
      .subscribe({
        next: (updated) => {
          const list = this.logicSignals.get(signal.logic_id) ?? [];
          this.logicSignals.set(
            signal.logic_id,
            list.map((s) => (s.id === updated.id ? updated : s))
          );
          this.formulaDrafts.set(updated.id, updated.formula);
          this.savingFormulaIds.delete(signal.id);
          this.cdr.markForCheck();
        },
        error: () => {
          this.savingFormulaIds.delete(signal.id);
          this.cdr.markForCheck();
        },
      });
  }

  /** #972: подтверждение типа сигнала — секунды ожидания направления цены (0 = не подтверждать). */
  onSignalConfirmSecChange(signal: LogicIndicatorSignalRow, next: string): void {
    const nextSec = Number(next);
    const confirmSec = Number.isInteger(nextSec) && nextSec >= 0 ? nextSec : 0;
    if ((signal.signal_confirm_sec || 0) === confirmSec || this.savingFormulaIds.has(signal.id)) {
      return;
    }
    this.savingFormulaIds.add(signal.id);
    this.logicsService
      .updateLogicIndicatorSignal(signal.id, {
        formula: this.formulaDraft(signal).trim() || signal.formula,
        signal_confirm_sec: confirmSec,
      })
      .subscribe({
        next: (updated) => {
          const list = this.logicSignals.get(signal.logic_id) ?? [];
          this.logicSignals.set(
            signal.logic_id,
            list.map((s) => (s.id === updated.id ? updated : s))
          );
          this.formulaDrafts.set(updated.id, updated.formula);
          this.savingFormulaIds.delete(signal.id);
          this.cdr.markForCheck();
        },
        error: () => {
          this.savingFormulaIds.delete(signal.id);
          this.cdr.markForCheck();
        },
      });
  }

  saveSignalFormula(signal: LogicIndicatorSignalRow): void {
    const draft = this.formulaDraft(signal).trim();
    if (!draft || draft === signal.formula || this.savingFormulaIds.has(signal.id)) {
      return;
    }
    this.savingFormulaIds.add(signal.id);
    this.logicsService.updateLogicIndicatorSignal(signal.id, { formula: draft }).subscribe({
      next: (updated) => {
        const list = this.logicSignals.get(signal.logic_id) ?? [];
        this.logicSignals.set(
          signal.logic_id,
          list.map((s) => (s.id === updated.id ? updated : s))
        );
        this.formulaDrafts.set(updated.id, updated.formula);
        this.savingFormulaIds.delete(signal.id);
      },
      error: () => {
        this.formulaDrafts.set(signal.id, signal.formula);
        this.savingFormulaIds.delete(signal.id);
      },
    });
  }

  toggleSignalActive(signal: LogicIndicatorSignalRow, event: Event): void {
    event.stopPropagation();
    if (this.savingFormulaIds.has(signal.id)) return;
    const next = !signal.is_active;
    this.savingFormulaIds.add(signal.id);
    this.logicsService
      .updateLogicIndicatorSignal(signal.id, {
        formula: this.formulaDraft(signal).trim() || signal.formula,
        is_active: next,
      })
      .subscribe({
        next: (updated) => {
          const list = this.logicSignals.get(signal.logic_id) ?? [];
          this.logicSignals.set(
            signal.logic_id,
            list.map((s) => (s.id === updated.id ? updated : s))
          );
          this.formulaDrafts.set(updated.id, updated.formula);
          this.savingFormulaIds.delete(signal.id);
          this.cdr.markForCheck();
        },
        error: () => {
          this.formulaDrafts.set(signal.id, signal.formula);
          this.savingFormulaIds.delete(signal.id);
          this.cdr.markForCheck();
        },
      });
  }

  deleteSignal(signal: LogicIndicatorSignalRow, event: Event): void {
    event.stopPropagation();
    this.logicsService.deleteLogicIndicatorSignal(signal.id).subscribe({
      next: () => {
        const list = (this.logicSignals.get(signal.logic_id) ?? []).filter(
          (s) => s.id !== signal.id
        );
        this.logicSignals.set(signal.logic_id, list);
        this.formulaDrafts.delete(signal.id);
      },
    });
  }

  openAdd(): void {
    this.editorMode = 'add';
    this.editorLogic = null;
    this.editorOpen = true;
  }

  openEdit(row: LogicRow, event: Event): void {
    event.stopPropagation();
    this.editorMode = 'edit';
    this.editorLogic = row;
    this.editorOpen = true;
  }

  closeEditor(): void {
    this.editorOpen = false;
    this.editorLogic = null;
  }

  onEditorSaved(created: LogicRow | null = null): void {
    const editedId = this.editorLogic?.id;
    if (editedId != null) {
      // После смены счёта API чистит боевые сделки — сбросить кэш панели.
      this.logicTrades.delete(editedId);
      this.expandedTradeRows.clear();
      if (this.expandedTradesBlocks.has(editedId)) {
        this.loadTradesForLogic(editedId, true);
      }
    }
    // Новая логика: добавить в список сразу (без перезагрузки), раскрыть все логики,
    // развернуть новую строку и доскроллить до неё — как при копировании.
    if (created != null && !this.logics.some((l) => l.id === created.id)) {
      this.logics = [...this.logics, created].sort((a, b) => a.id - b.id);
      this.showAllLogics = true;
      this.sortColumn = null;
      this.expandedLogics.add(created.id);
      this.ensureParamsDraft(created.id, true);
      this.loadParamsForLogic(created.id);
      setTimeout(() => this.scrollLogicIntoView(created.id), 0);
      return;
    }
    this.loadLogicsOnce();
  }

  deleteLogic(row: LogicRow, event: Event): void {
    event.stopPropagation();
    const ok = confirm(`Удалить логику «${row.name}»?`);
    if (!ok) return;
    this.logicsService.deleteLogic(row.id).subscribe({
      next: () => {
        this.logicSignals.delete(row.id);
        this.logicStops.delete(row.id);
        this.logicSecurities.delete(row.id);
        this.logicTrades.delete(row.id);
        this.expandedLogics.delete(row.id);
        this.expandedSecuritiesBlocks.delete(row.id);
        this.expandedTradesBlocks.delete(row.id);
        this.selectedExportIds.delete(row.id);
        this.loadLogicsOnce();
      },
      error: (err) => {
        alert(err?.error?.error || 'Не удалось удалить логику');
      },
    });
  }

  /** Открыть диалог копирования: спрашиваем имя и примечание новой логики. */
  copyLogic(row: LogicRow, event: Event): void {
    event.stopPropagation();
    if (this.copyingLogicIds.has(row.id)) return;
    this.copyDialogSource = row;
    this.copyDialogName = `${row.name} copy`;
    this.copyDialogNote = row.note ?? '';
    this.copyDialogError = null;
    this.copyDialogBusy = false;
    this.copyDialogOpen = true;
    setTimeout(() => {
      const input = this.copyLogicNameInput?.nativeElement;
      if (input) {
        input.focus();
        input.select();
      }
    }, 0);
  }

  cancelCopyLogic(): void {
    if (this.copyDialogBusy) return;
    this.copyDialogOpen = false;
    this.copyDialogSource = null;
    this.copyDialogError = null;
  }

  confirmCopyLogic(): void {
    const source = this.copyDialogSource;
    if (!source) return;
    const name = this.copyDialogName.trim();
    if (!name) {
      this.copyDialogError = 'Укажите имя новой логики';
      return;
    }
    if (this.copyingLogicIds.has(source.id)) return;
    this.copyingLogicIds.add(source.id);
    this.copyDialogBusy = true;
    this.copyDialogError = null;
    const note = this.copyDialogNote.trim();
    this.logicsService
      .copyLogic(source.id, { name, note: note.length ? note : null })
      .subscribe({
        next: (created) => {
          this.copyingLogicIds.delete(source.id);
          this.copyDialogBusy = false;
          this.copyDialogOpen = false;
          this.copyDialogSource = null;
          this.logics = [...this.logics, created].sort((a, b) => a.id - b.id);
          this.showAllLogics = true;
          this.sortColumn = null;
          this.expandedLogics.add(created.id);
          this.ensureParamsDraft(created.id, true);
          this.loadSignalsForLogic(created.id, true);
          this.loadStopsForLogic(created.id);
          this.loadSecuritiesForLogic(created.id);
          // After OK: list is already updated/expanded — scroll so the new row is on screen.
          setTimeout(() => this.scrollLogicIntoView(created.id), 0);
        },
        error: (err) => {
          this.copyingLogicIds.delete(source.id);
          this.copyDialogBusy = false;
          this.copyDialogError =
            err?.error?.error || 'Не удалось скопировать логику';
        },
      });
  }

  isExportSelected(logicId: number): boolean {
    return this.selectedExportIds.has(logicId);
  }

  toggleExportSelection(logicId: number, checked: boolean): void {
    if (checked) {
      this.selectedExportIds.add(logicId);
    } else {
      this.selectedExportIds.delete(logicId);
    }
  }

  allExportSelected(): boolean {
    return (
      this.logics.length > 0 &&
      this.logics.every((r) => this.selectedExportIds.has(r.id))
    );
  }

  toggleAllExport(checked: boolean): void {
    if (checked) {
      for (const r of this.logics) {
        this.selectedExportIds.add(r.id);
      }
    } else {
      this.selectedExportIds.clear();
    }
  }

  exportSelectedLogics(): void {
    const ids = this.logics
      .filter((r) => this.selectedExportIds.has(r.id))
      .map((r) => r.id);
    if (ids.length === 0) {
      alert('Отметьте логики для экспорта (чекбокс справа)');
      return;
    }
    this.downloadLogicExport(ids);
  }

  private downloadLogicExport(ids: number[], preferredName?: string): void {
    if (this.exportImportBusy) return;
    this.exportImportBusy = true;
    this.logicsService.exportLogics(ids).subscribe({
      next: (bundle) => {
        this.exportImportBusy = false;
        const names = (bundle.logics || []).map((l) => l.name);
        const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
        const safe =
          String(preferredName || names[0] || 'logics')
            .replace(/[^\w\-а-яА-ЯёЁ]+/g, '_')
            .slice(0, 60) || 'logics';
        const blob = new Blob([JSON.stringify(bundle, null, 2)], {
          type: 'application/json;charset=utf-8',
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download =
          ids.length === 1
            ? `multilogic-logic-${safe}-${stamp}.json`
            : `multilogic-logics-${stamp}.json`;
        a.click();
        URL.revokeObjectURL(url);
        const optN = (bundle.logics || []).filter(
          (l) =>
            Array.isArray(l.last_opt_grid?.results) &&
            (l.last_opt_grid?.results?.length ?? 0) > 0
        ).length;
        alert(
          (names.length === 1
            ? `Экспортирована логика: ${names[0]}`
            : `Экспортированы логики (${names.length}):\n${names.join('\n')}`) +
            (optN
              ? `\n(с кэшем OPT: ${optN})`
              : '') +
            `\nБез сделок, свечей и тестов.`
        );
      },
      error: (err) => {
        this.exportImportBusy = false;
        alert(err?.error?.error || 'Не удалось экспортировать логики');
      },
    });
  }

  /** Download complete trades JSON (params/signals/stops + all trade flags) for AI analysis. */
  exportLogicTrades(logicId: number, isTest: boolean): void {
    const key = `${logicId}:${isTest ? 'test' : 'live'}`;
    if (this.tradesExportBusy.has(key)) return;
    this.tradesExportBusy.add(key);
    const runId = isTest ? (this.backtestRuns.get(Number(logicId))?.id ?? null) : null;
    this.logicsService.exportLogicTrades(logicId, isTest, runId).pipe(takeUntil(this.destroy$)).subscribe({
      next: (bundle) => {
        this.tradesExportBusy.delete(key);
        const logicName = String(bundle?.logic?.name || `logic-${logicId}`)
          .replace(/[^\w\-а-яА-ЯёЁ]+/g, '_')
          .slice(0, 60);
        const mode = isTest ? 'test' : 'live';
        const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
        const run = isTest ? this.backtestRuns.get(Number(logicId)) : null;
        const from = String(run?.date_from || '').slice(0, 10);
        const to = String(run?.date_to || '').slice(0, 10);
        const periodBit =
          from && to ? `_${from}_${to}` : from ? `_${from}` : to ? `_${to}` : '';
        const blob = new Blob([JSON.stringify(bundle, null, 2)], {
          type: 'application/json;charset=utf-8',
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `multilogic-trades-${mode}-${logicName}${periodBit}-${stamp}.json`;
        a.click();
        URL.revokeObjectURL(url);
        const n = Number(bundle?.counts?.['total'] ?? bundle?.trades?.length ?? 0);
        const shadow = Number(bundle?.counts?.['shadow'] ?? 0);
        alert(
          `Экспорт ${mode === 'test' ? 'теста' : 'боя'}: ${n} сделок` +
            (shadow ? ` (из них shadow: ${shadow})` : '') +
            `\nФайл: ${a.download}`
        );
      },
      error: (err) => {
        this.tradesExportBusy.delete(key);
        alert(err?.error?.error || 'Не удалось экспортировать сделки');
      },
    });
  }

  triggerImportLogics(event?: Event): void {
    event?.stopPropagation();
    if (this.exportImportBusy) return;
    const input = this.logicImportFile?.nativeElement;
    if (!input) return;
    input.value = '';
    input.click();
  }

  onImportFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    if (this.exportImportBusy) return;
    this.exportImportBusy = true;
    const reader = new FileReader();
    reader.onload = () => {
      let bundle: LogicExportBundle;
      try {
        bundle = JSON.parse(String(reader.result || '')) as LogicExportBundle;
      } catch {
        this.exportImportBusy = false;
        this.openImportDialog(
          buildImportLocalErrorModel('Файл не является корректным JSON')
        );
        this.cdr.markForCheck();
        return;
      }
      this.logicsService
        .importLogics(bundle, { overwriteByName: true })
        .subscribe({
          next: (result) => {
            this.exportImportBusy = false;
            this.loadLogicsOnce();
            for (const r of result.imported || []) {
              this.refreshOptGridAvailability(r.id);
            }
            this.openImportDialog(buildImportSuccessModel(result));
            this.cdr.markForCheck();
          },
          error: (err) => {
            this.exportImportBusy = false;
            const body = err?.error;
            const protocol =
              typeof body?.protocol === 'string' ? body.protocol : '';
            const msg =
              body?.error || err?.message || 'Не удалось импортировать логики';
            this.openImportDialog(
              buildImportFailureModel(msg, protocol, body?.detail)
            );
            this.cdr.markForCheck();
          },
        });
    };
    reader.onerror = () => {
      this.exportImportBusy = false;
      this.openImportDialog(
        buildImportLocalErrorModel('Не удалось прочитать файл')
      );
      this.cdr.markForCheck();
    };
    reader.readAsText(file, 'utf-8');
  }

  private openImportDialog(model: ImportDialogModel): void {
    this.importDialog = model;
    this.importDialogOpen = true;
    this.importProtocolOpen = false;
    this.importProtocolCopied = false;
  }

  closeImportDialog(): void {
    this.importDialogOpen = false;
    this.importProtocolOpen = false;
    this.importProtocolCopied = false;
  }

  toggleImportProtocol(): void {
    this.importProtocolOpen = !this.importProtocolOpen;
  }

  async copyImportProtocol(): Promise<void> {
    const text = this.importDialog?.protocol || '';
    if (!text) return;
    let copied = false;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
        copied = true;
      }
    } catch {
      copied = false;
    }
    if (!copied) {
      try {
        const area = document.createElement('textarea');
        area.value = text;
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        copied = document.execCommand('copy');
        document.body.removeChild(area);
      } catch {
        copied = false;
      }
    }
    this.importProtocolCopied = copied;
    this.cdr.markForCheck();
  }

  private scrollLogicIntoView(logicId: number): void {
    const el = document.querySelector(
      `.logic-main-row[data-logic-id="${logicId}"]`,
    ) as HTMLElement | null;
    el?.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
  }

  isCopying(row: LogicRow): boolean {
    return this.copyingLogicIds.has(row.id);
  }

  onEnabledChange(row: LogicRow, checked: boolean, event: Event): void {
    event.stopPropagation();
    if (this.savingIds.has(row.id)) return;

    // Фейк-счёт: котировки с глобального TBANK_API_TOKEN (один на все логики/копии).
    if (checked && row.account_type === 'fake') {
      this.settings.getTbankTokenConfigured().subscribe({
        next: (status) => {
          if (!status.has_token) {
            this.pendingEnableLogic = row;
            this.tbankTokenDialogContext = 'logic';
            this.tbankTokenDialogReason = 'missing';
            this.tbankTokenDialogOpen = true;
            return;
          }
          this.applyEnabledChange(row, checked);
        },
        error: () => this.applyEnabledChange(row, checked),
      });
      return;
    }

    this.applyEnabledChange(row, checked);
  }

  onTbankTokenSavedForLogic(): void {
    this.tbankTokenDialogOpen = false;
    this.lastTbankTokenCheckAt = Date.now();
    const row = this.pendingEnableLogic;
    const pendingBt = this.pendingBacktest;
    this.pendingEnableLogic = null;
    this.pendingBacktest = null;
    this.settings.getTbankTokenStatus(true).subscribe({
      next: (status) => {
        this.applyTbankTokenStatus(status);
        if (row && status.has_token) {
          this.applyEnabledChange(row, true);
        }
        if (pendingBt && status.has_token) {
          this.doStartBacktestRun(pendingBt.logicId, pendingBt.period);
        }
      },
      error: () => {},
    });
  }

  onTbankTokenCancelledForLogic(): void {
    this.tbankTokenDialogOpen = false;
    this.pendingEnableLogic = null;
    this.pendingBacktest = null;
  }

  openTbankTokenDialogFromAlert(event?: Event): void {
    event?.preventDefault();
    event?.stopPropagation();
    if (this.tbankTokenDialogOpen) return;
    const alert = this.tbankTokenAlert;
    this.tbankTokenDialogContext = 'trades';
    this.tbankTokenDialogReason = alert?.reason ?? 'missing';
    this.tbankTokenDialogOpen = true;
  }

  tbankTokenAlertShortLabel(): string {
    if (!this.tbankTokenAlert) return '';
    return this.tbankTokenAlert.reason === 'invalid'
      ? 'Токен T-Bank неактивен'
      : 'Токен T-Bank не задан';
  }

  private hasEnabledLogic(): boolean {
    return this.logics.some((l) => l.is_enabled);
  }

  private applyTbankTokenStatus(status: {
    has_token: boolean;
    valid?: boolean;
    error_message?: string | null;
  }): void {
    if (!this.hasEnabledLogic() || status.valid) {
      this.tbankTokenAlert = null;
      return;
    }
    const reason: 'missing' | 'invalid' = status.has_token ? 'invalid' : 'missing';
    this.tbankTokenAlert = {
      reason,
      message:
        status.error_message?.trim() ||
        (reason === 'invalid'
          ? 'Токен T-Bank неактивен или просрочен. Нажмите, чтобы ввести новый API-токен.'
          : 'Токен T-Bank не задан. Нажмите, чтобы ввести API-токен для котировок и сделок.'),
    };
  }

  /** Проверка токена для runner: баннер + диалог только по клику. */
  private maybeCheckTbankTokenForTrades(): void {
    if (!this.hasEnabledLogic()) {
      this.tbankTokenAlert = null;
      return;
    }

    const now = Date.now();
    if (now - this.lastTbankTokenCheckAt < this.tbankTokenCheckMs) return;
    this.lastTbankTokenCheckAt = now;

    this.settings.getTbankTokenStatus(true).subscribe({
      next: (status) => this.applyTbankTokenStatus(status),
      error: () => {},
    });
  }

  private applyEnabledChange(row: LogicRow, checked: boolean): void {
    const previous = row.is_enabled;
    row.is_enabled = checked;
    this.savingIds.add(row.id);
    this.logicsService.updateLogicEnabled(row.id, checked).subscribe({
      next: (resp) => {
        this.savingIds.delete(row.id);
        row.is_enabled = resp.is_enabled;
        this.techLog.event(
          this.techLog.logicThreadKey(row.id, 'control'),
          checked ? 'logic.enabled' : 'logic.disabled',
          checked ? 'Логика включена (UI)' : 'Логика выключена (UI)',
          { logicId: row.id, payload: resp }
        );
        if (resp.warmup_pretest?.started) {
          this.backtestUi.watch(row.id);
          this.expandedLogics.add(row.id);
          this.expandedTestTradesBlocks.add(row.id);
          return;
        }
        if (checked) {
          this.lastTbankTokenCheckAt = 0;
          this.maybeCheckTbankTokenForTrades();
          const precalc = resp?.rating_precalc;
          if (precalc) {
            this.ratingPrecalcByLogic.set(row.id, precalc);
          }
          this.watchRatingPrecalc(row.id);
        } else if (!this.hasEnabledLogic()) {
          this.tbankTokenAlert = null;
        }
      },
      error: () => {
        row.is_enabled = previous;
        this.savingIds.delete(row.id);
      },
    });
  }

  onTerminalSignalChange(row: LogicRow, checked: boolean, event: Event): void {
    event.stopPropagation();
    if (this.savingSignalIds.has(row.id)) return;
    const previous = row.use_as_terminal_signal ?? false;
    row.use_as_terminal_signal = checked;
    this.savingSignalIds.add(row.id);
    this.logicsService.updateLogicTerminalSignal(row.id, checked).subscribe({
      next: (resp) => {
        this.savingSignalIds.delete(row.id);
        row.use_as_terminal_signal = resp.use_as_terminal_signal;
        this.techLog.event(
          this.techLog.logicThreadKey(row.id, 'control'),
          checked ? 'logic.terminal_signal.on' : 'logic.terminal_signal.off',
          checked
            ? 'Логика выдаёт сигналы в терминал (UI)'
            : 'Логика больше не выдаёт сигналы в терминал (UI)',
          { logicId: row.id, payload: resp }
        );
      },
      error: () => {
        row.use_as_terminal_signal = previous;
        this.savingSignalIds.delete(row.id);
      },
    });
  }

  combatSignalKey(logicId: number, signalId: number): string {
    return `${logicId}:${signalId}`;
  }

  isCombatSignalExpanded(logicId: number, signalId: number): boolean {
    return this.expandedCombatSignals.has(this.combatSignalKey(logicId, signalId));
  }

  toggleCombatSignal(logicId: number, signalId: number, event: Event): void {
    event.preventDefault();
    event.stopPropagation();
    const key = this.combatSignalKey(logicId, signalId);
    if (this.expandedCombatSignals.has(key)) {
      this.expandedCombatSignals.delete(key);
      return;
    }
    this.expandedCombatSignals.add(key);
    this.loadSecuritiesForLogic(logicId);
  }

  isRatingPrecalcActive(logicId: number): boolean {
    const s = this.ratingPrecalcByLogic.get(logicId);
    return !!s && (s.status === 'pending' || s.status === 'running');
  }

  ratingPrecalcTitle(logicId: number): string {
    const s = this.ratingPrecalcByLogic.get(logicId);
    if (!s) return '';
    const pct = Math.round(Number(s.progress_pct) || 0);
    return `Предрасчёт рейтинга: ${s.phase_message || s.status} (${pct}%)`;
  }

  combatReloadToken(logicId: number): number {
    return this.combatRatingReloadToken.get(logicId) ?? 0;
  }

  private watchRatingPrecalc(logicId: number): void {
    if (this.ratingPrecalcPollIds.has(logicId)) return;
    this.ratingPrecalcPollIds.add(logicId);
    const pollOnce = () => {
      this.logicsService.getSignalRatingPrecalc(logicId).subscribe({
        next: (status) => {
          this.ratingPrecalcByLogic.set(logicId, status);
          if (status.status === 'pending' || status.status === 'running') {
            window.setTimeout(pollOnce, 1500);
            return;
          }
          this.ratingPrecalcPollIds.delete(logicId);
          if (status.status === 'done') {
            this.combatRatingReloadToken.set(
              logicId,
              (this.combatRatingReloadToken.get(logicId) ?? 0) + 1
            );
            this.loadSignalsForLogic(logicId, true);
          }
        },
        error: () => {
          this.ratingPrecalcPollIds.delete(logicId);
        },
      });
    };
    pollOnce();
  }

  isSaving(row: LogicRow): boolean {
    return this.savingIds.has(row.id);
  }

  isFormulaSaving(signalId: number): boolean {
    return this.savingFormulaIds.has(signalId);
  }

  accountTypeLabel(type: string): string {
    return type === 'fake' ? 'фейковый' : 'реальный';
  }

  private loadIndicatorsCatalog(): void {
    this.refs.getIndicators(false).subscribe({
      next: (rows) => {
        this.indicatorsCatalog = rows.filter((r) => r.is_active);
        this.indicatorsLoaded = true;
      },
      error: () => {
        this.indicatorsLoaded = true;
      },
    });
  }

  private loadStopsForLogic(logicId: number, force = false): void {
    if (!force && this.stopsLoading.has(logicId)) return;
    // Уже есть кэш — не мигать «загрузка…» / пустой таблицей; фоновый refresh.
    const hasCache = this.logicStops.has(logicId);
    if (!force && hasCache) {
      this.logicsService.getLogicStops(logicId).subscribe({
        next: (rows) => this.logicStops.set(logicId, rows),
        error: () => undefined,
      });
      return;
    }
    this.stopsLoading.add(logicId);
    this.logicsService.getLogicStops(logicId).subscribe({
      next: (rows) => {
        this.logicStops.set(logicId, rows);
        this.stopsLoading.delete(logicId);
      },
      error: () => {
        this.stopsLoading.delete(logicId);
      },
    });
  }

  private loadSignalsForLogic(logicId: number, force = false): void {
    if (!force && this.signalsLoading.has(logicId)) return;
    const hasCache = this.logicSignals.has(logicId);
    const applyRows = (rows: LogicIndicatorSignalRow[]) => {
      this.logicSignals.set(logicId, rows);
      for (const r of rows) {
        if (!this.isFormulaDraftDirty(r.id, r.formula)) {
          this.formulaDrafts.set(r.id, r.formula);
        }
      }
      this.rebuildSignalIndicatorIds(logicId);
    };
    // Кэш есть — не показывать «загрузка…» при повторном открытии блока.
    if (!force && hasCache) {
      this.logicsService.getLogicIndicatorSignals(logicId).subscribe({
        next: applyRows,
        error: () => undefined,
      });
      return;
    }
    this.signalsLoading.add(logicId);
    this.logicsService.getLogicIndicatorSignals(logicId).subscribe({
      next: (rows) => {
        applyRows(rows);
        this.signalsLoading.delete(logicId);
      },
      error: () => {
        this.signalsLoading.delete(logicId);
      },
    });
  }

  /** Денежный фонд — первая бумага в Позиции/Тестирование → «Бумаги». */
  cashFundPinnedPaper(row: LogicRow): {
    security_id: number;
    security_name: string;
    security_prefix: string | null;
    pnl: number;
    commission: number;
    trade_count: number;
    open_qty: number;
    last_price: number | null;
    position_value: number;
  } | null {
    const code = String(row.cash_fund_code ?? '')
      .trim()
      .toUpperCase();
    if (!code || !['TMON', 'LQDT', 'SBMM'].includes(code)) {
      return null;
    }
    if (!this.logicSecurities.has(row.id) && !this.securitiesLoading.has(row.id)) {
      this.loadSecuritiesForLogic(row.id);
    }
    const sec = this.securitiesFor(row.id).find(
      (s) =>
        String(s.prefix ?? '')
          .trim()
          .toUpperCase() === code && s.is_active !== false
    );
    if (!sec) {
      return null;
    }
    return {
      security_id: Number(sec.security_id),
      security_name: sec.security_name,
      security_prefix: sec.prefix,
      pnl: 0,
      commission: 0,
      trade_count: 0,
      open_qty: 0,
      last_price: null,
      position_value: 0,
    };
  }

  private loadSecuritiesForLogic(logicId: number, force = false): void {
    if (!force && this.securitiesLoading.has(logicId)) return;
    this.securitiesLoading.add(logicId);
    this.logicsService.getLogicSecurities(logicId).subscribe({
      next: (rows) => {
        this.logicSecurities.set(logicId, rows);
        this.securitiesLoading.delete(logicId);
      },
      error: () => {
        this.securitiesLoading.delete(logicId);
      },
    });
  }

  startBacktestRun(
    logicId: number,
    period: {
      date_from: string;
      date_to: string;
      slippage_pct?: number;
      opt_grid?: {
        config?: unknown;
        arms?: { lane: string; values: Record<string, number> }[];
      } | null;
    }
  ): void {
    // Тест: тот же глобальный токен, что у seed-логик — без повторного HTTP-verify на каждую копию.
    this.settings.getTbankTokenConfigured().subscribe({
      next: (status) => {
        if (!status.has_token) {
          this.pendingBacktest = { logicId, period };
          this.tbankTokenDialogContext = 'logic';
          this.tbankTokenDialogReason = 'missing';
          this.tbankTokenDialogOpen = true;
          return;
        }
        this.doStartBacktestRun(logicId, period);
      },
      error: () => this.doStartBacktestRun(logicId, period),
    });
  }

  private doStartBacktestRun(
    logicId: number,
    period: {
      date_from: string;
      date_to: string;
      slippage_pct?: number;
      opt_grid?: {
        config?: unknown;
        arms?: { lane: string; values: Record<string, number> }[];
      } | null;
    }
  ): void {
    this.logicsService
      .startBacktest({
        logic_id: logicId,
        date_from: period.date_from,
        date_to: period.date_to,
        slippage_pct: period.slippage_pct ?? 0,
        opt_grid: period.opt_grid ?? null,
      })
      .subscribe({
        next: () => {
          // Drop stale mid-run equity / panel so chart cannot show a previous run
          // (or truncated closes) while FinRes already tracks the new run_id.
          this.testEquityByLogic.delete(logicId);
          this.logicTradesTest.delete(logicId);
          this.testTradesViewByLogic.delete(logicId);
          this.testEquityInFlight.delete(logicId);
          this.testEquityStartedAt.delete(logicId);
          // Единственный владелец status-poll — BacktestUiStateService.watch().
          this.backtestUi.watch(logicId);
          this.expandedTestTradesBlocks.add(logicId);
          this.loadSignalsForLogic(logicId);
          this.refreshOptGridAvailability(logicId);
        },
        error: (err) => alert(err?.error?.error || 'Не удалось запустить тест'),
      });
  }

  cancelBacktestRun(logicId: number): void {
    const run = this.backtestRuns.get(logicId);
    if (!run?.id) return;
    this.backtestRuns.set(logicId, {
      ...run,
      phase_message: 'Остановка…',
      phase_detail: run.phase_detail || 'Запрос на остановку принят',
    });
    this.logicsService.cancelBacktest(run.id).subscribe({
      next: () => this.backtestUi.watch(logicId),
      error: (err) => alert(err?.error?.error || 'Не удалось остановить тест'),
    });
  }

  private loadTradesForLogic(logicId: number, silent = false): void {
    if (!silent && this.tradesLoading.has(logicId)) return;
    if (this.liveTradesInFlight.has(logicId)) return;
    if (!silent) {
      this.tradesLoading.add(logicId);
    }
    this.liveTradesInFlight.add(logicId);
    this.logicsService.getLogicTrades(logicId, 200, false).pipe(takeUntil(this.destroy$)).subscribe({
      next: (rows) => {
        this.liveTradesInFlight.delete(logicId);
        const prev = this.logicTrades.get(Number(logicId));
        if (!prev || !this.sameTradeListFingerprint(prev, rows)) {
          this.logicTrades.set(Number(logicId), rows);
          this.cdr.markForCheck();
        }
        this.tradesLoading.delete(logicId);
      },
      error: () => {
        this.liveTradesInFlight.delete(logicId);
        this.tradesLoading.delete(logicId);
      },
    });
    this.loadRejectedTradesForLogic(logicId);
    this.loadRejectAlertForLogic(logicId);
  }

  private loadRejectedTradesForLogic(logicId: number): void {
    const id = Number(logicId);
    this.logicsService
      .getLogicTradesRejected(id, 200, false)
      .pipe(
        takeUntil(this.destroy$),
        catchError(() => of([] as LogicTradeRow[]))
      )
      .subscribe((rows) => {
        const prev = this.logicRejectedTrades.get(id);
        if (prev && this.sameRejectedListFingerprint(prev, rows)) return;
        this.logicRejectedTrades.set(id, rows);
        this.cdr.markForCheck();
      });
  }

  private sameRejectedListFingerprint(a: LogicTradeRow[], b: LogicTradeRow[]): boolean {
    if (a === b) return true;
    if (a.length !== b.length) return false;
    if (a.length === 0) return true;
    const lastA = a[a.length - 1];
    const lastB = b[b.length - 1];
    return (
      a[0].id === b[0].id &&
      lastA.id === lastB.id &&
      String(a[0].note ?? '') === String(b[0].note ?? '') &&
      String(lastA.note ?? '') === String(lastB.note ?? '')
    );
  }

  private loadRejectAlertForLogic(logicId: number): void {
    const id = Number(logicId);
    this.logicsService
      .getLogicTradesRejectAlert(id, false)
      .pipe(
        takeUntil(this.destroy$),
        catchError(() => of(null))
      )
      .subscribe((alert) => {
        if (!alert?.warn) {
          if (this.logicRejectAlerts.has(id)) {
            this.logicRejectAlerts.delete(id);
            this.cdr.markForCheck();
          }
          return;
        }
        const next = {
          warn: true,
          rejected_count: Number(alert.rejected_count) || 0,
          message: alert.message ?? null,
        };
        const prev = this.logicRejectAlerts.get(id);
        if (
          prev &&
          prev.rejected_count === next.rejected_count &&
          prev.message === next.message
        ) {
          return;
        }
        this.logicRejectAlerts.set(id, next);
        this.cdr.markForCheck();
      });
  }

  private loadTestTradesForLogic(logicId: number, _silent = false): void {
    if (this.testTradesInFlight.has(logicId)) return;
    this.testTradesInFlight.add(logicId);
    // Полный последний прогон: иначе LIMIT 5000 даёт другой финрез, чем колонка «Тест» (pnl-summary).
    const runId = this.backtestRuns.get(Number(logicId))?.id ?? null;
    this.logicsService
      .getLogicTrades(logicId, 50000, true, runId)
      .pipe(
        timeout(90_000),
        takeUntil(this.destroy$),
        finalize(() => this.testTradesInFlight.delete(logicId))
      )
      .subscribe({
        next: (rows) => {
          const prev = this.logicTradesTest.get(Number(logicId));
          if (prev && this.sameTradeListFingerprint(prev, rows)) {
            this.rebuildTestTradesView(logicId);
            return;
          }
          this.logicTradesTest.set(Number(logicId), rows);
          this.rebuildTestTradesView(logicId);
          this.cdr.markForCheck();
        },
        error: () => {
          /* timeout / network — inFlight cleared in finalize; next poll retries */
        },
      });
  }

  private refreshAllTradesSummaries(): void {
    this.pollTick++;
    // Тяжёлые списки — реже; status теста не дублируем (BacktestUiStateService).
    const heavyTick = this.pollTick % 3 === 0;

    for (const row of this.logics) {
      const id = row.id;
      const liveOpen = this.expandedTradesBlocks.has(id);
      const testOpen = this.expandedTestTradesBlocks.has(id);
      const testing = this.isBacktestRunning(id);

      if (liveOpen || (this.expandedLogics.has(id) && heavyTick)) {
        this.loadTradesForLogic(id, true);
      }
      // Mid-run: equity-curve + test-panel (opens + recent champion closes).
      // Full 50k dump only after finish (OPT paper would freeze the tab).
      if (testOpen) {
        this.loadTestEquityForLogic(id);
        // Mid-run: refresh panel every poll (not only heavyTick) so a timed-out
        // request can retry soon; full dump still only after finish.
        if (testing) {
          this.loadTestTradesPanelForLogic(id);
        }
      } else if (!testing) {
        this.testEquityByLogic.delete(id);
      }
      if (!testing && (testOpen || (this.expandedLogics.has(id) && heavyTick))) {
        this.loadTestTradesForLogic(id, true);
      }
    }
  }

  /** Lightweight champion opens + recent closes while backtest is running. */
  private loadTestTradesPanelForLogic(logicId: number): void {
    const id = Number(logicId);
    if (!Number.isFinite(id) || id <= 0) return;
    if (this.testTradesInFlight.has(id)) return;
    if (typeof document !== 'undefined' && document.hidden) return;
    this.testTradesInFlight.add(id);
    const runId = this.backtestRuns.get(id)?.id ?? null;
    this.logicsService
      .getLogicTradesTestPanel(id, runId, 2500)
      .pipe(
        // Prefer fail-fast retry over long hang: empty panel while FinRes moves.
        timeout(20_000),
        takeUntil(this.destroy$),
        finalize(() => this.testTradesInFlight.delete(id))
      )
      .subscribe({
        next: (resp) => {
          const rows = resp.rows ?? [];
          const prev = this.logicTradesTest.get(id);
          if (prev && this.sameTradeListFingerprint(prev, rows)) {
            this.rebuildTestTradesView(id);
            return;
          }
          this.logicTradesTest.set(id, rows);
          this.rebuildTestTradesView(id);
          this.cdr.markForCheck();
        },
        error: () => {
          /* timeout / network — finalize clears inFlight; next poll retries */
        },
      });
  }

  private loadTestEquityForLogic(logicId: number): void {
    const id = Number(logicId);
    if (!Number.isFinite(id) || id <= 0) return;
    if (typeof document !== 'undefined' && document.hidden) return;
    const now = Date.now();
    if (this.testEquityInFlight.has(id)) {
      const started = this.testEquityStartedAt.get(id) ?? 0;
      // Stuck request (timeout pipe / tab freeze) — allow a fresh poll.
      if (now - started < 35_000) return;
      this.testEquityInFlight.delete(id);
    }
    const runId = this.backtestRuns.get(id)?.id ?? null;
    this.testEquityInFlight.add(id);
    this.testEquityStartedAt.set(id, now);
    this.logicsService
      .getLogicTradesEquityCurve(id, true, runId)
      .pipe(
        timeout(25_000),
        takeUntil(this.destroy$),
        finalize(() => {
          this.testEquityInFlight.delete(id);
          this.testEquityStartedAt.delete(id);
        })
      )
      .subscribe({
        next: (resp) => {
          const currentRun = this.backtestRuns.get(id)?.id ?? null;
          if (runId != null && currentRun != null && runId !== currentRun) {
            return; // response from previous run
          }
          this.testEquityByLogic.set(id, {
            total: resp.total ?? [],
            long: resp.long ?? [],
            short: resp.short ?? [],
            run_id: currentRun ?? runId,
            financial_result: Number(resp.financial_result) || 0,
          });
          this.cdr.markForCheck();
        },
        error: () => {
          /* timeout / network — finalize clears inFlight */
        },
      });
  }

  testEquityTotal(logicId: number): Array<{ dt: string; value: number }> | null {
    return this.testEquityByLogic.get(Number(logicId))?.total ?? null;
  }

  testEquityLong(logicId: number): Array<{ dt: string; value: number }> | null {
    return this.testEquityByLogic.get(Number(logicId))?.long ?? null;
  }

  testEquityShort(logicId: number): Array<{ dt: string; value: number }> | null {
    return this.testEquityByLogic.get(Number(logicId))?.short ?? null;
  }

  private refreshPnlSummaries(): void {
    // Test PnL column: реже во время активных прогонов (колонка не критична mid-run).
    if (this.backtestPollIds.size === 0 || this.pollTick % 3 === 0) {
      this.refreshTestPnlSummary();
    }
    this.refreshCombatPnlSummary();
  }

  private refreshProcesses(): void {
    this.logicsService.getProcesses().pipe(takeUntil(this.destroy$)).subscribe({
      next: (resp) => {
        this.processRows = resp.rows ?? [];
        this.processError = null;
        // Processes strip also lists active backtests — keep yellow/watch in sync.
        for (const p of this.processRows) {
          if (p.type === 'backtest' && p.logic_id != null) {
            const id = Number(p.logic_id);
            if (Number.isFinite(id) && id > 0 && !this.backtestUi.isRunning(id)) {
              this.backtestUi.watch(id);
            }
          }
        }
      },
      error: (err) => {
        this.processRows = [];
        this.processError = err?.error?.error ?? err?.message ?? 'Не удалось загрузить процессы';
      },
    });
  }

  private refreshTestPnlSummary(): void {
    if (this.testPnlInFlight) return;
    if (typeof document !== 'undefined' && document.hidden) return;
    this.testPnlInFlight = true;
    this.logicsService.getLogicTradesPnlSummary(true).pipe(takeUntil(this.destroy$)).subscribe({
      next: (resp) => {
        this.testPnlInFlight = false;
        this.testPnlByLogic.clear();
        for (const r of resp.rows ?? []) {
          const logicId = Number(r.logic_id);
          if (!Number.isFinite(logicId) || logicId <= 0) continue;
          const pnl = Number(r.financial_result);
          this.testPnlByLogic.set(logicId, {
            financial_result: Number.isFinite(pnl) ? pnl : 0,
            commission: Number(r.commission) || 0,
            trade_count: Number(r.trade_count) || 0,
            date_from: r.date_from ?? null,
            date_to: r.date_to ?? null,
          });
          // If equity curve lags FinRes (common with two concurrent tests), force refresh.
          const eq = this.testEquityByLogic.get(logicId);
          const eqLast =
            eq?.total?.length ? eq.total[eq.total.length - 1]?.value : null;
          const fr = Number.isFinite(pnl) ? pnl : 0;
          if (
            this.expandedTestTradesBlocks.has(logicId) &&
            (eqLast == null || Math.abs(Number(eqLast) - fr) > 1) &&
            !this.testEquityInFlight.has(logicId)
          ) {
            this.loadTestEquityForLogic(logicId);
          }
        }
        this.cdr.markForCheck();
      },
      error: () => {
        this.testPnlInFlight = false;
        // Старый API без /pnl-summary — только если нет нового endpoint
        this.refreshTestPnlFromBacktestRuns();
      },
    });
  }

  private refreshCombatPnlSummary(): void {
    if (this.combatPnlInFlight) return;
    if (typeof document !== 'undefined' && document.hidden) return;
    this.combatPnlInFlight = true;
    this.logicsService.getLogicTradesPnlSummary(false).pipe(takeUntil(this.destroy$)).subscribe({
      next: (resp) => {
        this.combatPnlInFlight = false;
        const next = new Map<
          number,
          { financial_result: number; commission: number; trade_count: number }
        >();
        for (const r of resp.rows ?? []) {
          const logicId = Number(r.logic_id);
          if (!Number.isFinite(logicId) || logicId <= 0) continue;
          const pnl = Number(r.financial_result);
          next.set(logicId, {
            financial_result: Number.isFinite(pnl) ? pnl : 0,
            commission: Number(r.commission) || 0,
            trade_count: Number(r.trade_count) || 0,
          });
        }
        this.combatPnlByLogic = next;
      },
      error: () => {
        this.combatPnlInFlight = false;
      },
    });
  }

  /** Fallback без /pnl-summary: сумма уже загруженных test-сделок (не runs.financial_result). */
  private refreshTestPnlFromBacktestRuns(): void {
    this.testPnlByLogic.clear();
    for (const row of this.logics) {
      const trades = this.logicTradesTest.get(Number(row.id)) ?? [];
      const live = trades.filter((t) => !t.is_shadow);
      if (live.length === 0) continue;
      const financial_result = live.reduce(
        (sum, t) =>
          t.financial_result != null && Number.isFinite(Number(t.financial_result))
            ? sum + Number(t.financial_result)
            : sum,
        0
      );
      const commission = live.reduce(
        (sum, t) => sum + (Number(t.commission) || 0),
        0
      );
      const run = this.backtestRuns.get(Number(row.id));
      this.testPnlByLogic.set(Number(row.id), {
        financial_result,
        commission,
        trade_count: live.length,
        date_from: run?.date_from ?? null,
        date_to: run?.date_to ?? null,
      });
    }
  }

  private loadMoexExchangeId(): void {
    this.refs.getExchanges().subscribe({
      next: (rows) => {
        const moex =
          rows.find((e) => e.name === 'MOEX') ?? rows[0];
        this.moexExchangeId = moex?.id ?? null;
      },
    });
  }

  private ensureSecuritiesCatalogLoaded(): void {
    if (this.securitiesCatalogLoaded || this.securitiesCatalogLoading) {
      return;
    }
    if (!this.moexExchangeId) {
      this.refs.getExchanges().subscribe({
        next: (rows) => {
          const moex =
            rows.find((e) => e.name === 'MOEX') ?? rows[0];
          this.moexExchangeId = moex?.id ?? null;
          if (this.moexExchangeId) {
            this.fetchSecuritiesCatalog(this.moexExchangeId);
          } else {
            this.securitiesCatalogLoaded = true;
          }
        },
        error: () => {
          this.securitiesCatalogLoaded = true;
        },
      });
      return;
    }
    this.fetchSecuritiesCatalog(this.moexExchangeId);
  }

  private fetchSecuritiesCatalog(exchangeId: number): void {
    this.securitiesCatalogLoading = true;
    forkJoin({
      stocks: this.securitiesService.getSecurities(exchangeId, 'stock'),
      futures: this.securitiesService.getSecurities(exchangeId, 'futures'),
      funds: this.securitiesService.getSecurities(exchangeId, 'other'),
    }).subscribe({
      next: ({ stocks, futures, funds }) => {
        this.stocksCatalog = stocks;
        this.futuresCatalog = futures;
        this.fundsCatalog = funds;
        this.securitiesCatalogLoaded = true;
        this.securitiesCatalogLoading = false;
      },
      error: () => {
        this.securitiesCatalogLoaded = true;
        this.securitiesCatalogLoading = false;
      },
    });
  }

  private isFormulaDraftDirty(signalId: number, savedFormula: string): boolean {
    const draft = this.formulaDrafts.get(signalId);
    return draft !== undefined && draft !== savedFormula;
  }

  private loadLogicsOnce(): void {
    this.logicsService.getLogics().subscribe({
      next: (rows) => {
        this.logics = rows;
        this.error = null;
        const alive = new Set(rows.map((r) => r.id));
        for (const id of [...this.selectedExportIds]) {
          if (!alive.has(id)) this.selectedExportIds.delete(id);
        }
      },
    });
  }

  /**
   * Строки таблицы списка логик в порядке отображения:
   * 1) реальные счета; 2) включённые логики (независимо от счёта);
   * 3) тестовые (fake) — по дате последнего теста (свежие выше);
   * 4) тестовые, у которых теста никогда не было — в самом низу.
   * Если `showAllLogics` выключен — оставляем все реальные + все включённые + N последних протестированных.
   */
  displayedLogics(): LogicRow[] {
    // Если пользователь отсортировал по колонке — раскрываем весь список и сортируем по ней.
    if (this.sortColumn) {
      const all = [...this.logics];
      const dir = this.sortDir === 'asc' ? 1 : -1;
      const val = (r: LogicRow): number | string | null => {
        switch (this.sortColumn) {
          case 'id': return r.id;
          case 'name': return r.name;
          case 'enabled': return r.is_enabled ? 1 : 0;
          case 'signal': return r.use_as_terminal_signal ? 1 : 0;
          case 'combat_pnl': return this.combatFinancialResult(r.id);
          case 'test_pnl': return this.testFinancialResult(r.id);
          default: return 0;
        }
      };
      const isEmpty = (v: number | string | null): boolean =>
        v == null || v === '' || (typeof v === 'number' && !Number.isFinite(v));
      all.sort((a, b) => {
        const av = val(a);
        const bv = val(b);
        const aNull = isEmpty(av);
        const bNull = isEmpty(bv);
        if (aNull && bNull) return 0;
        if (aNull) return 1;
        if (bNull) return -1;
        if (typeof av === 'string' && typeof bv === 'string') {
          return av.localeCompare(bv, 'ru') * dir;
        }
        return ((av as number) - (bv as number)) * dir;
      });
      return all;
    }

    const parsed = new Map<number, number>();
    const lastTestMs = (r: LogicRow): number => {
      if (parsed.has(r.id)) return parsed.get(r.id)!;
      let ms = -1;
      if (r.last_test_at) {
        const t = Date.parse(`${r.last_test_at}`.replace(' ', 'T'));
        if (Number.isFinite(t)) ms = t;
      }
      parsed.set(r.id, ms);
      return ms;
    };

    const real: LogicRow[] = [];
    const enabled: LogicRow[] = [];
    const tested: LogicRow[] = [];
    const untested: LogicRow[] = [];
    for (const r of this.logics) {
      if (r.account_type === 'real') {
        real.push(r);
      } else if (r.is_enabled) {
        enabled.push(r);
      } else if (lastTestMs(r) >= 0) {
        tested.push(r);
      } else {
        untested.push(r);
      }
    }
    tested.sort((a, b) => lastTestMs(b) - lastTestMs(a));
    untested.sort((a, b) => a.id - b.id);

    if (this.showAllLogics) {
      return [...real, ...enabled, ...tested, ...untested];
    }
    return [
      ...real,
      ...enabled,
      ...tested.slice(0, Math.max(0, this.defaultTestLogicsVisible)),
    ];
  }

  /** Сколько логик скрыто в свёрнутом виде (нужно для подписи кнопки). */
  hiddenLogicsCount(): number {
    if (this.showAllLogics) return 0;
    return this.logics.length - this.displayedLogics().length;
  }

  toggleShowAllLogics(): void {
    this.showAllLogics = !this.showAllLogics;
    // При сворачивании возвращаем порядок по умолчанию: реальные + включённые + последние тестовые.
    if (!this.showAllLogics) {
      this.sortColumn = null;
      this.sortDir = 'asc';
    }
  }

  /** Сортировка по колонке (повторный клик — переключение направления). Раскрывает весь список. */
  toggleSort(col: 'id' | 'name' | 'enabled' | 'signal' | 'combat_pnl' | 'test_pnl'): void {
    if (this.sortColumn === col) {
      this.sortDir = this.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = col;
      this.sortDir = 'asc';
    }
    this.showAllLogics = true;
  }

  isColumnSorted(col: 'id' | 'name' | 'enabled' | 'signal' | 'combat_pnl' | 'test_pnl'): boolean {
    return this.sortColumn === col;
  }

  /** Значок направления сортировки (▲/▼) для активной колонки. */
  sortIndicator(col: 'id' | 'name' | 'enabled' | 'signal' | 'combat_pnl' | 'test_pnl'): string {
    if (this.sortColumn !== col) return '';
    return this.sortDir === 'asc' ? '▲' : '▼';
  }
}
