/**
 * #1030: ползунок «строже / мягче» в списке сигналов логики.
 * Положение 0..100 — АБСОЛЮТНОЕ: 0 = строгая граница параметра, 100 = мягкая,
 * 50 = середина диапазона. Значение параметра в формуле однозначно задаёт
 * положение ползунка, поэтому после сохранения он остаётся там, где его оставили.
 */
export interface IndicatorParamBound {
  indicator_code: string;
  param_key: string;
  /** Значение на «строгом» конце ползунка. */
  strict_value: number;
  /** Значение на «мягком» конце. */
  loose_value: number;
  /** Значение в середине (дефолт индикатора); пусто — середина диапазона. */
  default_value?: number | null;
  /** Округление до целого (period и т.п.). */
  is_integer: boolean;
}

/** Числовые параметры key=value, встречающиеся в формуле сигнала. */
export function formulaParamValues(formula: string): Record<string, number> {
  const out: Record<string, number> = {};
  const re = /([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(-?\d+(?:[.,]\d+)?)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(String(formula || ''))) != null) {
    const v = Number(m[2].replace(',', '.'));
    if (Number.isFinite(v)) out[m[1]] = v;
  }
  return out;
}

/** Только параметры внутри вызовов @indicatorCode(...) (с учётом вложенных скобок). */
export function indicatorCallParams(
  formula: string,
  indicatorCode?: string
): Record<string, number> {
  const src = String(formula || '');
  const code = String(indicatorCode || '').trim().toUpperCase();
  if (!code) return formulaParamValues(src);
  const out: Record<string, number> = {};
  const marker = `@${code}(`;
  let cursor = 0;
  while (cursor < src.length) {
    const idx = src.toUpperCase().indexOf(marker, cursor);
    if (idx < 0) break;
    let depth = 1;
    let i = idx + marker.length;
    while (i < src.length && depth > 0) {
      if (src[i] === '(') depth += 1;
      else if (src[i] === ')') depth -= 1;
      i += 1;
    }
    const inner = src.slice(idx + marker.length, depth === 0 ? i - 1 : i);
    Object.assign(out, formulaParamValues(inner));
    cursor = i;
  }
  return out;
}

/**
 * Пересчитать параметры формулы под абсолютное положение ползунка 0..100.
 * 0 — строгие границы, 100 — мягкие, 50 — середина диапазона.
 * Меняются только параметры из bounds и только внутри вызовов @indicatorCode(...).
 */
export function applyStrictnessToFormula(
  formula: string,
  bounds: IndicatorParamBound[],
  position: number,
  indicatorCode?: string
): string {
  const p = Math.min(100, Math.max(0, Number(position) || 0)) / 100;
  const byKey = new Map(bounds.map((b) => [b.param_key, b]));
  const rewrite = (text: string): string =>
    text.replace(
      /([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(-?\d+(?:[.,]\d+)?)/g,
      (whole, key: string) => {
        const b = byKey.get(key);
        if (!b) return whole;
        const strict = Number(b.strict_value);
        const loose = Number(b.loose_value);
        const mid = Number.isFinite(Number(b.default_value))
          ? Number(b.default_value)
          : (strict + loose) / 2;
        if (!Number.isFinite(strict) || !Number.isFinite(loose)) return whole;
        let v: number;
        if (p <= 0.5) {
          v = strict + (mid - strict) * (p / 0.5);
        } else {
          v = mid + (loose - mid) * ((p - 0.5) / 0.5);
        }
        v = b.is_integer ? Math.round(v) : Math.round(v * 100) / 100;
        return `${key}=${v}`;
      }
    );

  const src = String(formula || '');
  const code = String(indicatorCode || '').trim().toUpperCase();
  if (!code) return rewrite(src);

  const marker = `@${code}(`;
  let out = '';
  let cursor = 0;
  while (cursor < src.length) {
    const idx = src.toUpperCase().indexOf(marker, cursor);
    if (idx < 0) {
      out += src.slice(cursor);
      break;
    }
    out += src.slice(cursor, idx) + src.slice(idx, idx + marker.length);
    let depth = 1;
    let i = idx + marker.length;
    while (i < src.length && depth > 0) {
      if (src[i] === '(') depth += 1;
      else if (src[i] === ')') depth -= 1;
      i += 1;
    }
    const inner = src.slice(idx + marker.length, depth === 0 ? i - 1 : i);
    out += rewrite(inner);
    if (depth === 0) out += ')';
    cursor = i;
  }
  return out;
}

/**
 * Положение ползунка, соответствующее текущим параметрам формулы.
 * Среднее по всем параметрам индикатора (каждый нормируется в 0..100).
 * Нет значений/границ — 50 (середина).
 */
export function strictnessPositionFromFormula(
  formula: string,
  bounds: IndicatorParamBound[],
  indicatorCode?: string
): number {
  if (!bounds.length) return 50;
  const values = indicatorCallParams(formula, indicatorCode);
  const positions: number[] = [];
  for (const b of bounds) {
    const cur = values[b.param_key];
    const strict = Number(b.strict_value);
    const loose = Number(b.loose_value);
    if (!Number.isFinite(cur) || !Number.isFinite(strict) || !Number.isFinite(loose)) continue;
    if (strict === loose) continue;
    const mid = Number.isFinite(Number(b.default_value))
      ? Number(b.default_value)
      : (strict + loose) / 2;
    let p: number;
    if (cur >= mid && mid !== strict) {
      p = 50 * ((cur - strict) / (mid - strict));
    } else if (mid !== loose) {
      p = 50 + 50 * ((cur - mid) / (loose - mid));
    } else {
      p = 50;
    }
    positions.push(Math.min(100, Math.max(0, p)));
  }
  if (!positions.length) return 50;
  const avg = positions.reduce((a, b) => a + b, 0) / positions.length;
  return Math.round(Math.min(100, Math.max(0, avg)));
}

/**
 * #1033/#1035: фон полосы сигнала по положению ползунка.
 * Строго (0) — светло-красный, мягко (100) — светло-голубой,
 * в середине — белый. Цвета непрозрачные, чтобы фон реально было видно.
 */
export function strictnessRowBackground(position: number): string {
  const p = Math.min(100, Math.max(0, Number(position) || 0)) / 100;
  const strict: [number, number, number] = [252, 205, 211]; // светло-красный
  const white: [number, number, number] = [255, 255, 255];
  const loose: [number, number, number] = [205, 227, 255]; // светло-голубой
  const mix = (a: [number, number, number], b: [number, number, number], t: number): string => {
    const r = Math.round(a[0] + (b[0] - a[0]) * t);
    const g = Math.round(a[1] + (b[1] - a[1]) * t);
    const bl = Math.round(a[2] + (b[2] - a[2]) * t);
    return `rgb(${r}, ${g}, ${bl})`;
  };
  return p <= 0.5 ? mix(strict, white, p / 0.5) : mix(white, loose, (p - 0.5) / 0.5);
}
