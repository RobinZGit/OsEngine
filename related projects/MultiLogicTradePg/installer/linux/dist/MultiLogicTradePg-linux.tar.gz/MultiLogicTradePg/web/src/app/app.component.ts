import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { DbSchemaPanelComponent } from './db-schema/db-schema-panel.component';
import { AppHelpPanelComponent } from './app-help/app-help-panel.component';
import { AppSettingsPanelComponent } from './app-settings/app-settings-panel.component';
import { AppAboutPanelComponent } from './app-about/app-about-panel.component';
import { ProjectSchemaPanelComponent } from './project-schema/project-schema-panel.component';
import { TechLogService } from './services/tech-log.service';
import { TradeRunnerSessionService } from './services/trade-runner-session.service';
import { TerminalStateService } from './services/terminal-state.service';
import { assetUrl } from './shared/asset-url';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    DbSchemaPanelComponent,
    AppHelpPanelComponent,
    AppSettingsPanelComponent,
    AppAboutPanelComponent,
    ProjectSchemaPanelComponent,
    FormsModule,
  ],
  template: `
    <header class="app-bar">
      <div class="app-bar-left">
        <strong>MultiLogic Trade</strong>
        <span>PostgreSQL + Angular</span>
      </div>
      <div class="app-bar-right">
        <a
          class="crypt-link"
          [href]="myProjectsUrl"
          target="_blank"
          rel="noopener noreferrer"
          title="My Published Projects — hub of GitHub Pages apps"
        >My Projects</a>
        <a
          class="crypt-link"
          [href]="cryptToolUrl"
          target="_blank"
          rel="noopener noreferrer"
          title="Crypt — parity stego (text/picture)"
        >Crypt</a>
        <label class="tech-log-toggle" title="Журнал app_tech_log: trade runner, сигналы, параметры">
          <input
            type="checkbox"
            [(ngModel)]="techLoggingEnabled"
            (ngModelChange)="onTechLoggingChange($event)"
          />
          <span>Логирование</span>
        </label>
        <button
          type="button"
          class="bar-icon-btn"
          title="Справка"
          aria-label="Справка"
          (click)="openHelp()"
        >
          <!-- Book icon -->
          <svg class="bar-icon" viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
            <path
              fill="#ffffff"
              d="M18 2H8c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 18H8V4h2v8l2.5-1.5L15 12V4h3v16z"
            />
            <path fill="#111827" d="M10 4h5v8l-2.5-1.5L10 12V4z" />
          </svg>
        </button>
        <button
          type="button"
          class="bar-icon-btn"
          title="Структура базы данных"
          aria-label="Структура базы данных"
          (click)="openSchema()"
        >
          <!-- Database / cylinders icon -->
          <svg class="bar-icon" viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
            <ellipse cx="12" cy="5" rx="8" ry="3" fill="#ffffff" />
            <path
              fill="#ffffff"
              d="M4 5v6c0 1.66 3.58 3 8 3s8-1.34 8-3V5c0 1.66-3.58 3-8 3S4 6.66 4 5z"
            />
            <path
              fill="#ffffff"
              d="M4 11v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6c0 1.66-3.58 3-8 3s-8-1.34-8-3z"
            />
          </svg>
        </button>
        <button
          type="button"
          class="bar-icon-btn"
          title="Схема проекта: модули, где работают Node.js / PostgreSQL / Angular"
          aria-label="Схема проекта"
          (click)="openProjectSchema()"
        >
          <!-- Diagram / network icon -->
          <svg class="bar-icon" viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
            <rect x="3" y="3" width="8" height="8" rx="2" fill="#ffffff" />
            <rect x="13" y="3" width="8" height="8" rx="2" fill="#ffffff" />
            <rect x="3" y="13" width="8" height="8" rx="2" fill="#ffffff" />
            <rect x="13" y="13" width="8" height="8" rx="2" fill="#ffffff" />
            <path
              fill="#ffffff"
              d="M11 7h2v2h-2zM11 15h2v2h-2zM7 11h2v2H7zM15 11h2v2h-2z"
            />
            <circle cx="11" cy="12" r="1.4" fill="#111827" />
          </svg>
        </button>
        <button
          type="button"
          class="bar-icon-btn"
          title="Общие настройки"
          aria-label="Общие настройки"
          (click)="openSettings()"
        >
          <!-- Gear icon -->
          <svg class="bar-icon" viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
            <path
              fill="#ffffff"
              d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.488.488 0 0 0-.59-.22l-2.39.96a7.02 7.02 0 0 0-1.63-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54a7.02 7.02 0 0 0-1.63.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.63.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.6-.24 1.13-.56 1.63-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6A3.6 3.6 0 1 1 12 8.4a3.6 3.6 0 0 1 0 7.2z"
            />
            <circle cx="12" cy="12" r="3.6" fill="#111827" />
          </svg>
        </button>
        <button
          type="button"
          class="bar-icon-btn"
          title="О системе: версия, сборка, дата"
          aria-label="О системе"
          (click)="openAbout()"
        >
          <!-- Info icon -->
          <svg class="bar-icon" viewBox="0 0 24 24" width="32" height="32" aria-hidden="true">
            <path
              fill="#ffffff"
              d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16z"
            />
            <path fill="#ffffff" d="M11 10h2v7h-2z" />
            <circle cx="12" cy="7" r="1.3" fill="#ffffff" />
          </svg>
        </button>
      </div>
    </header>
    <nav class="app-tabs">
      <a routerLink="/operations" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: true }">
        Торговые операции
      </a>
      <a routerLink="/indicators" routerLinkActive="active">
        Бумаги и индикаторы
      </a>
      <a routerLink="/references" routerLinkActive="active">
        Справочники
      </a>
      <a routerLink="/terminal" routerLinkActive="active">
        Терминал
      </a>
      <a routerLink="/monitoring" routerLinkActive="active">
        Мониторинг системы
      </a>
    </nav>
    <main>
      <router-outlet />
    </main>
    <app-help-panel [open]="helpOpen" (closed)="helpOpen = false" />
    <app-db-schema-panel [open]="schemaOpen" (closed)="schemaOpen = false" />
    <app-project-schema-panel [open]="projectSchemaOpen" (closed)="projectSchemaOpen = false" />
    <app-settings-panel [open]="settingsOpen" (closed)="settingsOpen = false" />
    <app-about-panel [open]="aboutOpen" (closed)="aboutOpen = false" />
  `,
  styles: [
    `
      .app-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        padding: 0.75rem 1.5rem;
        background: #111827;
        color: #f9fafb;
      }
      .app-bar-left {
        display: flex;
        align-items: center;
        gap: 1rem;
      }
      .app-bar-right {
        display: flex;
        align-items: center;
        gap: 0.35rem;
      }
      .crypt-link {
        display: inline-flex;
        align-items: center;
        margin-right: 0.55rem;
        padding: 0.35rem 0.7rem;
        border-radius: 8px;
        border: 1px solid rgba(255, 255, 255, 0.28);
        color: #f9fafb;
        text-decoration: none;
        font-size: 0.88rem;
        font-weight: 600;
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .crypt-link:hover {
        background: rgba(255, 255, 255, 0.12);
      }
      .tech-log-toggle {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        font-size: 0.88rem;
        color: #e5e7eb;
        cursor: pointer;
        user-select: none;
        white-space: nowrap;
        margin-right: 0.4rem;
      }
      .tech-log-toggle input {
        width: 1rem;
        height: 1rem;
        cursor: pointer;
      }
      .app-bar span {
        color: #9ca3af;
        font-size: 0.9rem;
      }
      .bar-icon-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 2.75rem;
        height: 2.75rem;
        border: none;
        border-radius: 10px;
        background: transparent;
        cursor: pointer;
        padding: 0;
      }
      .bar-icon-btn:hover {
        background: rgba(255, 255, 255, 0.12);
      }
      .bar-icon-btn:hover .bar-icon {
        filter: drop-shadow(0 0 4px rgba(255, 255, 255, 0.45));
      }
      .app-tabs {
        display: flex;
        gap: 0;
        padding: 0 1.5rem;
        background: #fff;
        border-bottom: 1px solid #e5e7eb;
      }
      .app-tabs a {
        padding: 0.65rem 1rem;
        color: #6b7280;
        text-decoration: none;
        font-size: 0.92rem;
        border-bottom: 2px solid transparent;
        margin-bottom: -1px;
      }
      .app-tabs a:hover {
        color: #111827;
      }
      .app-tabs a.active {
        color: #2563eb;
        border-bottom-color: #2563eb;
        font-weight: 600;
      }
      main {
        min-height: calc(100vh - 96px);
        background: #f3f4f6;
      }
    `,
  ],
})
export class AppComponent implements OnInit, OnDestroy {
  schemaOpen = false;
  helpOpen = false;
  settingsOpen = false;
  aboutOpen = false;
  projectSchemaOpen = false;
  techLoggingEnabled = false;
  /** Standalone Crypt tool (GitHub Pages + local assets). */
  readonly cryptToolUrl = assetUrl('assets/tools/parity-stego.html');
  /**
   * Hub of published projects. Prefer the Pages root URL so Angular SPA
   * 404-fallback cannot swallow a missing assets path.
   */
  readonly myProjectsUrl =
    typeof location !== 'undefined' &&
    /localhost|127\.0\.0\.1/.test(location.hostname)
      ? assetUrl('assets/tools/my-projects.html')
      : 'https://robinzgit.github.io/OsEngine/my-projects.html';

  /**
   * #996: сторож сигналов логик — работает независимо от открытой вкладки.
   * Терминал (`TerminalComponent`) монтируется только на своей вкладке, а
   * обработка сигнала (полоса + автоисполнение «Исполнять сделки сразу») живёт
   * внутри него. Пока вкладка закрыта, новый сигнал теряется. Поэтому корневой
   * компонент сам следит за непрочитанными сигналами и при их появлении
   * переводит пользователя на вкладку «Терминал» — тогда полоса рисуется и
   * автоисполнение срабатывает. Неважно, исполнился сигнал сразу или это просто
   * появление бумаги: реакция одна.
   */
  private signalsWatchTimer: ReturnType<typeof setInterval> | null = null;
  private signalsWatchFirst: ReturnType<typeof setTimeout> | null = null;
  private signalsWatchBusy = false;
  /** #998: id последнего сигнала, на который уже поднимали окно (чтобы не всплывать
      повторно на тот же сигнал каждые 15 с). */
  private lastRaisedSignalId = 0;

  constructor(
    private readonly techLog: TechLogService,
    private readonly tradeRunnerSession: TradeRunnerSessionService,
    private readonly terminalState: TerminalStateService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.tradeRunnerSession.start();
    this.techLog.loadEnabled().subscribe({
      next: (r) => {
        this.techLoggingEnabled = r.enabled;
      },
    });
    this.startSignalsWatch();
  }

  onTechLoggingChange(enabled: boolean): void {
    this.techLog.setEnabled(enabled);
  }

  ngOnDestroy(): void {
    this.tradeRunnerSession.stop();
    if (this.signalsWatchTimer) clearInterval(this.signalsWatchTimer);
    if (this.signalsWatchFirst) clearTimeout(this.signalsWatchFirst);
  }

  /** #996: опрос непрочитанных сигналов раз в 15 с (как и в терминале). */
  private startSignalsWatch(): void {
    if (this.signalsWatchTimer) return;
    this.signalsWatchTimer = setInterval(() => this.watchLogicSignals(), 15_000);
    // Первый опрос — после того, как устоится стартовая маршрутизация ('' → 'operations').
    this.signalsWatchFirst = setTimeout(() => this.watchLogicSignals(), 2000);
  }

  /** #996/#998: есть непрочитанный сигнал — поднимаем окно браузера и, если открыта
      не вкладка терминала, открываем её. Сигналы отмечает прочитанными сам терминал,
      когда смонтируется (иначе был бы бесконечный переход).
      #998: подъём окна НЕ пропускается, когда мы уже на терминале (раньше ранний
      `return` глушил его — окно не всплывало); плюс дедуп по id, чтобы не всплывать
      повторно на тот же сигнал. */
  private watchLogicSignals(): void {
    if (this.signalsWatchBusy) return;
    this.signalsWatchBusy = true;
    this.terminalState.getLogicSignals(1).subscribe({
      next: (r) => {
        this.signalsWatchBusy = false;
        const signals = r?.signals ?? [];
        if (signals.length === 0) return;
        const newestId = signals.reduce((m, s) => Math.max(m, Number(s.id) || 0), 0);
        if (newestId > this.lastRaisedSignalId) {
          this.lastRaisedSignalId = newestId;
          this.focusBrowser();
        }
        if (this.activeTab() !== 'terminal') {
          void this.router.navigateByUrl('/terminal');
        }
      },
      error: () => {
        this.signalsWatchBusy = false;
      },
    });
  }

  /** Первый сегмент текущего маршрута ('' — корень/редирект). */
  private activeTab(): string {
    const path = this.router.url.split('?')[0].split('#')[0];
    return path.split('/').filter((s) => s.length > 0)[0] ?? '';
  }

  /** #997: вместе с автопереходом поднимаем окно браузера поверх остальных
      окон. window.focus() сам по себе только мигает на панели задач, поэтому
      локальный API запускает Windows-хелпер (см. scripts/show-browser.ps1).
      Если API недоступен (не-Windows, удалённый сервер) — просто игнорируем. */
  private focusBrowser(): void {
    try {
      window.focus();
    } catch {
      /* noop */
    }
    this.terminalState.showBrowser().subscribe({ error: () => undefined });
  }

  openHelp(): void {
    this.helpOpen = true;
  }

  openSchema(): void {
    this.schemaOpen = true;
  }

  openSettings(): void {
    this.settingsOpen = true;
  }

  openAbout(): void {
    this.aboutOpen = true;
  }

  openProjectSchema(): void {
    this.projectSchemaOpen = true;
  }
}
