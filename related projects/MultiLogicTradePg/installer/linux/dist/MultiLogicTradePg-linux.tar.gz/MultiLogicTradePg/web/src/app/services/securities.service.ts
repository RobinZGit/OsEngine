/**
 * Бумаги, цены и серии индикаторов (вкладка «Бумаги и индикаторы»).
 * HTTP → `/api/securities`, `/api/prices`, `/api/security-indicator-series`, `/api/indicator-values`.
 */
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of, timeout } from 'rxjs';
import { AppConfigService } from './app-config.service';
import {
  ChartIndicatorSeries,
  IndicatorSeriesParamPatch,
  IndicatorValueRow,
  LastPricesResult,
  PriceCandle,
  PriceLoadRequest,
  PriceLoadResult,
  PriceRefreshResult,
  SecurityIndicatorSeriesRow,
  SecurityPayload,
  SecurityRow,
  TimeframeRow,
} from '../models/market.model';

@Injectable({ providedIn: 'root' })
export class SecuritiesService {
  constructor(
    private readonly http: HttpClient,
    private readonly appConfig: AppConfigService
  ) {}

  getTimeframes(): Observable<TimeframeRow[]> {
    return this.http.get<TimeframeRow[]>(`${this.appConfig.apiUrl}/timeframes`);
  }

  getSecurities(
    exchangeId: number,
    kind: 'stock' | 'futures' | 'other' | 'bond'
  ): Observable<SecurityRow[]> {
    const params = new HttpParams()
      .set('exchange_id', String(exchangeId))
      .set('kind', kind);
    return this.http.get<SecurityRow[]>(`${this.appConfig.apiUrl}/securities`, {
      params,
    });
  }

  createSecurity(payload: SecurityPayload): Observable<SecurityRow> {
    return this.http.post<SecurityRow>(
      `${this.appConfig.apiUrl}/securities`,
      payload
    );
  }

  getPrices(
    securityId: number,
    timeframeId: number,
    limit = 120,
    before?: string
  ): Observable<PriceCandle[]> {
    let params = new HttpParams()
      .set('security_id', String(securityId))
      .set('timeframe_id', String(timeframeId))
      .set('limit', String(limit));
    if (before) {
      params = params.set('before', before);
    }
    return this.http
      .get<PriceCandle[]>(`${this.appConfig.apiUrl}/prices`, { params })
      .pipe(timeout(15_000));
  }

  loadPrices(body: PriceLoadRequest): Observable<PriceLoadResult> {
    return this.http
      .post<PriceLoadResult>(`${this.appConfig.apiUrl}/prices/load`, body)
      .pipe(timeout(190_000));
  }

  /** Живое обновление: догрузка последней закрытой свечи TF (окно подбирает API). */
  refreshPrices(
    securityId: number,
    timeframeId: number
  ): Observable<PriceRefreshResult> {
    return this.http
      .post<PriceRefreshResult>(`${this.appConfig.apiUrl}/prices/refresh`, {
        security_id: securityId,
        timeframe_id: timeframeId,
      })
      .pipe(timeout(120_000));
  }

  /** #922: живые цены (последняя сделка) пачкой по бумагам с открытыми
      позициями — терминал зовёт раз в 30 с, чтобы разница по позиции была
      оперативной (график живёт на закрытых барах). */
  getLastPrices(securityIds: number[], force = false): Observable<LastPricesResult> {
    const ids = [...new Set(securityIds.filter((id) => Number.isInteger(id) && id > 0))];
    if (ids.length === 0) {
      return of({ ok: true, source: null, prices: [] });
    }
    let params = new HttpParams().set('security_ids', ids.join(','));
    if (force) params = params.set('force', '1');
    return this.http
      .get<LastPricesResult>(`${this.appConfig.apiUrl}/prices/last`, { params })
      .pipe(timeout(20_000));
  }

  getSecurityIndicatorSeries(
    securityId: number
  ): Observable<SecurityIndicatorSeriesRow[]> {
    const params = new HttpParams().set('security_id', String(securityId));
    return this.http
      .get<SecurityIndicatorSeriesRow[]>(
        `${this.appConfig.apiUrl}/security-indicator-series`,
        { params }
      )
      .pipe(timeout(15_000));
  }

  assignIndicatorSeries(
    securityId: number,
    indicatorId: number,
    timeframeId?: number
  ): Observable<SecurityIndicatorSeriesRow[]> {
    const body: Record<string, number> = {
      security_id: securityId,
      indicator_id: indicatorId,
    };
    if (timeframeId) {
      body['timeframe_id'] = timeframeId;
    }
    return this.http
      .post<SecurityIndicatorSeriesRow[]>(
        `${this.appConfig.apiUrl}/security-indicator-series`,
        body
      )
      .pipe(timeout(15_000));
  }

  removeIndicatorSeries(id: number): Observable<{ ok: boolean }> {
    return this.http.delete<{ ok: boolean }>(
      `${this.appConfig.apiUrl}/security-indicator-series/${id}`
    );
  }

  /** Правка параметров серий индикатора: обновляет все активные серии
      индикатора на бумаге и возвращает обновлённые строки. */
  updateIndicatorSeriesParams(
    id: number,
    params: IndicatorSeriesParamPatch
  ): Observable<SecurityIndicatorSeriesRow[]> {
    return this.http
      .put<SecurityIndicatorSeriesRow[]>(
        `${this.appConfig.apiUrl}/security-indicator-series/${id}`,
        params
      )
      .pipe(timeout(15_000));
  }

  syncIndicatorSeries(body: {
    security_id: number;
    timeframe_id: number;
    indicator_id?: number;
    end_dt?: string;
    point_count?: number;
    incremental?: boolean;
    /** Всегда true в UI — расчёт только в фоне на сервере. */
    async?: boolean;
  }): Observable<{ ok: boolean; status?: string }> {
    const payload = { ...body, async: true };
    return this.http
      .post<{ ok: boolean; status?: string }>(
        `${this.appConfig.apiUrl}/security-indicator-series/sync`,
        payload
      )
      .pipe(timeout(10_000));
  }

  getIndicatorValues(
    securityId: number,
    timeframeId: number,
    indicatorIds: number[],
    after?: string,
    before?: string,
    limit = 1500
  ): Observable<IndicatorValueRow[]> {
    let params = new HttpParams()
      .set('security_id', String(securityId))
      .set('timeframe_id', String(timeframeId))
      .set('indicator_ids', indicatorIds.join(','))
      .set('limit', String(Math.min(Math.max(1, limit), 4000)));
    if (after) params = params.set('after', after);
    if (before) params = params.set('before', before);
    return this.http.get<IndicatorValueRow[]>(
      `${this.appConfig.apiUrl}/indicator-values`,
      { params }
    ).pipe(timeout(15_000));
  }
}
