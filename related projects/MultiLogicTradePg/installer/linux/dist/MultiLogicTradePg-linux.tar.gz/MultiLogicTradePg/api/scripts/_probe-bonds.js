const { Pool } = require('pg');
const p = new Pool();
(async () => {
  const r = await p.query(
    "SELECT st.name AS type, sp.instrument_market, count(*) AS n " +
      "FROM securities s " +
      "JOIN security_types st ON st.id = s.security_type_id " +
      "JOIN security_prefixes sp ON sp.security_id = s.id " +
      "GROUP BY st.name, sp.instrument_market ORDER BY n DESC"
  );
  for (const x of r.rows) console.log(x.type, '|', x.instrument_market, '|', x.n);
  const bonds = await p.query(
    "SELECT sp.prefix, s.name, sp.instrument_market " +
      "FROM securities s " +
      "JOIN security_types st ON st.id = s.security_type_id " +
      "JOIN security_prefixes sp ON sp.security_id = s.id " +
      "WHERE st.name IN ('Bond','Bonds') OR sp.instrument_market IN ('bond','bonds') LIMIT 20"
  );
  console.log('--- bonds sample ---');
  for (const x of bonds.rows) console.log(x.prefix, '|', x.instrument_market, '|', x.name);
  await p.end();
})().catch((e) => { console.error('FAIL', e.message); process.exit(1); });