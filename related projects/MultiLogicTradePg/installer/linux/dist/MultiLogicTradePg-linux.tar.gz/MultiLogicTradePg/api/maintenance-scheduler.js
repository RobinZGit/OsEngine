'use strict';

const CLEANUP_CHECK_MS = Number(process.env.CLEANUP_CHECK_MS) || 60 * 60 * 1000; // hourly check
const CLEANUP_MIN_INTERVAL_MS = Number(process.env.CLEANUP_MIN_INTERVAL_MS) || 24 * 60 * 60 * 1000;

// Журнал ошибок «Мониторинг системы»: храним 24 ч, чистим каждый час (+ на старте).
const ERROR_LOG_RETENTION_HOURS = Number(process.env.ERROR_LOG_RETENTION_HOURS) || 24;
const ERROR_LOG_PURGE_CHECK_MS =
  Number(process.env.ERROR_LOG_PURGE_CHECK_MS) || 60 * 60 * 1000; // hourly

// Брокерская сверка (цена исполнения + комиссия → пересборка PnL боевых сделок).
// Лечит зависший finres, записанный по предварительной цене до финального fill.
const BROKER_FEE_SYNC_CHECK_MS =
  Number(process.env.BROKER_FEE_SYNC_CHECK_MS) || 5 * 60 * 1000; // каждые 5 минут

let running = false;
let feeSyncRunning = false;
let terminalFeeSyncRunning = false;
let errorPurgeRunning = false;

/**
 * Windows / no-pg_cron fallback: if APP_CLEANUP_DISK is on and last run > 24h,
 * call run_cleanup_if_enabled().
 */
async function maybeRunScheduledCleanup(pool) {
  if (running) return { skipped: true, reason: 'busy' };
  running = true;
  try {
    const { rows: enabledRows } = await pool.query(
      'SELECT cleanup_unused_market_data_enabled() AS enabled'
    );
    if (!enabledRows[0]?.enabled) {
      return { skipped: true, reason: 'disabled' };
    }

    const { rows: lastRows } = await pool.query(
      'SELECT app_cleanup_last_at() AS last_at'
    );
    const lastAt = lastRows[0]?.last_at ? new Date(lastRows[0].last_at) : null;
    if (lastAt && Number.isFinite(lastAt.getTime())) {
      const age = Date.now() - lastAt.getTime();
      if (age < CLEANUP_MIN_INTERVAL_MS) {
        return { skipped: true, reason: 'too_soon', last_at: lastAt.toISOString() };
      }
    }

    const { rows } = await pool.query('SELECT run_cleanup_if_enabled() AS result');
    return { ok: true, result: rows[0]?.result ?? {} };
  } catch (err) {
    console.error('Scheduled cleanup error', err.message);
    return { ok: false, error: err.message };
  } finally {
    running = false;
  }
}

/**
 * Периодическая сверка боевых сделок с T-Bank (GetOrderState): финальная цена
 * исполнения и комиссия → сразу пересобираются пакеты/PnL закрытий.
 * Отключается APP_BROKER_FEE_SYNC=0.
 */
async function maybeSyncBrokerFees(pool) {
  if (process.env.APP_BROKER_FEE_SYNC === '0') {
    return { skipped: true, reason: 'disabled' };
  }
  if (feeSyncRunning) return { skipped: true, reason: 'busy' };
  feeSyncRunning = true;
  try {
    const { rows } = await pool.query(
      'SELECT logic_sync_real_trade_broker_fees(NULL) AS result'
    );
    const result = rows[0]?.result ?? {};
    if (Number(result.updated) > 0 || result.rebuild_error) {
      console.log(
        `Broker fee sync: updated=${result.updated} refinalized=${result.refinalized}` +
          (result.rebuild_error ? ` rebuild_error=${result.rebuild_error}` : '')
      );
    }
    return { ok: true, result };
  } catch (err) {
    // Функции может не быть на старой схеме — молча ждать обновления 02.
    console.error('Broker fee sync error', err.message);
    return { ok: false, error: err.message };
  } finally {
    feeSyncRunning = false;
  }
}

/**
 * Сверка ручных сделок терминала по реальному счёту: PostOrder у маркет-заявки
 * комиссию обычно не отдаёт, а исполняется ЦЕЛОЕ число лотов — дотягиваем
 * комиссию и фактическую цену/количество (лоты × размер лота) с T-Bank.
 * Отключается тем же APP_BROKER_FEE_SYNC=0.
 */
async function maybeSyncTerminalBrokerFees(pool) {
  if (process.env.APP_BROKER_FEE_SYNC === '0') {
    return { skipped: true, reason: 'disabled' };
  }
  if (terminalFeeSyncRunning) return { skipped: true, reason: 'busy' };
  terminalFeeSyncRunning = true;
  try {
    const { rows } = await pool.query(
      'SELECT terminal_sync_real_trade_broker_fees(NULL, NULL) AS result'
    );
    const result = rows[0]?.result ?? {};
    if (Number(result.updated) > 0) {
      console.log(`Terminal broker fee sync: updated=${result.updated}`);
    }
    return { ok: true, result };
  } catch (err) {
    // Функции может не быть на старой схеме — молча ждать обновления 02.
    console.error('Terminal broker fee sync error', err.message);
    return { ok: false, error: err.message };
  } finally {
    terminalFeeSyncRunning = false;
  }
}

/**
 * Чистка app_error_log: удаляет записи старше retention (по умолчанию 24 ч).
 * Держит журнал «Мониторинг системы» компактным; вызывается каждый час и на старте.
 */
async function purgeErrorLog(pool) {
  if (process.env.ERROR_LOG_PURGE_ENABLED === '0') {
    return { skipped: true, reason: 'disabled' };
  }
  if (errorPurgeRunning) return { skipped: true, reason: 'busy' };
  errorPurgeRunning = true;
  try {
    const res = await pool.query(
      `DELETE FROM app_error_log WHERE created_at < now() - make_interval(hours => $1::int)`,
      [ERROR_LOG_RETENTION_HOURS]
    );
    return { ok: true, deleted: res.rowCount ?? 0 };
  } catch (err) {
    // На старой схеме таблицы может не быть — молча ждём обновления 01.
    if (process.env.ERROR_LOG_DEBUG === '1') {
      console.error('Error log purge error', err.message);
    }
    return { ok: false, error: err.message };
  } finally {
    errorPurgeRunning = false;
  }
}

function startMaintenanceScheduler(pool) {
  if (process.env.CLEANUP_SCHEDULER_ENABLED === '0') {
    console.log('Maintenance cleanup scheduler: disabled (CLEANUP_SCHEDULER_ENABLED=0)');
  } else {
    console.log(
      `Maintenance cleanup scheduler: check every ${CLEANUP_CHECK_MS}ms; min interval ${CLEANUP_MIN_INTERVAL_MS}ms when APP_CLEANUP_DISK on`
    );
    setInterval(() => {
      maybeRunScheduledCleanup(pool).catch((err) => {
        console.error('Maintenance cleanup tick error', err.message);
      });
    }, CLEANUP_CHECK_MS);
    // First check shortly after API start (do not block listen)
    setTimeout(() => {
      maybeRunScheduledCleanup(pool).catch(() => {});
    }, 15000);
  }

  if (process.env.APP_BROKER_FEE_SYNC === '0') {
    console.log('Broker fee sync scheduler: disabled (APP_BROKER_FEE_SYNC=0)');
  } else {
    console.log(`Broker fee sync scheduler: every ${BROKER_FEE_SYNC_CHECK_MS}ms`);
    setInterval(() => {
      maybeSyncBrokerFees(pool).catch((err) => {
        console.error('Broker fee sync tick error', err.message);
      });
      maybeSyncTerminalBrokerFees(pool).catch((err) => {
        console.error('Terminal broker fee sync tick error', err.message);
      });
    }, BROKER_FEE_SYNC_CHECK_MS);
    setTimeout(() => {
      maybeSyncBrokerFees(pool).catch(() => {});
      maybeSyncTerminalBrokerFees(pool).catch(() => {});
    }, 30000);
  }

  if (process.env.ERROR_LOG_PURGE_ENABLED === '0') {
    console.log('Error log purge scheduler: disabled (ERROR_LOG_PURGE_ENABLED=0)');
  } else {
    console.log(
      `Error log purge scheduler: retention ${ERROR_LOG_RETENTION_HOURS}h; check every ${ERROR_LOG_PURGE_CHECK_MS}ms`
    );
    setInterval(() => {
      purgeErrorLog(pool).catch((err) => {
        console.error('Error log purge tick error', err.message);
      });
    }, ERROR_LOG_PURGE_CHECK_MS);
    setTimeout(() => {
      purgeErrorLog(pool).catch(() => {});
    }, 20000);
  }
}

module.exports = {
  maybeRunScheduledCleanup,
  maybeSyncBrokerFees,
  maybeSyncTerminalBrokerFees,
  purgeErrorLog,
  startMaintenanceScheduler,
};
