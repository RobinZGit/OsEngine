'use strict';

const { writeTechLogEvent } = require('./lib/tech-log');
const { writeErrorLog } = require('./lib/error-log');
const { schedulePersistBacktestReport } = require('./backtest-report-persist');

/**
 * Параллельность подготовки бумаг внутри одного прогона.
 * Env: BACKTEST_PRICE_CONCURRENCY (1..8). По умолчанию 3 — кэш цен + sync
 * индикаторов идут параллельно; HTTP load_prices всё ещё single-flight по ключу.
 * При SSL timeout T-Bank/MOEX снизьте до 1.
 *
 * Между прогонами: load_prices — single-flight по ключу
 * (security_id, timeframe_id, date_from, date_to). Первый грузит HTTP,
 * остальные ждут тот же Promise и читают `prices` из БД; индикаторы каждый
 * прогон считает сам (ensure/sync) по своим сигналам логики.
 */
const BACKTEST_PRICE_CONCURRENCY = Math.max(
  1,
  Math.min(8, Number(process.env.BACKTEST_PRICE_CONCURRENCY) || 3)
);

/** Куски HTTP-загрузки цен (дни), чтобы UI tip не залипал на одной бумаге месяцами истории. */
const BACKTEST_PRICE_CHUNK_DAYS = Math.max(
  7,
  Math.min(90, Number(process.env.BACKTEST_PRICE_CHUNK_DAYS) || 30)
);

/** @type {Map<string, Promise<object>>} */
const priceLoadFlights = new Map();

/** In-process workers — prevents double-start of the same run_id. */
const activeBacktestRuns = new Set();

function priceLoadKey(secId, tfId, dateFrom, dateTo) {
  return `${Number(secId)}|${Number(tfId)}|${String(dateFrom)}|${String(dateTo)}`;
}

/** Разбить [from,to] на окна по chunkDays (включительно, YYYY-MM-DD). */
function splitDateRangeChunks(dateFrom, dateTo, chunkDays = BACKTEST_PRICE_CHUNK_DAYS) {
  const from = String(dateFrom || '').slice(0, 10);
  const to = String(dateTo || '').slice(0, 10);
  if (!from || !to || from > to) return [];
  const days = Math.max(1, Number(chunkDays) || 30);
  const spanDays =
    Math.round(
      (new Date(`${to}T12:00:00`).getTime() - new Date(`${from}T12:00:00`).getTime()) /
        86400000
    ) + 1;
  if (spanDays <= days) {
    return [{ from, to, index: 0, total: 1 }];
  }
  const chunks = [];
  let cur = from;
  while (cur <= to) {
    let end = shiftDate(cur, days - 1);
    if (end > to) end = to;
    chunks.push({ from: cur, to: end, index: chunks.length, total: 0 });
    cur = shiftDate(end, 1);
  }
  for (const c of chunks) c.total = chunks.length;
  return chunks;
}

/**
 * Single-flight загрузка цен в общую таблицу `prices`.
 * Длинный период режется на окна — onChunk обновляет tip в UI.
 * @returns {Promise<{
 *   status: 'cached'|'loaded'|'partial'|'empty'|'error',
 *   waited: boolean,
 *   pricesReloaded: boolean,
 *   inPeriod: number,
 *   error?: Error
 * }>}
 */
/**
 * #1050: жёсткий таймаут на CALL load_prices/load_prices_http.
 * HTTP к T-Bank/MOEX может «зависнуть» на SSL-соединении на десятки минут;
 * ставим statement_timeout на выделенном соединении и watchdog-отмену,
 * чтобы подготовка бэктеста не висела вечно.
 */
async function callPriceLoadWithTimeout(pool, sql, params, timeoutMs = 180000) {
  const client = await pool.connect();
  let pid = 0;
  let finished = false;
  let watchdog = null;
  try {
    const pidRes = await client.query('SELECT pg_backend_pid() AS pid');
    pid = Number(pidRes.rows[0]?.pid) || 0;
    await client.query(
      `SET statement_timeout = '${Math.max(1000, Math.floor(timeoutMs))}'`
    );
    if (pid) {
      watchdog = setTimeout(() => {
        if (!finished) {
          pool.query('SELECT pg_cancel_backend($1)', [pid]).catch(() => {});
        }
      }, timeoutMs + 5000);
      if (typeof watchdog.unref === 'function') watchdog.unref();
    }
    await client.query(sql, params);
  } finally {
    finished = true;
    if (watchdog) clearTimeout(watchdog);
    try {
      await client.query('RESET statement_timeout');
    } catch (_e) {
      /* соединение могло быть уже сброшено таймаутом */
    }
    client.release();
  }
}

async function ensurePricesReady(pool, secId, tfId, loadDateFrom, dateFrom, dateTo, onChunk = null) {
  const key = priceLoadKey(secId, tfId, loadDateFrom, dateTo);

  if (await pricesCached(pool, secId, tfId, loadDateFrom, dateFrom, dateTo)) {
    return {
      status: 'cached',
      waited: false,
      pricesReloaded: false,
      inPeriod: await countPricesForSecurity(pool, secId, tfId, dateFrom, dateTo),
    };
  }

  let isLeader = false;
  let flight = priceLoadFlights.get(key);
  if (!flight) {
    isLeader = true;
    flight = (async () => {
      try {
        if (await pricesCached(pool, secId, tfId, loadDateFrom, dateFrom, dateTo)) {
          return {
            status: 'cached',
            pricesReloaded: false,
            inPeriod: await countPricesForSecurity(pool, secId, tfId, dateFrom, dateTo),
          };
        }
        const chunks = splitDateRangeChunks(loadDateFrom, dateTo, BACKTEST_PRICE_CHUNK_DAYS);
        for (const chunk of chunks) {
          if (typeof onChunk === 'function') {
            await onChunk(chunk);
          }
          await callPriceLoadWithTimeout(
            pool,
            'CALL load_prices($1, $2, $3, $4)',
            [secId, tfId, chunk.from, chunk.to],
            180000
          );
        }
        const okAfterLoad = await pricesCached(
          pool,
          secId,
          tfId,
          loadDateFrom,
          dateFrom,
          dateTo
        );
        const inPeriod = await countPricesForSecurity(pool, secId, tfId, dateFrom, dateTo);
        if (okAfterLoad) {
          return { status: 'loaded', pricesReloaded: true, inPeriod };
        }
        if (inPeriod > 0) {
          return { status: 'partial', pricesReloaded: true, inPeriod };
        }
        return { status: 'empty', pricesReloaded: false, inPeriod: 0 };
      } catch (error) {
        return { status: 'error', pricesReloaded: false, inPeriod: 0, error };
      } finally {
        priceLoadFlights.delete(key);
      }
    })();
    priceLoadFlights.set(key, flight);
  } else if (typeof onChunk === 'function') {
    // Follower: пока лидер грузит — подсказка, что ждём shared load.
    await onChunk({
      from: String(loadDateFrom).slice(0, 10),
      to: String(dateTo).slice(0, 10),
      index: 0,
      total: 1,
      waiting: true,
    });
  }

  const result = await flight;
  return {
    status: result.status,
    waited: !isLeader,
    pricesReloaded: Boolean(result.pricesReloaded),
    inPeriod: Number(result.inPeriod) || 0,
    error: result.error,
  };
}

/**
 * Single-flight для денежного фонда (load_prices_http, без проверки backtest_prices_cached).
 */
async function ensureFundPricesReady(pool, fundSecId, tfId, loadDateFrom, loadDateTo) {
  const key = `fund|${priceLoadKey(fundSecId, tfId, loadDateFrom, loadDateTo)}`;
  let isLeader = false;
  let flight = priceLoadFlights.get(key);
  if (!flight) {
    isLeader = true;
    flight = (async () => {
      try {
        await callPriceLoadWithTimeout(
          pool,
          `CALL load_prices_http($1, $2, $3::date, $4::date)`,
          [fundSecId, tfId, loadDateFrom, loadDateTo],
          120000
        );
        return { status: 'loaded', error: null };
      } catch (error) {
        return { status: 'error', error };
      } finally {
        priceLoadFlights.delete(key);
      }
    })();
    priceLoadFlights.set(key, flight);
  }
  const result = await flight;
  return { status: result.status, waited: !isLeader, error: result.error };
}

async function countPricesForSecurity(pool, secId, tfId, dateFrom, dateTo) {
  const { rows } = await pool.query(
    `SELECT COUNT(*)::int AS cnt FROM prices p
     WHERE p.security_id = $1 AND p.timeframe_id = $2
       AND p.dt::date BETWEEN $3 AND $4`,
    [secId, tfId, dateFrom, dateTo]
  );
  return rows[0]?.cnt ?? 0;
}

/**
 * Ограниченный параллельный обход: не больше `concurrency` задач одновременно.
 * Индекс следующего элемента берётся синхронно (безопасно в однопоточном Node).
 */
async function mapPool(items, concurrency, worker) {
  if (!items.length) return;
  let next = 0;
  const n = Math.min(Math.max(1, concurrency), items.length);
  await Promise.all(
    Array.from({ length: n }, async () => {
      for (;;) {
        const i = next;
        next += 1;
        if (i >= items.length) return;
        await worker(items[i], i);
      }
    })
  );
}

async function backtestLog(pool, runId, logicId, operation, message, payload = null, securityId = null, tfId = null) {
  try {
    await pool.query(
      `SELECT logic_backtest_log($1, $2, $3, $4, $5::jsonb, $6, $7)`,
      [
        runId,
        logicId,
        operation,
        message,
        payload != null ? JSON.stringify(payload) : null,
        securityId,
        tfId,
      ]
    );
  } catch (err) {
    console.warn('backtestLog', operation, err.message);
  }
  try {
    await writeTechLogEvent(pool, {
      threadKey: `logic:${logicId}:backtest:${runId}`,
      operation,
      message,
      source: 'backtest',
      logicId,
      securityId,
      timeframeId: tfId,
      payload: { run_id: runId, ...(payload || {}) },
    });
  } catch (_err) {
    /* APP_TECH_LOGGING may be off */
  }
}

async function updateRun(pool, runId, patch) {
  const { rows: curRows } = await pool.query(
    `SELECT status, cancel_requested FROM logic_backtest_runs WHERE id = $1`,
    [runId]
  );
  const cur = curRows[0];
  if (!cur) return;

  // После Стоп не воскрешаем прогон и не затираем «Отменено»
  if (cur.status === 'cancelled' || cur.cancel_requested) {
    if (patch.status && patch.status !== 'cancelled') {
      delete patch.status;
    }
    if (
      (cur.status === 'cancelled' || cur.cancel_requested) &&
      patch.phase_message &&
      !String(patch.phase_message).includes('Отмен')
    ) {
      delete patch.phase_message;
    }
  }

  const fields = [];
  const values = [runId];
  let i = 2;
  for (const [key, val] of Object.entries(patch)) {
    if (val === undefined) continue;
    fields.push(`${key} = $${i}`);
    values.push(val);
    i += 1;
  }
  if (fields.length === 0) return;
  await pool.query(
    `UPDATE logic_backtest_runs SET ${fields.join(', ')} WHERE id = $1`,
    values
  );

  // Archive report outside the hot path whenever a run reaches a terminal status.
  const terminal = patch.status;
  if (
    terminal === 'completed' ||
    terminal === 'cancelled' ||
    terminal === 'failed'
  ) {
    schedulePersistBacktestReport(pool, runId, { isSnapshot: false });
  }
}

/**
 * Троттлинг записи progress_pct, чтобы UI не «стоял», но и не долбил БД каждый мс.
 * force — всегда писать (конец фазы / 100%).
 */
function createProgressReporter(pool, runId, minIntervalMs = 200) {
  let lastAt = 0;
  let lastPct = -1;
  let pending = null;
  let timer = null;

  const flush = async (patch) => {
    lastAt = Date.now();
    if (patch.progress_pct != null) lastPct = Number(patch.progress_pct);
    await updateRun(pool, runId, patch);
  };

  return async function report(patch, opts = {}) {
    const force = Boolean(opts.force);
    const now = Date.now();
    const pct = patch.progress_pct != null ? Number(patch.progress_pct) : null;
    const elapsed = now - lastAt;
    const pctJump = pct != null && lastPct >= 0 ? Math.abs(pct - lastPct) : 99;

    if (force || elapsed >= minIntervalMs || pctJump >= 0.4 || lastPct < 0) {
      if (timer) {
        clearTimeout(timer);
        timer = null;
        pending = null;
      }
      await flush(patch);
      return;
    }

    pending = patch;
    if (!timer) {
      timer = setTimeout(() => {
        timer = null;
        const p = pending;
        pending = null;
        if (p) flush(p).catch(() => {});
      }, Math.max(50, minIntervalMs - elapsed));
    }
  };
}

async function isCancelRequested(pool, runId) {
  const { rows } = await pool.query(
    'SELECT cancel_requested, status FROM logic_backtest_runs WHERE id = $1',
    [runId]
  );
  if (rows.length === 0) return true;
  return rows[0].cancel_requested || !['pending', 'loading_prices', 'loading_indicators', 'running'].includes(rows[0].status);
}

async function fetchActiveSecurityIds(pool, logicId) {
  const { rows } = await pool.query(
    `SELECT ls.security_id, s.name
     FROM logic_securities ls
     JOIN securities s ON s.id = ls.security_id
     WHERE ls.logic_id = $1 AND ls.is_active = TRUE
       AND NOT EXISTS (
         SELECT 1
         FROM security_prefixes sp
         WHERE sp.security_id = ls.security_id
           AND upper(sp.prefix) IN ('TMON', 'LQDT', 'SBMM')
       )
     ORDER BY ls.display_order, ls.id`,
    [logicId]
  );
  return rows;
}

async function fetchActiveIndicatorIds(pool, logicId) {
  const { rows } = await pool.query(
    `SELECT DISTINCT indicator_id FROM logic_indicator_signals
     WHERE logic_id = $1 AND is_active = TRUE`,
    [logicId]
  );
  return rows.map((r) => r.indicator_id);
}

async function pricesCached(pool, secId, tfId, warmupFrom, dateFrom, dateTo) {
  const { rows } = await pool.query(
    `SELECT backtest_prices_cached($1, $2, $3, $4, $5, 20) AS cached`,
    [secId, tfId, warmupFrom, dateFrom, dateTo]
  );
  return Boolean(rows[0]?.cached);
}

async function indicatorsCached(pool, secId, tfId, indicatorId, dateFrom, dateTo) {
  const { rows } = await pool.query(
    `SELECT backtest_indicators_cached($1, $2, $3, $4, $5) AS cached`,
    [secId, tfId, indicatorId, dateFrom, dateTo]
  );
  return Boolean(rows[0]?.cached);
}

/** Snapshot series param_* so we can detect formula-driven changes after apply. */
async function snapshotIndicatorSeriesParams(pool, secId, indicatorId) {
  const { rows } = await pool.query(
    `
    SELECT
      param_period,
      param_std_dev::text AS param_std_dev,
      param_fast_period,
      param_slow_period,
      param_signal_period,
      param_k_period,
      param_d_period,
      param_smooth
    FROM security_indicator_series
    WHERE security_id = $1
      AND indicator_id = $2
      AND is_active = TRUE
    ORDER BY id
    `,
    [secId, indicatorId]
  );
  return JSON.stringify(rows);
}

async function fetchPriceLoadLog(pool, logicId, tfId, dateFrom, dateTo) {
  const { rows } = await pool.query(
    `SELECT pll.security_id, pll.source, pll.records_loaded, pll.error_message,
            pll.date_from, pll.date_to
     FROM price_load_log pll
     JOIN logic_securities ls ON ls.security_id = pll.security_id
     WHERE ls.logic_id = $1 AND ls.is_active = TRUE
       AND pll.timeframe_id = $2
       AND pll.date_from >= $3::date - 30
       AND pll.date_to <= $4::date
     ORDER BY pll.id DESC
     LIMIT 10`,
    [logicId, tfId, dateFrom, dateTo]
  );
  return rows;
}

async function countPricesInPeriod(pool, logicId, tfId, dateFrom, dateTo, securityId = null) {
  const params = [logicId, tfId, dateFrom, dateTo];
  let secFilter = '';
  if (securityId != null) {
    params.push(securityId);
    secFilter = ` AND p.security_id = $${params.length}`;
  }
  const { rows } = await pool.query(
    `SELECT COUNT(*)::int AS cnt FROM prices p
     JOIN logic_securities ls ON ls.security_id = p.security_id
     WHERE ls.logic_id = $1 AND ls.is_active = TRUE
       AND p.timeframe_id = $2 AND p.dt::date BETWEEN $3 AND $4${secFilter}`,
    params
  );
  return rows[0]?.cnt ?? 0;
}

/** Fast presence check — full COUNT on indicator_values is multi-second on large DBs. */
async function hasIndicatorsInPeriod(pool, logicId, tfId, dateFrom, dateTo) {
  const { rows } = await pool.query(
    `
    SELECT EXISTS (
      SELECT 1
      FROM indicator_values iv
      JOIN logic_securities ls ON ls.security_id = iv.security_id
      WHERE ls.logic_id = $1 AND ls.is_active = TRUE
        AND iv.timeframe_id = $2 AND iv.dt::date BETWEEN $3 AND $4
      LIMIT 1
    ) AS ok
    `,
    [logicId, tfId, dateFrom, dateTo]
  );
  return Boolean(rows[0]?.ok);
}

async function hasPricesInPeriod(pool, logicId, tfId, dateFrom, dateTo) {
  const { rows } = await pool.query(
    `
    SELECT EXISTS (
      SELECT 1
      FROM prices p
      JOIN logic_securities ls ON ls.security_id = p.security_id
      WHERE ls.logic_id = $1 AND ls.is_active = TRUE
        AND p.timeframe_id = $2 AND p.dt::date BETWEEN $3 AND $4
      LIMIT 1
    ) AS ok
    `,
    [logicId, tfId, dateFrom, dateTo]
  );
  return Boolean(rows[0]?.ok);
}

async function countIndicatorsInPeriod(pool, logicId, tfId, dateFrom, dateTo) {
  const { rows } = await pool.query(
    `SELECT COUNT(*)::int AS cnt FROM indicator_values iv
     JOIN logic_securities ls ON ls.security_id = iv.security_id
     WHERE ls.logic_id = $1 AND ls.is_active = TRUE
       AND iv.timeframe_id = $2 AND iv.dt::date BETWEEN $3 AND $4`,
    [logicId, tfId, dateFrom, dateTo]
  );
  return rows[0]?.cnt ?? 0;
}

/**
 * Форс-пересчёт индикаторов по логике — fallback, если кэш сообщил «cached», но в
 * периоде 0 значений (значения удалила автоочистка indicator_values / гонка).
 * Best-effort: ошибки логируются и не валят прогон. Возвращает {synced, errors}.
 */
/**
 * #1055: точечная синхронизация серий, которых нет в периоде у конкретной
 * бумаги/индикатора. Раньше проверка была на всю логику: если значения были
 * хоть у одной бумаги, sync пропускался, и по остальным сигналы молчали.
 */
async function syncMissingIndicatorSeriesForLogic(
  pool,
  runId,
  logicId,
  tfId,
  dateFrom,
  dateTo,
  endDt,
  pointCount
) {
  const { rows } = await pool.query(
    `
    WITH req AS (
      SELECT DISTINCT
        ls.security_id,
        lis.indicator_id,
        upper(COALESCE(parse_signal_series(psf.params), 'VALUE')) AS series_code
      FROM logic_securities ls
      JOIN logic_indicator_signals lis ON lis.logic_id = ls.logic_id
      LEFT JOIN LATERAL parse_signal_formula(lis.formula) psf ON TRUE
      WHERE ls.logic_id = $1
        AND ls.is_active = TRUE
        AND lis.is_active = TRUE
    )
    SELECT r.security_id, r.indicator_id, r.series_code
    FROM req r
    WHERE NOT EXISTS (
      SELECT 1
      FROM indicator_values iv
      JOIN indicator_value_types ivt ON ivt.id = iv.indicator_value_type_id
      WHERE iv.security_id = r.security_id
        AND iv.timeframe_id = $2
        AND iv.indicator_id = r.indicator_id
        AND upper(ivt.code) = r.series_code
        AND iv.dt::date BETWEEN $3 AND $4
    )
    `,
    [logicId, tfId, dateFrom, dateTo]
  );
  let synced = 0;
  let errors = 0;
  for (const r of rows) {
    try {
      await pool.query('CALL ensure_security_indicator_series($1, $2)', [
        r.security_id,
        r.indicator_id,
      ]);
      await pool.query('CALL logic_apply_indicator_params_from_signals($1, $2)', [
        logicId,
        r.security_id,
      ]);
      await pool.query(
        'CALL sync_security_indicator_series_for_indicator($1, $2, $3, $4, $5, $6)',
        [r.security_id, r.indicator_id, tfId, endDt, pointCount, false]
      );
      synced += 1;
    } catch (e) {
      errors += 1;
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.indicator.error',
        e.message,
        {
          security_id: r.security_id,
          indicator_id: r.indicator_id,
          series_code: r.series_code,
          phase: 'missing_series',
        },
        r.security_id,
        tfId
      );
    }
  }
  if (rows.length > 0) {
    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.indicators.missing_synced',
      `Точечный пересчёт отсутствующих серий: sync=${synced} err=${errors}`,
      { missing: rows.length, synced, errors },
      null,
      tfId
    );
  }
  return { missing: rows.length, synced, errors };
}

async function forceSyncIndicatorsForLogic(pool, runId, logicId, tfId, endDt, pointCount) {
  const { rows: secRows } = await pool.query(
    `SELECT DISTINCT ls.security_id
     FROM logic_securities ls
     WHERE ls.logic_id = $1 AND ls.is_active = TRUE`,
    [logicId]
  );
  const indicatorIds = await fetchActiveIndicatorIds(pool, logicId);
  let synced = 0;
  let errors = 0;
  for (const { security_id: secId } of secRows) {
    for (const indicatorId of indicatorIds) {
      try {
        await pool.query('CALL ensure_security_indicator_series($1, $2)', [secId, indicatorId]);
        await pool.query('CALL logic_apply_indicator_params_from_signals($1, $2)', [
          logicId,
          secId,
        ]);
        await pool.query(
          'CALL sync_security_indicator_series_for_indicator($1, $2, $3, $4, $5, $6)',
          [secId, indicatorId, tfId, endDt, pointCount, false]
        );
        synced += 1;
      } catch (e) {
        errors += 1;
        await backtestLog(
          pool,
          runId,
          logicId,
          'backtest.indicator.error',
          e.message,
          { security_id: secId, indicator_id: indicatorId, phase: 'force_sync' },
          secId,
          tfId
        );
      }
    }
  }
  return { synced, errors };
}

async function logicTimeframeSec(pool, logicId) {
  const { rows } = await pool.query(
    `SELECT t.sec FROM timeframes t
     WHERE t.id = logic_resolve_timeframe_id($1)`,
    [logicId]
  );
  return Number(rows[0]?.sec ?? 86400);
}

async function ensureTbankForBacktest(pool, runId, logicId) {
  const tfSec = await logicTimeframeSec(pool, logicId);
  if (tfSec >= 86400) return true;

  const { rows } = await pool.query(`SELECT tbank_verify_token() AS s`);
  const status = rows[0]?.s ?? {};
  if (status.valid) return true;

  await backtestLog(
    pool,
    runId,
    logicId,
    'backtest.tbank.missing',
    status.error_message ||
      'Токен T-Bank не задан или невалиден — загрузка цен через MOEX',
    { tbank_status: status }
  );
  return true;
}

/**
 * Подготовка одной бумаги:
 * (1) цены — shared single-flight по ключу → таблица `prices`;
 * (2) индикаторы — каждый прогон считает сам по активным сигналам логики.
 * onPhase(kind, detail) — для плавного progress_pct (начало HTTP, после цен, по индикаторам).
 */
async function ensureSecurityData(
  pool,
  runId,
  logicId,
  secId,
  secName,
  tfId,
  loadDateFrom,
  dateFrom,
  dateTo,
  endDt,
  pointCount,
  stats,
  onPhase = null
) {
  const phase = async (kind, detail, frac) => {
    if (typeof onPhase === 'function') {
      await onPhase({ kind, detail, frac, secId, secName });
    }
  };

  await phase('prices_http_start', `Цены: ${secName || secId}`, 0.12);
  const priceResult = await ensurePricesReady(
    pool,
    secId,
    tfId,
    loadDateFrom,
    dateFrom,
    dateTo,
    async (chunk) => {
      const n = Math.max(1, Number(chunk.total) || 1);
      const i = Math.min(n, (Number(chunk.index) || 0) + 1);
      const wait = chunk.waiting ? 'ожидание shared · ' : '';
      const frac = 0.12 + 0.4 * ((Number(chunk.index) || 0) / n);
      await phase(
        'prices_http_chunk',
        `${wait}Цены ${secName || secId}: ${chunk.from}–${chunk.to} (${i}/${n})`,
        frac
      );
    }
  );
  const pricesReloaded = Boolean(priceResult.pricesReloaded);

  if (priceResult.status === 'error') {
    stats.pricesErr += 1;
    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.prices.error',
      priceResult.error?.message || 'load_prices failed',
      {
        security_id: secId,
        name: secName,
        waited: priceResult.waited,
        price_key: priceLoadKey(secId, tfId, loadDateFrom, dateTo),
      },
      secId,
      tfId
    );
    // Если загрузка источников недоступна (напр. облигационный фонд,
    // instrument_market='other', где провайдер даёт SSL timeout), но в периоде
    // уже есть исторические цены — не роняем подготовку целиком, а продолжаем
    // синк индикаторов по имеющимся барам (фонды тогда торгуются на покрытом
    // участке вместо полного молчания). Если данных в периоде нет — выходим.
    const existingInPeriod = await countPricesForSecurity(
      pool,
      secId,
      tfId,
      dateFrom,
      dateTo
    );
    if (existingInPeriod > 0) {
      priceResult.status = 'partial';
      priceResult.inPeriod = existingInPeriod;
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.prices.partial_after_error',
        `Источники недоступны, но есть ${existingInPeriod} свечей — синкаем по имеющимся: ${secName || secId}`,
        {
          security_id: secId,
          name: secName,
          prices_in_period: existingInPeriod,
        },
        secId,
        tfId
      );
    } else {
      return;
    }
  }

  if (priceResult.status === 'cached') {
    stats.pricesCached += 1;
    await phase('prices_cache', `Кэш цен: ${secName || secId}`, 0.35);
    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.prices.cached',
      `Кэш цен: ${secName || secId} (${loadDateFrom} — ${dateTo})`,
      { security_id: secId, name: secName },
      secId,
      tfId
    );
  } else if (priceResult.waited) {
    stats.pricesShared += 1;
    await phase('prices_http_done', `Общие цены: ${secName || secId}`, 0.55);
    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.prices.shared',
      `Цены из shared load: ${secName || secId} (${priceResult.status}, ${priceResult.inPeriod} свечей)`,
      {
        security_id: secId,
        name: secName,
        status: priceResult.status,
        prices_in_period: priceResult.inPeriod,
        price_key: priceLoadKey(secId, tfId, loadDateFrom, dateTo),
      },
      secId,
      tfId
    );
  } else {
    stats.pricesLoaded += 1;
    await phase('prices_http_done', `Цены загружены: ${secName || secId}`, 0.55);
    await backtestLog(
      pool,
      runId,
      logicId,
      priceResult.status === 'loaded'
        ? 'backtest.prices.loaded'
        : priceResult.status === 'partial'
          ? 'backtest.prices.partial'
          : 'backtest.prices.insufficient',
      priceResult.status === 'loaded'
        ? `Цены загружены: ${secName || secId}, в периоде ${priceResult.inPeriod} свечей`
        : priceResult.status === 'partial'
          ? `Частичные цены: ${secName || secId}, в периоде ${priceResult.inPeriod} свечей — считаем индикаторы`
          : `Недостаточно свечей после загрузки (${priceResult.inPeriod} в периоде ${dateFrom} — ${dateTo})`,
      {
        security_id: secId,
        prices_in_period: priceResult.inPeriod,
        coverage_ok: priceResult.status === 'loaded',
        price_key: priceLoadKey(secId, tfId, loadDateFrom, dateTo),
      },
      secId,
      tfId
    );
  }

  if (priceResult.status === 'empty') {
    stats.pricesErr += 1;
    return;
  }

  // Цены базы (base_asset/contango) + синтетика contango.
  try {
    const { rows: undRows } = await pool.query(
      `
      SELECT DISTINCT
        u.id AS security_id,
        COALESCE(sp.prefix, u.name) AS name
      FROM logic_indicator_signals lis
      CROSS JOIN LATERAL (
        SELECT logic_future_underlying_security_id($2) AS und_id
      ) x
      JOIN securities u ON u.id = x.und_id
      LEFT JOIN security_prefixes sp ON sp.security_id = u.id
      WHERE lis.logic_id = $1
        AND lis.is_active = TRUE
        AND COALESCE(lis.signal_acts_on, 'security') IN ('base_asset', 'contango')
        AND x.und_id IS NOT NULL
        AND x.und_id <> $2
      `,
      [logicId, secId]
    );
    for (const und of undRows) {
      const undLabel = und.name || String(und.security_id);
      await ensurePricesReady(
        pool,
        und.security_id,
        tfId,
        loadDateFrom,
        dateFrom,
        dateTo,
        async (chunk) => {
          const n = Math.max(1, Number(chunk.total) || 1);
          const i = Math.min(n, (Number(chunk.index) || 0) + 1);
          const wait = chunk.waiting ? 'ожидание shared · ' : '';
          await phase(
            'prices_http_chunk_base',
            `${wait}База для ${secName || secId} → ${undLabel}: ${chunk.from}–${chunk.to} (${i}/${n})`,
            0.5
          );
        }
      );
    }
    const { rows: ctgNeed } = await pool.query(
      `
      SELECT 1
      FROM logic_indicator_signals lis
      WHERE lis.logic_id = $1
        AND lis.is_active = TRUE
        AND COALESCE(lis.signal_acts_on, 'security') = 'contango'
      LIMIT 1
      `,
      [logicId]
    );
    if (ctgNeed.length > 0) {
      await phase('prices_contango', `Контанго: ${secName || secId}`, 0.52);
      await pool.query(`SELECT sync_contango_prices($1, $2, $3::date, $4::date)`, [
        secId,
        tfId,
        loadDateFrom,
        dateTo,
      ]);
    }
  } catch (undErr) {
    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.prices.underlying_error',
      undErr?.message || String(undErr),
      { security_id: secId, name: secName },
      secId,
      tfId
    );
  }

  // (1c) Дополнительные timeframe из формул сигналов (например H2). Если для них
  // нет цен в периоде — резэмплим из основного tf, чтобы сигналы вида
  // @LINREG(tf=H2,...) могли быть оценены. Реальные биржевые свечи не трогаем.
  const extraTfIds = [];
  try {
    const { rows: extraRows } = await pool.query(
      `SELECT logic_signal_extra_tf_ids($1, $2) AS tf_id`,
      [logicId, tfId]
    );
    for (const r of extraRows) {
      const id = Number(r.tf_id);
      if (
        Number.isInteger(id) &&
        id > 0 &&
        id !== Number(tfId) &&
        !extraTfIds.includes(id)
      ) {
        extraTfIds.push(id);
      }
    }
  } catch (e) {
    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.extra_tf.error',
      e?.message || String(e),
      { security_id: secId, name: secName },
      secId,
      tfId
    );
  }

  for (const extraTfId of extraTfIds) {
    try {
      const { rows: cntRows } = await pool.query(
        `SELECT COUNT(*)::int AS cnt
         FROM prices
         WHERE security_id = $1 AND timeframe_id = $2
           AND dt::date BETWEEN $3::date AND $4::date`,
        [secId, extraTfId, dateFrom, dateTo]
      );
      if (Number(cntRows[0]?.cnt ?? 0) === 0) {
        await phase(
          'prices_resample',
          `Резэмпл ${secName || secId}: M15 → tf ${extraTfId}`,
          0.58
        );
        await pool.query(
          'CALL resample_prices_to_timeframe($1, $2, $3, $4::date, $5::date)',
          [secId, tfId, extraTfId, loadDateFrom, dateTo]
        );
        stats.pricesResampled += 1;
        await backtestLog(
          pool,
          runId,
          logicId,
          'backtest.prices.resampled',
          `Резэмпл ${secName || secId}: tf ${tfId} → tf ${extraTfId} (${loadDateFrom} — ${dateTo})`,
          { security_id: secId, name: secName, src_tf: tfId, dst_tf: extraTfId },
          secId,
          extraTfId
        );
      }
    } catch (e) {
      stats.pricesErr += 1;
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.prices.resample_error',
        e?.message || String(e),
        { security_id: secId, name: secName, src_tf: tfId, dst_tf: extraTfId },
        secId,
        extraTfId
      );
    }
  }

  // (2) Indicators: apply @CODE(...period/std_dev...) from logic signals onto
  // security_indicator_series, then sync. Skip cache only if params unchanged.
  const indicatorIds = await fetchActiveIndicatorIds(pool, logicId);
  const indTotal = Math.max(1, indicatorIds.length);
  let indDone = 0;
  await phase('indicators_start', `Индикаторы: ${secName || secId}`, 0.6);

  /** @type {Map<number, string>} */
  const paramsBefore = new Map();
  for (const indicatorId of indicatorIds) {
    try {
      await pool.query('CALL ensure_security_indicator_series($1, $2)', [secId, indicatorId]);
      paramsBefore.set(
        indicatorId,
        await snapshotIndicatorSeriesParams(pool, secId, indicatorId)
      );
    } catch (e) {
      stats.indErr += 1;
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.indicator.error',
        e.message,
        { security_id: secId, indicator_id: indicatorId, name: secName, phase: 'ensure' },
        secId,
        tfId
      );
    }
  }

  try {
    await pool.query('CALL logic_apply_indicator_params_from_signals($1, $2)', [
      logicId,
      secId,
    ]);
  } catch (e) {
    stats.indErr += 1;
    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.indicator.error',
      e.message,
      { security_id: secId, name: secName, phase: 'apply_params' },
      secId,
      tfId
    );
  }

  for (const indicatorId of indicatorIds) {
    let paramsChanged = true;
    try {
      const after = await snapshotIndicatorSeriesParams(pool, secId, indicatorId);
      paramsChanged = (paramsBefore.get(indicatorId) ?? '') !== after;
    } catch (_e) {
      paramsChanged = true;
    }

    if (
      !pricesReloaded &&
      !paramsChanged &&
      (await indicatorsCached(pool, secId, tfId, indicatorId, dateFrom, dateTo))
    ) {
      stats.indCached += 1;
      indDone += 1;
      await phase(
        'indicator',
        `Индикаторы ${secName || secId}: ${indDone}/${indicatorIds.length}`,
        0.6 + 0.35 * (indDone / indTotal)
      );
      continue;
    }
    try {
      await pool.query(
        'CALL sync_security_indicator_series_for_indicator($1, $2, $3, $4, $5, $6)',
        [secId, indicatorId, tfId, endDt, pointCount, false]
      );
      stats.indSynced += 1;
    } catch (e) {
      stats.indErr += 1;
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.indicator.error',
        e.message,
        { security_id: secId, indicator_id: indicatorId, name: secName },
        secId,
        tfId
      );
    }
    indDone += 1;
    await phase(
      'indicator',
      `Индикаторы ${secName || secId}: ${indDone}/${indicatorIds.length}`,
      0.6 + 0.35 * (indDone / indTotal)
    );
  }

  // (2b) Синк индикаторов на дополнительных timeframe (например H2) —
  // их требуют сигналы вида @LINREG(tf=H2,...), цены уже могли быть резэмплены.
  for (const extraTfId of extraTfIds) {
    for (const indicatorId of indicatorIds) {
      if (
        !pricesReloaded &&
        (await indicatorsCached(pool, secId, extraTfId, indicatorId, dateFrom, dateTo))
      ) {
        stats.indCached += 1;
        continue;
      }
      try {
        await pool.query(
          'CALL sync_security_indicator_series_for_indicator($1, $2, $3, $4, $5, $6)',
          [secId, indicatorId, extraTfId, endDt, pointCount, false]
        );
        stats.indSynced += 1;
      } catch (e) {
        stats.indErr += 1;
        await backtestLog(
          pool,
          runId,
          logicId,
          'backtest.indicator.error',
          e.message,
          { security_id: secId, indicator_id: indicatorId, name: secName, timeframe_id: extraTfId },
          secId,
          extraTfId
        );
      }
    }
    await phase('indicator_xtf', `Индикаторы tf ${extraTfId}: ${secName || secId}`, 0.99);
  }

  // Индикаторы на base_asset / contango (eval security ≠ trade security)
  try {
    const { rows: evalRows } = await pool.query(
      `
      SELECT DISTINCT
        lis.indicator_id,
        logic_signal_resolve_eval_security(lis.signal_acts_on, $2) AS eval_sec_id,
        COALESCE(lis.signal_acts_on, 'security') AS acts_on
      FROM logic_indicator_signals lis
      WHERE lis.logic_id = $1
        AND lis.is_active = TRUE
        AND COALESCE(lis.signal_acts_on, 'security') IN ('base_asset', 'contango')
      `,
      [logicId, secId]
    );
    for (const er of evalRows) {
      const evalSecId = Number(er.eval_sec_id);
      if (!Number.isInteger(evalSecId) || evalSecId <= 0 || evalSecId === Number(secId)) {
        continue;
      }
      try {
        await pool.query('CALL ensure_security_indicator_series($1, $2)', [
          evalSecId,
          er.indicator_id,
        ]);
        await pool.query('CALL logic_apply_indicator_params_from_signals($1, $2)', [
          logicId,
          evalSecId,
        ]);
        await pool.query(
          'CALL sync_security_indicator_series_for_indicator($1, $2, $3, $4, $5, $6)',
          [evalSecId, er.indicator_id, tfId, endDt, pointCount, false]
        );
        stats.indSynced += 1;
        await phase(
          'indicator_eval',
          `Индикаторы ${er.acts_on}: ${secName || secId} → sec ${evalSecId}`,
          0.95
        );
      } catch (e) {
        stats.indErr += 1;
        await backtestLog(
          pool,
          runId,
          logicId,
          'backtest.indicator.error',
          e.message,
          {
            security_id: evalSecId,
            trade_security_id: secId,
            indicator_id: er.indicator_id,
            role: er.acts_on,
          },
          secId,
          tfId
        );
      }
    }
  } catch (evalErr) {
    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.indicator.eval_error',
      evalErr?.message || String(evalErr),
      { security_id: secId, name: secName },
      secId,
      tfId
    );
  }

  await phase('paper_done', `Готово: ${secName || secId}`, 1);
}

/**
 * Читает актуальный список бумаг из logic_securities и подготавливает данные.
 * При изменении состава — логирует и подхватывает новые бумаги.
 */
async function syncActiveSecurities(
  pool,
  runId,
  logicId,
  tfId,
  loadDateFrom,
  dateFrom,
  dateTo,
  endDt,
  pointCount,
  knownIds,
  stats,
  phaseLabel,
  reportProgress = null
) {
  const secRows = await fetchActiveSecurityIds(pool, logicId);
  const currentIds = secRows.map((r) => r.security_id);
  const added = currentIds.filter((id) => !knownIds.has(id));
  const removed = [...knownIds].filter((id) => !currentIds.includes(id));

  if (added.length > 0 || removed.length > 0) {
    await backtestLog(pool, runId, logicId, 'backtest.config_changed', phaseLabel, {
      securities_active: currentIds,
      added,
      removed,
    });
  }

  // Начальная загрузка — все бумаги; на барах — только новые (added).
  const isInitialLoad = knownIds.size === 0;
  const rowsToPrepare = isInitialLoad
    ? secRows
    : secRows.filter((r) => added.includes(r.security_id));

  if (rowsToPrepare.length > 0) {
    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.prices.parallel',
      `Подготовка: ${rowsToPrepare.length} бумаг, concurrency=${BACKTEST_PRICE_CONCURRENCY} (prices single-flight)`,
      {
        securities: rowsToPrepare.length,
        concurrency: BACKTEST_PRICE_CONCURRENCY,
        price_single_flight: true,
        phase: phaseLabel,
      }
    );
  }

  let completed = 0;
  let cancelled = false;
  const inFlight = new Map();
  /** Доля внутри текущей бумаги 0..1 (пока грузится). */
  const paperFrac = new Map();
  const PREP_SPAN = 38; // 0..38% на подготовку цен/индикаторов

  const progressDetail = () => {
    const total = Math.max(1, secRows.length);
    // Одна активная строка целиком (с куском дат) — иначе tip «Natural Gas» без периода.
    const active = [...inFlight.values()].filter(Boolean);
    const activePart = active.length
      ? ` · ${active.length > 1 ? `[${active.length}] ` : ''}${active[0]}`
      : '';
    return `Подготовка ${completed}/${total}${activePart}`;
  };

  const bumpPrepProgress = async (force = false) => {
    if (!isInitialLoad || !reportProgress || secRows.length === 0) return;
    let sum = completed;
    for (const f of paperFrac.values()) {
      sum += Math.min(0.99, Number(f) || 0);
    }
    const pct = Math.min(
      PREP_SPAN,
      Math.round((sum / secRows.length) * PREP_SPAN * 100) / 100
    );
    await reportProgress(
      {
        status: 'loading_prices',
        progress_pct: pct,
        phase_message: 'Загрузка цен и индикаторов',
        phase_detail: progressDetail(),
      },
      { force }
    );
  };

  await mapPool(rowsToPrepare, BACKTEST_PRICE_CONCURRENCY, async (row) => {
    if (cancelled) return;
    if (await isCancelRequested(pool, runId)) {
      cancelled = true;
      return;
    }

    const { security_id: secId, name: secName } = row;
    const label = secName || String(secId);
    inFlight.set(secId, label);
    paperFrac.set(secId, 0.05);
    await bumpPrepProgress();

    try {
      await ensureSecurityData(
        pool,
        runId,
        logicId,
        secId,
        secName,
        tfId,
        loadDateFrom,
        dateFrom,
        dateTo,
        endDt,
        pointCount,
        stats,
        async ({ detail, frac }) => {
          paperFrac.set(secId, Math.max(0.05, Math.min(0.99, Number(frac) || 0.05)));
          if (detail) {
            // Полный detail (бумага + окно дат куска), не только имя.
            inFlight.set(secId, String(detail));
          }
          await bumpPrepProgress();
        }
      );
    } catch (e) {
      stats.pricesErr += 1;
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.prices.error',
        e.message,
        { security_id: secId, name: secName },
        secId,
        tfId
      );
    } finally {
      inFlight.delete(secId);
      paperFrac.delete(secId);
      completed += 1;
    }

    await bumpPrepProgress(true);
  });

  knownIds.clear();
  for (const id of currentIds) knownIds.add(id);
  return secRows.length;
}

/**
 * @param {object} [options]
 * @param {boolean} [options.resume] — continue same run_id after API restart (no wipe)
 */
async function runBacktestAsync(pool, logicId, dateFrom, dateTo, runId, options = {}) {
  const resume = Boolean(options.resume);
  const runKey = Number(runId);
  if (!Number.isFinite(runKey) || runKey <= 0) return;
  if (activeBacktestRuns.has(runKey)) {
    console.warn(`backtest run ${runKey} already active in this process — skip`);
    return;
  }
  activeBacktestRuns.add(runKey);

  const knownSecIds = new Set();
  const stats = {
    pricesLoaded: 0,
    pricesCached: 0,
    pricesShared: 0,
    pricesErr: 0,
    pricesResampled: 0,
    indSynced: 0,
    indCached: 0,
    indErr: 0,
  };
  const reportProgress = createProgressReporter(pool, runId, 180);
  /** Bar index to start from (0-based); resume uses persisted processed_bars. */
  let startBarIndex = 0;

  try {
    if (!(await ensureTbankForBacktest(pool, runId, logicId))) {
      return;
    }

    const { rows: logicRows } = await pool.query(
      `SELECT l.id, l.account_id FROM logics l WHERE l.id = $1`,
      [logicId]
    );
    if (logicRows.length === 0) {
      await updateRun(pool, runId, {
        status: 'failed',
        error_message: 'Логика не найдена',
        progress_pct: 100,
        finished_at: new Date(),
      });
      return;
    }
    const logic = logicRows[0];

    const { rows: tfRows } = await pool.query(
      `SELECT logic_resolve_timeframe_id($1) AS tf_id`,
      [logicId]
    );
    const tfId = tfRows[0]?.tf_id;
    if (!tfId) {
      await backtestLog(pool, runId, logicId, 'backtest.failed', 'Не задан timeframe', null, null, null);
      await updateRun(pool, runId, {
        status: 'failed',
        error_message: 'Не задан timeframe',
        progress_pct: 100,
        finished_at: new Date(),
      });
      return;
    }

    // Empty/0 initial_balance must not become cash=0 (no opens). Default 1_000_000.
    // Отдельный test_initial_balance (если задан) — старт теста; иначе live-state initial_balance.
    const { rows: balRows } = await pool.query(
      `SELECT COALESCE(
         NULLIF(get_logic_param_numeric($1, 'test_initial_balance', NULL), 0),
         NULLIF(get_logic_param_numeric($1, 'initial_balance', NULL), 0),
         1000000
       )::float8 AS bal`,
      [logicId]
    );
    let balance = Number(balRows[0]?.bal ?? 1000000);
    if (!Number.isFinite(balance) || balance <= 0) {
      balance = 1000000;
    }

    if (resume) {
      const { rows: runState } = await pool.query(
        `
        SELECT test_balance::float8 AS test_balance,
               COALESCE(processed_bars, 0)::int AS processed_bars,
               COALESCE(trades_created, 0)::int AS trades_created,
               status, cancel_requested
        FROM logic_backtest_runs
        WHERE id = $1
        `,
        [runId]
      );
      if (runState.length === 0) {
        return;
      }
      if (runState[0].cancel_requested) {
        return;
      }
      if (
        !['pending', 'loading_prices', 'loading_indicators', 'running'].includes(
          runState[0].status
        )
      ) {
        return;
      }
      const resumedBal = Number(runState[0].test_balance);
      const resumedTrades = Number(runState[0].trades_created) || 0;
      // Do not resume a dead cash=0 run (empty initial_balance bug) if no trades yet.
      if (
        Number.isFinite(resumedBal) &&
        (resumedBal > 0 || resumedTrades > 0)
      ) {
        balance = resumedBal;
      }
      startBarIndex = Math.max(0, Number(runState[0].processed_bars) || 0);
      const seeded = await fetchActiveSecurityIds(pool, logicId);
      for (const row of seeded) knownSecIds.add(Number(row.security_id));
    } else {
      await pool.query('DELETE FROM logic_trades WHERE logic_id = $1 AND is_test = TRUE', [logicId]);
      await pool.query('DELETE FROM logic_backtest_security_state WHERE run_id = $1', [runId]);
      await pool.query('SELECT logic_backtest_reset_signal_ratings($1)', [logicId]);
    }

    const { rows: tfMetaRows } = await pool.query(
      `SELECT t.sec AS tf_sec, t.tf AS tf_name FROM timeframes t WHERE t.id = $1`,
      [tfId]
    );
    const tfSec = Number(tfMetaRows[0]?.tf_sec ?? 900);
    const tfName = tfMetaRows[0]?.tf_name ?? '?';

    // Период прогона как выбрал пользователь; HTTP/кэш — не дальше сегодня.
    const loadDateTo = clampDateToToday(dateTo);
    const loadDateFrom = shiftDate(dateFrom, -30);
    const endDt = `${loadDateTo} 23:59:59`;
    const daysSpan =
      Math.ceil((Date.parse(loadDateTo) - Date.parse(loadDateFrom)) / 86400000) + 1;
    const pointCount = Math.max(500, Math.ceil(daysSpan * (86400 / tfSec)) + 200);

    if (resume) {
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.resume',
        `Возобновление после перезапуска API с бара ${startBarIndex} (${dateFrom} — ${dateTo})`,
        {
          date_from: dateFrom,
          date_to: dateTo,
          resume_from_bar: startBarIndex,
          test_balance: balance,
          price_concurrency: BACKTEST_PRICE_CONCURRENCY,
        }
      );
      await updateRun(pool, runId, {
        status: startBarIndex > 0 ? 'running' : 'loading_prices',
        phase_message:
          startBarIndex > 0
            ? 'Возобновление прогона'
            : 'Возобновление: подготовка данных',
        phase_detail:
          startBarIndex > 0
            ? `С бара ${startBarIndex}, баланс ${balance}`
            : `Чтение бумаг (×${BACKTEST_PRICE_CONCURRENCY})`,
        test_balance: balance,
        finished_at: null,
        error_message: null,
      });
    } else {
      await backtestLog(pool, runId, logicId, 'backtest.start', `Старт ${dateFrom} — ${dateTo}`, {
        date_from: dateFrom,
        date_to: dateTo,
        load_date_to: loadDateTo,
        load_date_from: loadDateFrom,
        price_concurrency: BACKTEST_PRICE_CONCURRENCY,
      });

      await updateRun(pool, runId, {
        status: 'loading_prices',
        progress_pct: 0,
        phase_message: 'Подготовка данных',
        phase_detail: `Чтение бумаг (×${BACKTEST_PRICE_CONCURRENCY})`,
        test_balance: balance,
      });
    }

    /** Mid-run resume: data already loaded — skip HTTP prep and multi-second COUNTs. */
    const fastResume = resume && startBarIndex > 0;
    let secTotal = knownSecIds.size;

    if (fastResume) {
      const seeded = await fetchActiveSecurityIds(pool, logicId);
      knownSecIds.clear();
      for (const row of seeded) knownSecIds.add(Number(row.security_id));
      secTotal = knownSecIds.size;
      if (secTotal === 0) {
        await updateRun(pool, runId, {
          status: 'failed',
          error_message: 'Нет активных бумаг в логике',
          progress_pct: 100,
          finished_at: new Date(),
        });
        return;
      }
      if (!(await hasPricesInPeriod(pool, logicId, tfId, dateFrom, dateTo))) {
        await updateRun(pool, runId, {
          status: 'failed',
          progress_pct: 100,
          phase_message: 'Нет свечей',
          error_message: 'При возобновлении нет цен в периоде',
          finished_at: new Date(),
        });
        return;
      }
      if (!(await hasIndicatorsInPeriod(pool, logicId, tfId, dateFrom, dateTo))) {
        await updateRun(pool, runId, {
          status: 'failed',
          progress_pct: 100,
          phase_message: 'Нет индикаторов',
          error_message: 'При возобновлении нет индикаторов в периоде',
          finished_at: new Date(),
        });
        return;
      }
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.resume.fast',
        `Быстрое возобновление: бумаг=${secTotal}, с бара ${startBarIndex}`,
        { securities: secTotal, resume_from_bar: startBarIndex },
        null,
        tfId
      );
    } else {
      secTotal = await syncActiveSecurities(
        pool,
        runId,
        logicId,
        tfId,
        loadDateFrom,
        dateFrom,
        loadDateTo,
        endDt,
        pointCount,
        knownSecIds,
        stats,
        'Стартовый состав бумаг',
        reportProgress
      );

      if (await isCancelRequested(pool, runId)) {
        await finishCancelled(pool, runId, logicId, balance, 0, 0);
        return;
      }

      if (secTotal === 0) {
        await updateRun(pool, runId, {
          status: 'failed',
          error_message: 'Нет активных бумаг в логике',
          progress_pct: 100,
          finished_at: new Date(),
        });
        return;
      }

      // Цены денежного фонда (TMON/…) — отдельно: фонд исключён из syncActiveSecurities сигналов.
      try {
        const { rows: fundCodeRows } = await pool.query(
          `SELECT upper(btrim(COALESCE(get_logic_param_text($1, 'cash_fund_code'), ''))) AS code`,
          [logicId]
        );
        const fundCode = String(fundCodeRows[0]?.code ?? '');
        if (fundCode && ['TMON', 'LQDT', 'SBMM'].includes(fundCode)) {
          await pool.query(`SELECT logic_ensure_cash_fund_security($1, $2)`, [logicId, fundCode]);
          const { rows: fundSecRows } = await pool.query(
            `
          SELECT s.id AS security_id
          FROM securities s
          JOIN security_prefixes sp ON sp.security_id = s.id
          WHERE upper(sp.prefix) = $1
          ORDER BY sp.exchange_id
          LIMIT 1
          `,
            [fundCode]
          );
          const fundSecId = fundSecRows[0]?.security_id;
          if (fundSecId) {
            knownSecIds.add(Number(fundSecId));
            // 4 аргумента — 5-й pointCount ломал load_prices_http на части сборок.
            const fundPrice = await ensureFundPricesReady(
              pool,
              fundSecId,
              tfId,
              loadDateFrom,
              loadDateTo
            );
            if (fundPrice.status === 'error') {
              throw fundPrice.error || new Error('cash fund load_prices_http failed');
            }
            await backtestLog(
              pool,
              runId,
              logicId,
              fundPrice.waited ? 'backtest.cash_fund.prices_shared' : 'backtest.cash_fund.prices',
              fundPrice.waited
                ? `Цены фонда ${fundCode} из shared load`
                : `Цены фонда ${fundCode} загружены`,
              { fund: fundCode, security_id: fundSecId, waited: fundPrice.waited },
              fundSecId,
              tfId
            );
          }
        }
      } catch (fundErr) {
        console.warn('backtest cash fund price prep', fundErr?.message || fundErr);
        await backtestLog(
          pool,
          runId,
          logicId,
          'backtest.cash_fund.prices_fail',
          String(fundErr?.message || fundErr).slice(0, 400),
          null,
          null,
          tfId
        );
      }

      const indicatorIdsFresh = await fetchActiveIndicatorIds(pool, logicId);
      if (indicatorIdsFresh.length === 0) {
        await updateRun(pool, runId, {
          status: 'failed',
          error_message: 'Нет активных сигналов в логике',
          progress_pct: 100,
          finished_at: new Date(),
        });
        return;
      }

      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.config',
        `TF=${tfName} бумаг=${secTotal} сигналов=${indicatorIdsFresh.length}`,
        {
          tf_id: tfId,
          tf_name: tfName,
          load_date_from: loadDateFrom,
          point_count: pointCount,
          securities: secTotal,
          indicators: indicatorIdsFresh.length,
          initial_balance: balance,
          prices_loaded: stats.pricesLoaded,
          prices_cached: stats.pricesCached,
        },
        null,
        tfId
      );

      const pricesInPeriod = await countPricesInPeriod(pool, logicId, tfId, dateFrom, dateTo);
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.prices.done',
        `Цены: load=${stats.pricesLoaded} cache=${stats.pricesCached} shared=${stats.pricesShared} err=${stats.pricesErr} в периоде=${pricesInPeriod}`,
        {
          prices_loaded: stats.pricesLoaded,
          prices_cached: stats.pricesCached,
          prices_shared: stats.pricesShared,
          prices_err: stats.pricesErr,
          prices_in_period: pricesInPeriod,
        },
        null,
        tfId
      );

      // #1024: сбои источников цен при подготовке бэктеста — в «Мониторинг
      // системы» (app_error_log), чтобы «Нет свечей» не выглядело молчаливым.
      if (stats.pricesErr > 0) {
        const errLog = await fetchPriceLoadLog(pool, logicId, tfId, dateFrom, dateTo);
        for (const pl of errLog) {
          if (!pl.error_message) continue;
          await writeErrorLog(pool, {
            level: 'warning',
            source: 'backtest',
            category: 'prices',
            code: `price_provider_${String(pl.source || 'unknown').toLowerCase()}`,
            message: `Бэктест: ${pl.source || 'источник'} не отдал цены (security=${pl.security_id}): ${String(pl.error_message).slice(0, 300)}`,
            detail: pl.error_message,
            logicId,
            securityId: pl.security_id,
            context: { source: pl.source, timeframe_id: tfId, run_id: runId },
          });
        }
      }

      // #1047: подробная ошибка в «Мониторинг системы», если по активным бумагам
      // цен в периоде нет вообще или данные начинаются позже запрошенной даты.
      try {
        const { rows: coverRows } = await pool.query(
          `
          SELECT
            s.id AS security_id,
            s.name,
            sp.prefix,
            (SELECT count(*) FROM prices p
              WHERE p.security_id = s.id AND p.timeframe_id = $2
                AND p.dt >= $3::date AND p.dt < ($4::date + 1)) AS bars,
            (SELECT min(p.dt) FROM prices p
              WHERE p.security_id = s.id AND p.timeframe_id = $2
                AND p.dt >= $3::date AND p.dt < ($4::date + 1)) AS first_dt,
            (SELECT max(p.dt) FROM prices p
              WHERE p.security_id = s.id AND p.timeframe_id = $2
                AND p.dt < ($4::date + 1)) AS last_dt
          FROM logic_securities ls
          JOIN securities s ON s.id = ls.security_id
          LEFT JOIN security_prefixes sp
            ON sp.security_id = s.id AND sp.exchange_id = 1
          WHERE ls.logic_id = $1 AND COALESCE(ls.is_active, TRUE)
          `,
          [logicId, tfId, dateFrom, dateTo]
        );
        const missing = coverRows.filter((r) => Number(r.bars) === 0);
        stats.priceMissingCount = missing.length;
        let firstBar = null;
        for (const r of coverRows) {
          if (r.first_dt && (!firstBar || r.first_dt < firstBar)) firstBar = r.first_dt;
        }
        if (missing.length > 0) {
          const loadRows = await fetchPriceLoadLog(pool, logicId, tfId, dateFrom, dateTo);
          for (const r of missing) {
            const secLoad = loadRows.filter(
              (x) => Number(x.security_id) === Number(r.security_id)
            );
            const srcErr = secLoad
              .filter((x) => x.error_message)
              .map((x) => `${x.source || 'источник'}: ${x.error_message}`)
              .join('; ');
            await writeErrorLog(pool, {
              level: 'error',
              source: 'backtest',
              category: 'prices',
              code: 'price_missing_instrument',
              message:
                `Бэктест: нет цен по бумаге ${r.prefix || r.name} ` +
                `(id=${r.security_id}) за ${dateFrom}…${dateTo} (TF ${tfName}) — ` +
                'ни один сервис не отдал цену',
              detail:
                srcErr ||
                `Нет ни одной свечи. Последняя цена до периода: ${
                  r.last_dt ? localIsoDate(new Date(r.last_dt)) : '—'
                }`,
              logicId,
              securityId: r.security_id,
              context: {
                run_id: runId,
                timeframe: tfName,
                prefix: r.prefix,
                name: r.name,
                date_from: dateFrom,
                date_to: dateTo,
                last_dt: r.last_dt,
              },
            });
          }
          await backtestLog(
            pool,
            runId,
            logicId,
            'backtest.prices.missing',
            `Нет цен по ${missing.length} бумагам из ${coverRows.length}`,
            {
              missing: missing.map((r) => ({
                security_id: r.security_id,
                prefix: r.prefix,
                name: r.name,
                last_dt: r.last_dt,
              })),
              date_from: dateFrom,
              date_to: dateTo,
            },
            null,
            tfId
          );
        }
        if (firstBar) {
          const actualFrom = localIsoDate(new Date(firstBar));
          if (actualFrom > dateFrom) {
            stats.priceLateFrom = actualFrom;
            await writeErrorLog(pool, {
              level: 'error',
              source: 'backtest',
              category: 'prices',
              code: 'price_period_start_late',
              message:
                `Бэктест: цены начинаются позже запрошенной даты — ` +
                `запрошено с ${dateFrom}, данные с ${actualFrom} (TF ${tfName})`,
              detail:
                `Фактический первый бар: ${actualFrom}. Период до ${actualFrom} ` +
                'не тестировался — источники не отдали более раннюю историю.',
              logicId,
              context: {
                run_id: runId,
                timeframe: tfName,
                requested_from: dateFrom,
                actual_from: actualFrom,
                date_to: dateTo,
              },
            });
          }
        }
      } catch (_covErr) {
        /* диагностика цен не должна ломать прогон */
      }

      if (pricesInPeriod === 0) {
        const priceLog = await fetchPriceLoadLog(pool, logicId, tfId, dateFrom, dateTo);
        await backtestLog(
          pool,
          runId,
          logicId,
          'backtest.failed',
          'Нет свечей в периоде',
          { prices_in_period: 0, price_load_log: priceLog },
          null,
          tfId
        );
        await updateRun(pool, runId, {
          status: 'failed',
          progress_pct: 100,
          phase_message: 'Нет свечей',
          error_message: `Не загружены цены (ошибок: ${stats.pricesErr}). Задайте токен T-Bank для M15.`,
          finished_at: new Date(),
        });
        return;
      }

      let indInPeriod = await countIndicatorsInPeriod(pool, logicId, tfId, dateFrom, dateTo);
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.indicators.done',
        `Индикаторы: sync=${stats.indSynced} cache=${stats.indCached} err=${stats.indErr} в периоде=${indInPeriod}`,
        {
          indicator_values_in_period: indInPeriod,
          sync_errors: stats.indErr,
          ind_synced: stats.indSynced,
          ind_cached: stats.indCached,
        },
        null,
        tfId
      );

      // #1055: даже когда в периоде есть значения у части бумаг, по конкретным
      // бумагам/сериям их может не быть — досинхронизируем точечно, иначе
      // сигналы по ним молчат и прогон даёт 0 сделок.
      const missingSeries = await syncMissingIndicatorSeriesForLogic(
        pool,
        runId,
        logicId,
        tfId,
        dateFrom,
        dateTo,
        endDt,
        pointCount
      );
      if (missingSeries.synced > 0) {
        indInPeriod = await countIndicatorsInPeriod(
          pool,
          logicId,
          tfId,
          dateFrom,
          dateTo
        );
      }

      // Кэш подтвердил наличие индикаторов, но в периоде 0 значений: значения могла
      // удалить автоочистка indicator_values между проверкой кэша и подсчётом (гонка).
      // Форсируем пересчёт, а не падаем сразу.
      if (indInPeriod === 0 && stats.indCached > 0) {
        const forced = await forceSyncIndicatorsForLogic(
          pool,
          runId,
          logicId,
          tfId,
          endDt,
          pointCount
        );
        indInPeriod = await countIndicatorsInPeriod(pool, logicId, tfId, dateFrom, dateTo);
        await backtestLog(
          pool,
          runId,
          logicId,
          'backtest.indicators.forced',
          `Форс-пересчёт индикаторов: sync=${forced.synced} err=${forced.errors} в периоде=${indInPeriod}`,
          {
            forced_synced: forced.synced,
            forced_errors: forced.errors,
            indicator_values_in_period: indInPeriod,
          },
          null,
          tfId
        );
      }

      if (indInPeriod === 0) {
        await updateRun(pool, runId, {
          status: 'failed',
          progress_pct: 100,
          phase_message: 'Нет индикаторов',
          error_message: 'Индикаторы не рассчитаны. См. backtest.indicator.error.',
          finished_at: new Date(),
        });
        return;
      }

      await reportProgress(
        {
          status: 'loading_indicators',
          progress_pct: 39,
          phase_message: 'Подготовка прогона',
          phase_detail: `Бумаг ${secTotal}, сигналов ${indicatorIdsFresh.length}`,
        },
        { force: true }
      );
    }

    const { rows: barRows } = await pool.query(
      `
      SELECT DISTINCT p.dt AS bar_dt
      FROM prices p
      JOIN logic_securities ls ON ls.security_id = p.security_id
      WHERE ls.logic_id = $1 AND ls.is_active = TRUE
        AND p.timeframe_id = $2
        AND p.dt::date BETWEEN $3 AND $4
      ORDER BY p.dt
      `,
      [logicId, tfId, dateFrom, dateTo]
    );
    const bars = barRows.map((r) => r.bar_dt);
    const totalBars = bars.length;
    const resumeBi = resume
      ? Math.min(Math.max(0, startBarIndex), totalBars)
      : 0;

    if (totalBars === 0) {
      await updateRun(pool, runId, {
        status: 'failed',
        progress_pct: 100,
        phase_message: 'Нет свечей',
        error_message: 'Нет цен в выбранном периоде',
        finished_at: new Date(),
      });
      return;
    }

    if (resume && resumeBi >= totalBars) {
      const pnl = await sumTestPnl(pool, logicId, runId);
      const { rows: tcFinal } = await pool.query(
        `SELECT trades_created FROM logic_backtest_runs WHERE id = $1`,
        [runId]
      );
      const tradesCreated = tcFinal[0]?.trades_created ?? 0;
      await backtestLog(
        pool,
        runId,
        logicId,
        'backtest.complete',
        `Возобновление: уже завершён (${totalBars} баров)`,
        { resumed: true, trades_created: tradesCreated, financial_result: pnl },
        null,
        tfId
      );
      await updateRun(pool, runId, {
        status: 'completed',
        progress_pct: 100,
        phase_message: tradesCreated > 0 ? 'Тестирование завершено' : 'Тест завершён — сделок нет',
        phase_detail: `${totalBars} баров, ${knownSecIds.size} бумаг, сделок: ${tradesCreated}` +
        (stats.priceLateFrom ? `, данные с ${stats.priceLateFrom}` : '') +
        (stats.priceMissingCount ? `, без цен: ${stats.priceMissingCount}` : ''),
        processed_bars: totalBars,
        test_balance: balance,
        financial_result: pnl,
        finished_at: new Date(),
      });
      return;
    }

    const startPct =
      resume && resumeBi > 0
        ? Math.round((40 + (resumeBi / totalBars) * 59.5) * 100) / 100
        : 40;
    await updateRun(pool, runId, {
      total_bars: totalBars,
      ...(resume && resumeBi > 0 ? {} : { processed_bars: 0 }),
      status: 'running',
      progress_pct: Math.min(99.5, startPct),
      phase_message: resume && resumeBi > 0 ? 'Прогон по свечам (продолжение)' : 'Прогон по свечам',
      phase_detail:
        resume && resumeBi > 0
          ? `${resumeBi} / ${totalBars} баров (продолжение)`
          : `0 / ${totalBars} баров`,
      finished_at: null,
    });

    for (let bi = resumeBi; bi < bars.length; bi += 1) {
      // Cancel: every 5 bars (was every bar — extra RTT).
      if (bi % 5 === 0 && (await isCancelRequested(pool, runId))) {
        await finishCancelled(pool, runId, logicId, balance, bi, totalBars);
        return;
      }

      // Rare re-sync of paper list (was every 20 bars).
      if (bi > 0 && bi % 100 === 0) {
        await syncActiveSecurities(
          pool,
          runId,
          logicId,
          tfId,
          loadDateFrom,
          dateFrom,
          loadDateTo,
          endDt,
          pointCount,
          knownSecIds,
          stats,
          `Обновление на баре ${bi + 1}/${totalBars}`,
          null
        );
        if (await isCancelRequested(pool, runId)) {
          await finishCancelled(pool, runId, logicId, balance, bi, totalBars);
          return;
        }
      }

      const barDt = bars[bi];
      const prevBar = bi > 0 ? bars[bi - 1] : null;
      const nextBar = bi + 1 < bars.length ? bars[bi + 1] : null;

      // One SQL round-trip: rate → risk → EOD → signals → park.
      const { rows: barRowsOut } = await pool.query(
        `SELECT logic_backtest_process_bar($1, $2, $3, $4, $5::timestamp, $6::timestamp, $7::timestamp, $8::numeric) AS balance`,
        [runId, logicId, logic.account_id, tfId, barDt, prevBar, nextBar, balance]
      );
      balance = Number(barRowsOut[0]?.balance ?? balance);

      const isLast = bi === bars.length - 1;
      const pct =
        Math.round((40 + ((bi + 1) / totalBars) * 59.5) * 100) / 100;
      const patch = {
        progress_pct: Math.min(99.5, pct),
        phase_message: 'Прогон по свечам',
        phase_detail: `${bi + 1} / ${totalBars} баров, бумаг ${knownSecIds.size}`,
        current_bar_dt: barDt,
        processed_bars: bi + 1,
        test_balance: balance,
      };
      // Full trade SUM is expensive as trades grow — every 25 bars is enough for UI.
      if (isLast || bi % 25 === 0) {
        patch.financial_result = await sumTestPnl(pool, logicId, runId);
      }
      await reportProgress(patch, { force: isLast });

      if (bi > 0 && bi % 200 === 0) {
        const { rows: tcRows } = await pool.query(
          `SELECT trades_created FROM logic_backtest_runs WHERE id = $1`,
          [runId]
        );
        await backtestLog(
          pool,
          runId,
          logicId,
          'backtest.progress',
          `Бар ${bi + 1}/${totalBars}, сделок=${tcRows[0]?.trades_created ?? 0}`,
          { processed_bars: bi + 1, total_bars: totalBars, securities: knownSecIds.size },
          null,
          tfId
        );
      }

      // Rare archive snapshot — never awaited; skipped if previous persist still running.
      if (bi > 0 && bi % 500 === 0) {
        schedulePersistBacktestReport(pool, runId, { isSnapshot: true });
      }
    }

    // #1040: equity считается по снимкам logic_backtest_equity_points с переоценкой
    // открытых позиций на каждом баре. #1061: при включённой галочке (default TRUE)
    // последним актом теста становится ликвидация всех позиций (как в #1039).
    const { rows: closeOptRows } = await pool.query(
      `SELECT COALESCE(close_all_at_end, TRUE) AS close_all_at_end
       FROM logic_backtest_runs WHERE id = $1`,
      [runId]
    );
    if (closeOptRows[0]?.close_all_at_end !== false && bars.length > 0) {
      const { rows: liqRows } = await pool.query(
        `SELECT logic_backtest_close_all_except_funds($1, $2, $3, $4, $5::timestamp, $6::numeric) AS balance`,
        [runId, logicId, logic.account_id, tfId, bars[bars.length - 1], balance]
      );
      const closedBalance = Number(liqRows[0]?.balance);
      if (Number.isFinite(closedBalance)) balance = closedBalance;
    }
    let pnl = await sumTestPnl(pool, logicId, runId);
    const { rows: eqRows } = await pool.query(
      `
      SELECT
        (SELECT equity::float8 FROM logic_backtest_equity_points
          WHERE run_id = $1 ORDER BY dt DESC LIMIT 1) AS last_equity,
        COALESCE((
          SELECT param_value::numeric FROM logic_params
          WHERE logic_id = $2 AND param_key = 'test_initial_balance'
        ), 1000000)::float8 AS initial_equity
      `,
      [runId, logicId]
    );
    const lastEquity = Number(eqRows[0]?.last_equity);
    const initialEquity = Number(eqRows[0]?.initial_equity);
    if (Number.isFinite(lastEquity) && Number.isFinite(initialEquity)) {
      pnl = lastEquity - initialEquity;
    }
    const { rows: diagRows } = await pool.query(
      `SELECT logic_backtest_diagnose($1, $2, $3, $4, $5) AS d`,
      [runId, logicId, tfId, dateFrom, dateTo]
    );
    const { rows: tcFinal } = await pool.query(
      `SELECT trades_created FROM logic_backtest_runs WHERE id = $1`,
      [runId]
    );
    const tradesCreated = tcFinal[0]?.trades_created ?? 0;
    const diag = diagRows[0]?.d ?? {};

    await backtestLog(
      pool,
      runId,
      logicId,
      'backtest.complete',
      tradesCreated > 0
        ? `Завершено: ${tradesCreated} сделок, PnL=${pnl.toFixed(2)}`
        : `Завершено без сделок (баров=${totalBars}, бумаг=${knownSecIds.size})`,
      {
        ...diag,
        trades_created: tradesCreated,
        financial_result: pnl,
        total_bars: totalBars,
        prices_loaded: stats.pricesLoaded,
        prices_cached: stats.pricesCached,
      },
      null,
      tfId
    );

    try {
      await pool.query(`SELECT logic_opt_grid_finalize($1)`, [runId]);
    } catch (err) {
      console.warn('logic_opt_grid_finalize', err?.message || err);
    }

    await updateRun(pool, runId, {
      status: 'completed',
      progress_pct: 100,
      phase_message: tradesCreated > 0 ? 'Тестирование завершено' : 'Тест завершён — сделок нет',
      phase_detail: `${totalBars} баров, ${knownSecIds.size} бумаг, сделок: ${tradesCreated}` +
        (stats.priceLateFrom ? `, данные с ${stats.priceLateFrom}` : '') +
        (stats.priceMissingCount ? `, без цен: ${stats.priceMissingCount}` : ''),
      processed_bars: totalBars,
      test_balance: balance,
      financial_result: pnl,
      finished_at: new Date(),
    });
  } catch (err) {
    const msg = err?.message || String(err);
    await backtestLog(pool, runId, logicId, 'backtest.failed', msg, {
      stack: err?.stack,
      resumed: resume,
    });
    await updateRun(pool, runId, {
      status: 'failed',
      error_message: resume ? `Возобновление: ${msg}` : msg,
      progress_pct: 100,
      finished_at: new Date(),
    });
    } finally {
    // Promote в тесте переписывает формулы — вернуть стартовый снимок OPT.
    try {
      await pool.query(`SELECT logic_opt_restore_formulas_from_run($1)`, [runId]);
    } catch (err) {
      console.warn('logic_opt_restore_formulas_from_run', err?.message || err);
    }
    activeBacktestRuns.delete(runKey);
    // Обрезка ненужных indicator_values (сироты + старые), без удаления чужих тестов.
    // Не блокируем завершение прогона: fire-and-forget. Запускаем только когда больше
    // нет активных прогонов: очистка удаляет старые indicator_values и может «съесть»
    // окно ещё идущего/стартующего теста (гонка → «Нет индикаторов»).
    if (activeBacktestRuns.size === 0) {
      pool
        .query('SELECT cleanup_unused_indicator_values() AS result')
        .then((res) => {
          const r = res.rows?.[0]?.result;
          if (r && r.skipped) {
            console.log('cleanup_unused_indicator_values skipped', r.reason || r);
          } else if (r) {
            console.log(
              'cleanup_unused_indicator_values',
              `orphans=${r.orphans_deleted ?? 0} aged=${r.aged_deleted ?? 0}`
            );
          }
        })
        .catch((err) => {
          console.warn('cleanup_unused_indicator_values', err?.message || err);
        });
    }
  }
}

/**
 * After API/process restart: pick up DB rows still marked in-progress and continue
 * the same run_id from processed_bars (no trade wipe).
 */
async function resumeOrphanBacktests(pool) {
  const { rows } = await pool.query(
    `
    SELECT id, logic_id,
      date_from::text AS date_from,
      date_to::text AS date_to,
      status,
      COALESCE(processed_bars, 0)::int AS processed_bars
    FROM logic_backtest_runs
    WHERE status IN ('pending', 'loading_prices', 'loading_indicators', 'running')
      AND cancel_requested = FALSE
    ORDER BY id
    `
  );
  let scheduled = 0;
  for (const row of rows) {
    const runId = Number(row.id);
    const logicId = Number(row.logic_id);
    if (!Number.isFinite(runId) || !Number.isFinite(logicId)) continue;
    if (activeBacktestRuns.has(runId)) continue;
    scheduled += 1;
    console.log(
      `backtest resume orphan run=${runId} logic=${logicId} status=${row.status} bars=${row.processed_bars}`
    );
    setImmediate(() => {
      runBacktestAsync(pool, logicId, row.date_from, row.date_to, runId, {
        resume: true,
      }).catch((err) => {
        console.error(`backtest resume run ${runId} failed`, err);
        writeErrorLog(pool, {
          level: 'error',
          source: 'backtest',
          category: 'run',
          code: 'BACKTEST_RESUME',
          message: `Возобновление бэктеста run=${runId} (логика ${logicId}) не удалось: ${err?.message || err}`,
          detail: err?.stack || err?.message || String(err),
          logicId,
        });
      });
    });
  }
  return { found: rows.length, scheduled };
}

/** Сумма финреза теста — как /logic-trades/pnl-summary (без shadow, только run). */
async function sumTestPnl(pool, logicId, runId = null) {
  const params = [logicId];
  let runFilter = '';
  if (runId != null && Number(runId) > 0) {
    params.push(Number(runId));
    runFilter = ` AND lt.run_id = $${params.length}`;
  }
  const { rows } = await pool.query(
    `
    SELECT COALESCE(SUM(lt.financial_result), 0)::float8 AS pnl
    FROM logic_trades lt
    WHERE lt.logic_id = $1
      AND lt.is_test = TRUE
      AND COALESCE(lt.is_shadow, FALSE) = FALSE
      AND COALESCE(lt.opt_lane, '') = ''
      AND lt.status IN ('filled', 'submitted')
      ${runFilter}
    `,
    params
  );
  return Number(rows[0]?.pnl ?? 0);
}

async function finishCancelled(pool, runId, logicId, balance, processed, total) {
  // Ничего не удаляем: сделки/рейтинги теста остаются как есть
  const pnl = await sumTestPnl(pool, logicId, runId);
  const { rows } = await pool.query(
    `SELECT status, processed_bars, total_bars FROM logic_backtest_runs WHERE id = $1`,
    [runId]
  );
  const already = rows[0]?.status === 'cancelled';
  const proc = processed ?? rows[0]?.processed_bars ?? 0;
  const tot = total ?? rows[0]?.total_bars ?? 0;
  if (!already) {
    await backtestLog(pool, runId, logicId, 'backtest.cancelled', `Отменено на ${proc}/${tot}`, {
      processed: proc,
      total: tot,
      financial_result: pnl,
    });
  }
  await pool.query(
    `
    UPDATE logic_backtest_runs
    SET cancel_requested = TRUE,
        status = 'cancelled',
        phase_message = 'Отменено',
        phase_detail = $2,
        test_balance = COALESCE($3::numeric, test_balance),
        financial_result = $4,
        processed_bars = GREATEST(COALESCE(processed_bars, 0), $5::int),
        finished_at = COALESCE(finished_at, CURRENT_TIMESTAMP)
    WHERE id = $1
    `,
    [
      runId,
      tot > 0 ? `${proc} / ${tot} баров (сохранено)` : 'Остановлено, результат сохранён',
      balance,
      pnl,
      proc,
    ]
  );
  schedulePersistBacktestReport(pool, runId, { isSnapshot: false });
}

async function startBacktest(
  pool, logicId, dateFrom, dateTo, optGrid = null, slippagePct = 0, closeAllAtEnd = true
) {
  const arms =
    optGrid && Array.isArray(optGrid.arms) && optGrid.arms.length > 0
      ? optGrid.arms.map((a) => ({
          lane: String(a.lane || ''),
          values: a.values && typeof a.values === 'object' ? a.values : {},
        }))
      : null;
  const config = optGrid && optGrid.config != null ? optGrid.config : null;

  if (arms && arms.length > 81) {
    throw new Error(
      `Слишком много комбинаций оптимизации (${arms.length}). Лимит 81: снимите галочки или уменьшите итерации.`
    );
  }

  const { rows } = await pool.query(
    `
    INSERT INTO logic_backtest_runs (
      logic_id, date_from, date_to, status, progress_pct, phase_message, started_at,
      slippage_pct, close_all_at_end,
      opt_grid_config, opt_grid_arms
    )
    VALUES (
      $1, $2, $3, 'pending', 0,
      CASE WHEN $4::jsonb IS NOT NULL THEN 'Старт (тест + оптимизация)' ELSE 'Старт' END,
      CURRENT_TIMESTAMP,
      $6::numeric,
      $7::boolean,
      $5::jsonb,
      $4::jsonb
    )
    RETURNING id
    `,
    [
      logicId,
      dateFrom,
      dateTo,
      arms ? JSON.stringify(arms) : null,
      config ? JSON.stringify(config) : null,
      slippagePct ?? 0,
      closeAllAtEnd !== false,
    ]
  );
  const runId = rows[0].id;
  // Снимок параметров формул/OPT на старте (отчёт + restore после promote в тесте).
  try {
    await pool.query(`SELECT logic_opt_snapshot_params($1, $2, NULL)`, [
      logicId,
      runId,
    ]);
  } catch (err) {
    console.warn('logic_opt_snapshot_params', err?.message || err);
  }
  setImmediate(() => {
    runBacktestAsync(pool, logicId, dateFrom, dateTo, runId).catch((err) => {
      console.error('backtest run failed', err);
      writeErrorLog(pool, {
        level: 'error',
        source: 'backtest',
        category: 'run',
        code: 'BACKTEST_RUN',
        message: `Бэктест run=${runId} (логика ${logicId}) не удался: ${err?.message || err}`,
        detail: err?.stack || err?.message || String(err),
        logicId,
      });
    });
  });
  return runId;
}

async function getBacktestStatus(pool, logicId, runId) {
  const params = [logicId];
  let sql = `
    SELECT id, logic_id,
      date_from::text AS date_from,
      date_to::text AS date_to,
      status,
      progress_pct::float8 AS progress_pct,
      phase_message, phase_detail, current_bar_dt,
      total_bars, processed_bars, trades_created,
      test_balance::float8 AS test_balance,
      financial_result::float8 AS financial_result,
      cancel_requested, error_message, started_at, finished_at, created_at,
      slippage_pct::float8 AS slippage_pct,
      close_all_at_end,
      (opt_grid_arms IS NOT NULL AND jsonb_typeof(opt_grid_arms) = 'array'
        AND jsonb_array_length(opt_grid_arms) > 0) AS opt_grid_enabled,
      opt_grid_results
    FROM logic_backtest_runs
    WHERE logic_id = $1
  `;
  if (runId) {
    sql += ' AND id = $2';
    params.push(runId);
  }
  sql += ' ORDER BY id DESC LIMIT 1';
  const { rows } = await pool.query(sql, params);
  return rows[0] ?? null;
}

async function cancelBacktest(pool, runId) {
  const { rows } = await pool.query(
    `
    SELECT id, logic_id, status, processed_bars, total_bars, test_balance
    FROM logic_backtest_runs
    WHERE id = $1
    `,
    [runId]
  );
  if (rows.length === 0) return false;
  const run = rows[0];
  if (!['pending', 'loading_prices', 'loading_indicators', 'running'].includes(run.status)) {
    return run.status === 'cancelled';
  }

  // Сразу status=cancelled — UI не висит на «Останавливаю…».
  // Фоновый воркер добьёт текущий SQL и выйдет; данные теста не трогаем.
  const pnl = await sumTestPnl(pool, run.logic_id, runId);
  const proc = Number(run.processed_bars ?? 0);
  const tot = Number(run.total_bars ?? 0);
  const { rowCount } = await pool.query(
    `
    UPDATE logic_backtest_runs
    SET cancel_requested = TRUE,
        status = 'cancelled',
        phase_message = 'Отменено',
        phase_detail = CASE
          WHEN $3::int > 0 THEN $2::text || ' / ' || $3::text || ' баров (сохранено)'
          ELSE COALESCE(phase_detail, 'Остановлено, результат сохранён')
        END,
        financial_result = $4,
        finished_at = COALESCE(finished_at, CURRENT_TIMESTAMP)
    WHERE id = $1
      AND status IN ('pending', 'loading_prices', 'loading_indicators', 'running')
    `,
    [runId, proc, tot, pnl]
  );

  try {
    await backtestLog(
      pool,
      runId,
      run.logic_id,
      'backtest.cancel_requested',
      `Стоп пользователем на ${proc}/${tot}`,
      { processed: proc, total: tot, financial_result: pnl }
    );
  } catch (_e) {
    /* ignore */
  }

  if (rowCount > 0) {
    // Rank OPT grid even on stop — so «Применить лучшие OPT» still works.
    try {
      await pool.query(`SELECT logic_opt_grid_finalize($1)`, [runId]);
    } catch (err) {
      console.warn('logic_opt_grid_finalize (cancel)', err?.message || err);
    }
    schedulePersistBacktestReport(pool, runId, { isSnapshot: false });
  }

  return rowCount > 0;
}

module.exports = {
  startBacktest,
  getBacktestStatus,
  cancelBacktest,
  resumeOrphanBacktests,
};

function shiftDate(isoDate, days) {
  const d = new Date(`${isoDate}T12:00:00`);
  d.setDate(d.getDate() + days);
  return localIsoDate(d);
}

/** YYYY-MM-DD по локальному календарю (без UTC-сдвига). */
function localIsoDate(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/** load_prices / кэш: не запрашивать будущие дни у T-Bank. */
function clampDateToToday(isoDate) {
  const today = localIsoDate();
  return isoDate > today ? today : isoDate;
}
