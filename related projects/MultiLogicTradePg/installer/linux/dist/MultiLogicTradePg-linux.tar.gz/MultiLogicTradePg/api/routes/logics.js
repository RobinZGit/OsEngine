/**
 * Logics CRUD, params, export/import, OPT, shadow, signals, stops, securities, NTP.
 */
const { writeErrorLog } = require('../lib/error-log');

module.exports = function registerLogicsRoutes(app, ctx) {
  const {
    pool,
    hashToken,
    startBacktest,
    getBacktestStatus,
    cancelBacktest,
    resolveLastOptGridResults,
    listBacktestReports,
    getBacktestReport,
    getBacktestReportNeighbors,
    persistBacktestReport,
    startRatingPrecalc,
    getRatingPrecalcStatus,
    runTradeCycle,
    touchUiHeartbeatDb,
    clearUiHeartbeatDb,
    isUiSessionActive,
    validateOptFormulaSave,
    getTradingParams,
    getTradingParamsForLogics,
    saveTradingParams,
    ensureDefaultParams,
    getLogicParamsDetailed,
    syncRealAccountBalancesIfNeeded,
    resetLogicTradingStateOnAccountChange,
    resetLogicShadowTradingState,
    buildLogicBundle,
    importLogicBundle,
    writeTechLogEvent,
    assertRealTbankAccount,
    sellAllPositions,
    planBuyBonds,
    executeBuyBonds,
    listBondFunds,
    getAccountCash,
    isScopeValidForRuleKind,
    isScopeChoosableForRuleKind,
    localIsoDate,
    shiftLocalDate,
    logicNeedsWarmup,
    watchWarmupBacktest,
    rewriteFormulaBasesNode,
    parseTimeHm,
    fetchNonTradingIntervals,
    btrimStr,
    formatColumn,
    formatConstraint,
    formatRoutine,
    parseLogicTradingParams,
    parseLogicBody,
    parseId,
    parseDateString,
    parseBrokerBody,
    parseExchangeBody,
    parseIndicatorBody,
    parseIndicatorCreateBody,
    runIndicatorSyncBackground,
    fetchIndicatorById,
    parseSecurityBody,
    parseAccountBody,
    fillRealTbankAccountFromToken,
    tokenFieldsFromParsed,
    buildTokenUpdateClause,
    stripAccountSecrets,
    enrichAccountBalance,
    resolveAccountConnection,
    handleDbError,
  } = ctx;

/** Короткая формальная запись сигнала: '@CODE(params) EXPR' → 'CMO(14)<0', 'STOCH(K,14)<50' и т.п.
 * Индикаторы — своими латинскими аббревиатурами (код из indicators.code), серии латинскими буквами. */
const SIGNAL_SERIES_ABBR = {
  K: 'K',
  D: 'D',
  UPPER: 'U',
  LOWER: 'L',
  MIDDLE: 'M',
};
function shortSignalToken(s) {
  const formula = String(s.formula || '');
  const code = s.indicator_code || (formula.match(/^@([A-Za-z0-9_]+)/i) || [])[1] || '';
  const series = (formula.match(/series=([A-Za-z0-9_]+)/i) || [])[1] || 'VALUE';
  const num = (formula.match(/(?:\b|_)period=(\d+)/i) || [])[1];
  let label = code;
  const sUp = series.toUpperCase();
  if (sUp !== 'VALUE') {
    const slet = SIGNAL_SERIES_ABBR[sUp] || series;
    label = num ? `${code}(${slet},${num})` : `${code}(${slet})`;
  } else if (num) {
    label = `${code}(${num})`;
  }
  let expr = formula;
  const close = formula.lastIndexOf(')');
  if (close >= 0) expr = formula.slice(close + 1);
  expr = expr
    .replace(/\bVALUE\b/g, label)
    .replace(/\bpp\b/g, 'Цена')
    .replace(/\s*([<>=]+)\s*/g, '$1')
    .replace(/\s+/g, ' ')
    .trim();
  return expr || label;
}

/**
 * Короткая формальная запись включённых сигналов логики (active only, из БД).
 * Группируется по стороне и событию: «Л: вх …∧…, вых …∧… | Ш: вх …, вых …».
 */
function buildSignalSummary(rows) {
  const groups = {
    long: { open: [], close: [] },
    short: { open: [], close: [] },
  };
  for (const s of rows) {
    const side = Object.prototype.hasOwnProperty.call(groups, s.position_side)
      ? s.position_side
      : 'long';
    const ev = s.position_event === 'close' ? 'close' : 'open';
    groups[side][ev].push(shortSignalToken(s));
  }
  const parts = [];
  for (const [side, label] of [['long', 'Л'], ['short', 'Ш']]) {
    const g = groups[side];
    if (g.open.length === 0 && g.close.length === 0) continue;
    const seg = [];
    if (g.open.length > 0) seg.push(`вх ${g.open.join('∧')}`);
    if (g.close.length > 0) seg.push(`вых ${g.close.join('∧')}`);
    parts.push(`${label}: ${seg.join(', ')}`);
  }
  return parts.join(' | ');
}

app.get('/api/logics', async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        l.id,
        l.name,
        l.account_id,
        l.is_enabled,
        COALESCE(l.use_as_terminal_signal, FALSE) AS use_as_terminal_signal,
        l.note,
        COALESCE(l.portfolio_trading_paused, FALSE) AS portfolio_trading_paused,
        l.portfolio_stop_resume_equity::float8 AS portfolio_stop_resume_equity,
        l.portfolio_stop_resume_baseline::float8 AS portfolio_stop_resume_baseline,
        l.portfolio_stop_resume_at AS portfolio_stop_resume_at,
        EXISTS (
          SELECT 1
          FROM logic_stops ls
          WHERE ls.logic_id = l.id
            AND ls.is_active = TRUE
            AND ls.rule_kind = 'take_profit'
            AND ls.scope_type IN ('portfolio_ltp_renew', 'security_ltp_renew')
        ) AS has_portfolio_ltp_renew,
        EXISTS (
          SELECT 1
          FROM logic_stops ls
          WHERE ls.logic_id = l.id
            AND ls.is_active = TRUE
            AND ls.rule_kind = 'stop_loss'
            AND ls.scope_type = 'portfolio_resume'
        ) AS has_portfolio_resume_sl,
        a.account_code,
        a.name AS account_name,
        a.account_type,
        a.broker_id,
        a.is_active AS account_is_active,
        b.code AS broker_code,
        b.name AS broker_name,
        (
          SELECT MAX(r.created_at)
          FROM logic_backtest_runs r
          WHERE r.logic_id = l.id
        ) AS last_test_at
      FROM logics l
      JOIN accounts a ON a.id = l.account_id
      JOIN brokers b ON b.id = a.broker_id
      ORDER BY l.id
    `);
    // Без T-Bank на каждый poll: остатки из logic_params (бой/enable/смена счёта обновляют сами).
    const paramsByLogic = await getTradingParamsForLogics(
      pool,
      rows.map((r) => r.id)
    );
    const result = rows.map((r) => ({
      ...r,
      ...(paramsByLogic.get(r.id) || {}),
    }));
    // Короткая формальная запись ВКЛЮЧЁННЫХ (is_active) сигналов логики — всегда по фактическому
    // состоянию БД: при сохранении логики/сигналов пересчитывается при следующей загрузке списка.
    if (result.length > 0) {
      const { rows: sigRows } = await pool.query(
        `
        SELECT lis.logic_id, lis.position_event, lis.position_side,
               i.code AS indicator_code, lis.formula
        FROM logic_indicator_signals lis
        JOIN indicators i ON i.id = lis.indicator_id
        WHERE lis.is_active = TRUE
        ORDER BY lis.logic_id, lis.display_order, lis.id
        `
      );
      const byLogic = new Map();
      for (const s of sigRows) {
        if (!byLogic.has(s.logic_id)) byLogic.set(s.logic_id, []);
        byLogic.get(s.logic_id).push(s);
      }
      for (const r of result) {
        r.signals_summary = buildSignalSummary(byLogic.get(r.id) || []);
      }
    }
    res.json(result);
  } catch (err) {
    console.error('GET /api/logics', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/logic-params', async (req, res) => {
  const logicId = Number(req.query.logic_id);
  if (!Number.isInteger(logicId) || logicId <= 0) {
    res.status(400).json({ error: 'logic_id required' });
    return;
  }
  try {
    const rows = await getLogicParamsDetailed(pool, logicId);
    const trading = await getTradingParams(pool, logicId);
    res.json({ logic_id: logicId, trading, params: rows });
  } catch (err) {
    console.error('GET /api/logic-params', err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/logic-params', async (req, res) => {
  const logicId = Number(req.body?.logic_id);
  if (!Number.isInteger(logicId) || logicId <= 0) {
    res.status(400).json({ error: 'logic_id required' });
    return;
  }
  const parsed = parseLogicTradingParams(req.body);
  if (parsed.error) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  try {
    const { rows: exists } = await pool.query(
      'SELECT id FROM logics WHERE id = $1',
      [logicId]
    );
    if (exists.length === 0) {
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    const trading = await saveTradingParams(pool, logicId, parsed);
    const params = await getLogicParamsDetailed(pool, logicId);
    await writeTechLogEvent(pool, {
      threadKey: `logic:${logicId}:params`,
      operation: 'logic.params.updated',
      message: 'Параметры логики сохранены',
      source: 'api',
      logicId,
      payload: { trading, params },
    });
    res.json({ logic_id: logicId, trading, params });
  } catch (err) {
    console.error('PUT /api/logic-params', err);
    res.status(500).json({ error: err.message });
  }
});
app.post('/api/logics', async (req, res) => {
  const parsed = parseLogicBody(req.body);
  if (parsed.error) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  try {
    const { rows } = await pool.query(
      `
      INSERT INTO logics (name, account_id, is_enabled, use_as_terminal_signal, note)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, name, account_id, is_enabled, use_as_terminal_signal, note
      `,
      [
        parsed.name,
        parsed.account_id,
        parsed.is_enabled,
        parsed.use_as_terminal_signal ?? false,
        parsed.note,
      ]
    );
    const row = rows[0];
    await ensureDefaultParams(pool, row.id);
    await syncRealAccountBalancesIfNeeded(pool, row.id, { force: true });
    const params = await getTradingParams(pool, row.id);
    res.status(201).json({ ...row, ...params });
  } catch (err) {
    console.error('POST /api/logics', err);
    if (err.code === '23505') {
      res.status(409).json({ error: 'Логика с таким именем уже существует' });
      return;
    }
    if (err.code === '23503') {
      res.status(400).json({ error: 'Указан несуществующий счёт' });
      return;
    }
    res.status(500).json({ error: err.message });
  }
});

/** Экспорт выбранных логик: params/signals/stops/securities; без тестов и сделок. */
app.post('/api/logics/export', async (req, res) => {
  const ids = Array.isArray(req.body?.ids) ? req.body.ids : [];
  try {
    const bundle = await buildLogicBundle(pool, ids);
    res.json(bundle);
  } catch (err) {
    console.error('POST /api/logics/export', err);
    res.status(err.status || 500).json({ error: err.message });
  }
});

/**
 * Импорт bundle: по имени — перезапись; иначе новая логика.
 * Тесты/сделки не импортируются; last_opt_grid из файла восстанавливается.
 * Body: bundle JSON; optional overwrite_by_name (default true).
 */
app.post('/api/logics/import', async (req, res) => {
  try {
    const overwriteByName = req.body?.overwrite_by_name !== false;
    const bundle = { ...req.body };
    delete bundle.overwrite_by_name;
    const result = await importLogicBundle(pool, bundle, { overwriteByName });
    res.status(201).json(result);
  } catch (err) {
    console.error('POST /api/logics/import', err);
    const detail = [];
    detail.push(`Код: ${err.code || 'N/A'}`);
    detail.push(`Сообщение: ${err.message || 'N/A'}`);
    if (err.detail) detail.push(`DETAIL: ${err.detail}`);
    if (err.hint) detail.push(`HINT: ${err.hint}`);
    if (err.constraint) detail.push(`CONSTRAINT: ${err.constraint}`);
    if (err.table) detail.push(`TABLE: ${err.table}`);
    if (err.column) detail.push(`COLUMN: ${err.column}`);
    if (err.schema) detail.push(`SCHEMA: ${err.schema}`);
    if (err.position) detail.push(`POSITION: ${err.position}`);
    if (err.where) detail.push(`WHERE: ${err.where}`);
    if (err.file) detail.push(`FILE: ${err.file}`);
    if (err.line) detail.push(`LINE: ${err.line}`);
    if (err.routine) detail.push(`ROUTINE: ${err.routine}`);
    if (err.stack) detail.push(`STACK: ${err.stack}`);
    const protocol =
      typeof err.protocol === 'string' && err.protocol
        ? err.protocol
        : [
            '=== ПРОТОКОЛ ИМПОРТА ЛОГИК ===',
            `Время: ${new Date().toISOString()}`,
            `URL: POST /api/logics/import`,
            '',
            ...detail,
            '',
            '=== КОНЕЦ ПРОТОКОЛА ===',
          ].join('\n');
    const errors = Array.isArray(err.importErrors)
      ? err.importErrors
      : [err.message || 'Ошибка импорта'];
    res.status(err.status || 500).json({ error: err.message, protocol, errors, detail: err });
  }
});

app.post('/api/logics/:id/copy', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: sourceRows } = await client.query(
      `
      SELECT id, name, account_id, note,
             last_opt_grid_results, last_opt_grid_run_id, last_opt_grid_at
      FROM logics WHERE id = $1
      `,
      [id]
    );
    if (sourceRows.length === 0) {
      await client.query('ROLLBACK');
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    const source = sourceRows[0];

    // Имя копии: из запроса (пользователь задаёт в диалоге), иначе «… copy».
    const requestedName =
      typeof req.body?.name === 'string' ? req.body.name.trim() : '';
    let copyName;
    if (requestedName) {
      copyName = requestedName;
    } else {
      const baseName = `${source.name} copy`;
      copyName = baseName;
      for (let i = 2; i <= 100; i += 1) {
        const { rows: existing } = await client.query(
          'SELECT 1 FROM logics WHERE name = $1 LIMIT 1',
          [copyName]
        );
        if (existing.length === 0) break;
        copyName = `${baseName} ${i}`;
      }
    }

    // Примечание: из запроса (можно очистить), иначе — как у источника.
    const copyNote =
      req.body?.note === undefined ? source.note : req.body.note;

    // use_as_terminal_signal намеренно НЕ копируется — копия стартует без
    // подачи сигналов в терминал; пользователь включает вручную.
    const { rows: inserted } = await client.query(
      `
      INSERT INTO logics (name, account_id, is_enabled, use_as_terminal_signal, note)
      VALUES ($1, $2, FALSE, FALSE, $3)
      RETURNING id, name, account_id, is_enabled, use_as_terminal_signal, note
      `,
      [copyName, source.account_id, copyNote]
    );
    const copy = inserted[0];

    // Сохранённая OPT-сетка («Применить лучшие OPT») — настройка, копируем.
    // Runtime-состояние (portfolio_trading_paused, equity peak, stop-resume/linear-tp)
    // намеренно НЕ копируется — копия стартует «чистой» и выключенной.
    await client.query(
      `
      UPDATE logics SET
        last_opt_grid_results = $2,
        last_opt_grid_run_id  = $3,
        last_opt_grid_at      = $4
      WHERE id = $1
      `,
      [
        copy.id,
        source.last_opt_grid_results ?? null,
        source.last_opt_grid_run_id ?? null,
        source.last_opt_grid_at ?? null,
      ]
    );

    await client.query(
      `
      INSERT INTO logic_params (logic_id, param_key, param_value, value_type)
      SELECT $1, param_key, param_value, value_type
      FROM logic_params
      WHERE logic_id = $2
        AND param_key NOT IN (
          'current_balance',
          'last_cash_fund_bar_dt',
          'last_opt_eval_bar_dt',
          'last_stop_bar_dt',
          'last_trade_bar_dt',
          'last_trade_check_at',
          'terminal_signal_last_bar_dt',
          'last_opt_grid_run_id',
          'last_opt_grid_at'
        )
      ON CONFLICT (logic_id, param_key) DO UPDATE SET
        param_value = EXCLUDED.param_value,
        value_type = EXCLUDED.value_type,
        updated_at = CURRENT_TIMESTAMP
      `,
      [copy.id, id]
    );

    // #1048: current_balance — runtime-состояние, не копируем из шаблона:
    // иначе новая логика с initial_balance=10000 торгует как с миллионом.
    await client.query(
      `
      INSERT INTO logic_params (logic_id, param_key, param_value, value_type)
      SELECT $1, 'current_balance', param_value, value_type
      FROM logic_params
      WHERE logic_id = $2 AND param_key = 'initial_balance'
      ON CONFLICT (logic_id, param_key) DO UPDATE SET
        param_value = EXCLUDED.param_value,
        value_type = EXCLUDED.value_type,
        updated_at = CURRENT_TIMESTAMP
      `,
      [copy.id, id]
    );

    await client.query(
      `
      INSERT INTO logic_indicator_signals (
        logic_id, indicator_id, position_event, position_side, signal_kind,
        signal_acts_on, formula, rating, rating_test, display_order, is_active
      )
      SELECT
        $1, indicator_id, position_event, position_side, signal_kind,
        signal_acts_on, formula, 0, 0, display_order, is_active
      FROM logic_indicator_signals
      WHERE logic_id = $2
      ORDER BY display_order, id
      `,
      [copy.id, id]
    );

    await client.query(
      `
      INSERT INTO logic_stops (
        logic_id, rule_kind, scope_type, value, value_unit,
        inversion_value, display_order, is_active
      )
      SELECT $1, rule_kind, scope_type, value, value_unit,
             inversion_value, display_order, is_active
      FROM logic_stops
      WHERE logic_id = $2
      ORDER BY display_order, id
      `,
      [copy.id, id]
    );

    // Бумаги + настройки боя по бумаге (пауза/инверсия).
    // stop_resume_* / linear_tp_* — runtime-состояние стопов, не копируем.
    await client.query(
      `
      INSERT INTO logic_securities (
        logic_id, security_id, display_order, is_active,
        real_trading_paused, real_trading_paused_long, real_trading_paused_short,
        real_trading_inverted
      )
      SELECT $1, security_id, display_order, is_active,
             real_trading_paused, real_trading_paused_long, real_trading_paused_short,
             real_trading_inverted
      FROM logic_securities
      WHERE logic_id = $2
      ORDER BY display_order, id
      ON CONFLICT (logic_id, security_id) DO NOTHING
      `,
      [copy.id, id]
    );

    await client.query(
      `
      INSERT INTO logic_non_trading_intervals (
        logic_id, day_of_week, time_from, time_to, note, display_order, is_active
      )
      SELECT $1, day_of_week, time_from, time_to, note, display_order, is_active
      FROM logic_non_trading_intervals
      WHERE logic_id = $2
      ORDER BY display_order, id
      `,
      [copy.id, id]
    );

    await client.query('COMMIT');
    // Копия с real-счёта не должна унаследовать paper 1M — остаток с брокера или 0
    await syncRealAccountBalancesIfNeeded(pool, copy.id, { force: true });
    const { rows: fullRows } = await pool.query(
      `
      SELECT
        l.id,
        l.name,
        l.account_id,
        l.is_enabled,
        COALESCE(l.use_as_terminal_signal, FALSE) AS use_as_terminal_signal,
        l.note,
        a.account_code,
        a.name AS account_name,
        a.account_type,
        a.broker_id,
        a.is_active AS account_is_active,
        b.code AS broker_code,
        b.name AS broker_name
      FROM logics l
      JOIN accounts a ON a.id = l.account_id
      JOIN brokers b ON b.id = a.broker_id
      WHERE l.id = $1
      `,
      [copy.id]
    );
    const params = await getTradingParams(pool, copy.id);
    res.status(201).json({ ...(fullRows[0] ?? copy), ...params });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('POST /api/logics/:id/copy', err);
    if (err.code === '23505') {
      res.status(409).json({ error: 'Логика с таким именем уже существует' });
      return;
    }
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
});

app.put('/api/logics/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  const parsed = parseLogicBody(req.body);
  if (parsed.error) {
    res.status(400).json({ error: parsed.error });
    return;
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const existing = await client.query(
      'SELECT id, name, account_id, is_enabled FROM logics WHERE id = $1',
      [id]
    );
    if (existing.rows.length === 0) {
      await client.query('ROLLBACK');
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    const prevAccountId = Number(existing.rows[0].account_id);
    const accountChanged = prevAccountId !== Number(parsed.account_id);
    const hasSignalFlag = parsed.use_as_terminal_signal !== undefined;
    const setClause = hasSignalFlag
      ? 'SET name = $1, account_id = $2, is_enabled = $3, use_as_terminal_signal = $4, note = $5'
      : 'SET name = $1, account_id = $2, is_enabled = $3, note = $4';
    const returningClause = hasSignalFlag
      ? 'RETURNING id, name, account_id, is_enabled, use_as_terminal_signal, note'
      : 'RETURNING id, name, account_id, is_enabled, note';
    const updateParams = hasSignalFlag
      ? [
          parsed.name,
          parsed.account_id,
          parsed.is_enabled,
          parsed.use_as_terminal_signal,
          parsed.note,
          id,
        ]
      : [parsed.name, parsed.account_id, parsed.is_enabled, parsed.note, id];
    const { rows } = await client.query(
      `
      UPDATE logics
      ${setClause}
      WHERE id = $${updateParams.length}
      ${returningClause}
      `,
      updateParams
    );

    let account_change = null;
    if (accountChanged) {
      // Боевая история/FINRES + pause state; остатки под новый счёт.
      const cleared = await resetLogicTradingStateOnAccountChange(client, id);
      account_change = {
        from_account_id: prevAccountId,
        to_account_id: Number(parsed.account_id),
        cleared_trades: cleared.cleared_trades,
      };
      await writeTechLogEvent(client, {
        threadKey: `logic:${id}:control`,
        operation: 'logic.account_changed',
        message: 'Счёт логики изменён: история сделок и FINRES очищены',
        source: 'api',
        logicId: id,
        payload: account_change,
      });
    }

    await client.query('COMMIT');
    if (!accountChanged) {
      // Смена на real / уже real — initial/current только с брокера (или 0)
      await syncRealAccountBalancesIfNeeded(pool, id, { force: true });
    }

    let rating_precalc = null;
    // Как «выкл → вкл»: при активной логике после смены счёта — предрасчёт рейтинга.
    if (accountChanged && rows[0].is_enabled) {
      rating_precalc = await startRatingPrecalc(pool, id);
    }

    res.json({
      ...rows[0],
      account_changed: accountChanged,
      account_change,
      rating_precalc,
    });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('PUT /api/logics/:id', err);
    if (err.code === '23505') {
      res.status(409).json({ error: 'Логика с таким именем уже существует' });
      return;
    }
    if (err.code === '23503') {
      res.status(400).json({ error: 'Указан несуществующий счёт' });
      return;
    }
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
});

app.delete('/api/logics/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const existing = await client.query(
      'SELECT id, name FROM logics WHERE id = $1',
      [id]
    );
    if (existing.rows.length === 0) {
      await client.query('ROLLBACK');
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    // logic_trades.logic_id historically RESTRICT — remove trades/lots before logic.
    await client.query('DELETE FROM logic_trade_lots WHERE logic_id = $1', [id]);
    await client.query('DELETE FROM logic_trades WHERE logic_id = $1', [id]);
    await client.query('DELETE FROM logics WHERE id = $1', [id]);
    await client.query('COMMIT');
    res.json({ ok: true, id });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('DELETE /api/logics/:id', err);
    res.status(500).json({ error: err.message });
  } finally {
    client.release();
  }
});

app.patch('/api/logics/:id', async (req, res) => {
  const id = Number(req.params.id);
  const { is_enabled, use_as_terminal_signal } = req.body;
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  const hasEnabled = typeof is_enabled === 'boolean';
  const hasSignal = typeof use_as_terminal_signal === 'boolean';
  if (!hasEnabled && !hasSignal) {
    res.status(400).json({ error: 'is_enabled or use_as_terminal_signal must be boolean' });
    return;
  }
  try {
    const { rows: existsRows } = await pool.query(
      `SELECT id FROM logics WHERE id = $1`,
      [id]
    );
    if (existsRows.length === 0) {
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    if (hasSignal && !hasEnabled) {
      const { rows } = await pool.query(
        `UPDATE logics SET use_as_terminal_signal = $1 WHERE id = $2 RETURNING id, use_as_terminal_signal`,
        [use_as_terminal_signal, id]
      );
      await writeTechLogEvent(pool, {
        threadKey: `logic:${id}:control`,
        operation: use_as_terminal_signal
          ? 'logic.terminal_signal.on'
          : 'logic.terminal_signal.off',
        message: use_as_terminal_signal
          ? 'Логика выдаёт сигналы в терминал'
          : 'Логика больше не выдаёт сигналы в терминал',
        source: 'api',
        logicId: id,
        payload: { use_as_terminal_signal },
      });
      res.json({ ...rows[0] });
      return;
    }
    if (is_enabled) {
      const warmup = await logicNeedsWarmup(pool, id);
      if (warmup.enabled) {
        const { rows: activeWarmup } = await pool.query(
          `
          SELECT id, date_from, date_to
          FROM logic_backtest_runs
          WHERE logic_id = $1
            AND status IN ('pending', 'loading_prices', 'loading_indicators', 'running')
          ORDER BY id DESC
          LIMIT 1
          `,
          [id]
        );
        if (activeWarmup.length > 0) {
          const run = activeWarmup[0];
          await pool.query(`UPDATE logics SET is_enabled = FALSE WHERE id = $1`, [id]);
          watchWarmupBacktest(pool, id, run.id);
          res.json({
            id,
            is_enabled: false,
            warmup_pretest: {
              started: true,
              run_id: run.id,
              date_from: run.date_from,
              date_to: run.date_to,
            },
          });
          return;
        }
        const dateTo = localIsoDate();
        const dateFrom = shiftLocalDate(dateTo, -(warmup.lookbackDays - 1));
        const runId = await startBacktest(pool, id, dateFrom, dateTo);
        await pool.query(`UPDATE logics SET is_enabled = FALSE WHERE id = $1`, [id]);
        watchWarmupBacktest(pool, id, runId);
        await writeTechLogEvent(pool, {
          threadKey: `logic:${id}:warmup`,
          operation: 'logic.warmup.started',
          message: `Warm-up backtest started before enabling logic`,
          source: 'api',
          logicId: id,
          payload: { run_id: runId, date_from: dateFrom, date_to: dateTo },
        });
        res.json({
          id,
          is_enabled: false,
          warmup_pretest: {
            started: true,
            run_id: runId,
            date_from: dateFrom,
            date_to: dateTo,
          },
        });
        return;
      }
    }
    const { rows } = await pool.query(
      hasSignal
        ? `UPDATE logics SET is_enabled = $1, use_as_terminal_signal = $3
           WHERE id = $2 RETURNING id, is_enabled, use_as_terminal_signal`
        : `UPDATE logics SET is_enabled = $1 WHERE id = $2 RETURNING id, is_enabled`,
      hasSignal ? [is_enabled, id, use_as_terminal_signal] : [is_enabled, id]
    );
    if (hasSignal) {
      await writeTechLogEvent(pool, {
        threadKey: `logic:${id}:control`,
        operation: use_as_terminal_signal
          ? 'logic.terminal_signal.on'
          : 'logic.terminal_signal.off',
        message: use_as_terminal_signal
          ? 'Логика выдаёт сигналы в терминал'
          : 'Логика больше не выдаёт сигналы в терминал',
        source: 'api',
        logicId: id,
        payload: { use_as_terminal_signal },
      });
    }
    await writeTechLogEvent(pool, {
      threadKey: `logic:${id}:control`,
      operation: is_enabled ? 'logic.enabled' : 'logic.disabled',
      message: is_enabled ? 'Логика включена' : 'Логика выключена',
      source: 'api',
      logicId: id,
      payload: { is_enabled },
    });
    let rating_precalc = null;
    if (is_enabled) {
      // Остатки с брокера — в фоне, не блокируем ответ UI (раньше блокировал poll списка).
      syncRealAccountBalancesIfNeeded(pool, id, { force: true }).catch(() => {});
      // Фон: не ждём; бой уже включён
      rating_precalc = await startRatingPrecalc(pool, id);
    }
    res.json({ ...rows[0], rating_precalc });
  } catch (err) {
    console.error('PATCH /api/logics/:id', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/logics/:id/signal-rating-precalc', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  try {
    const { rows } = await pool.query('SELECT id FROM logics WHERE id = $1', [id]);
    if (rows.length === 0) {
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    const job = await startRatingPrecalc(pool, id);
    res.json(job);
  } catch (err) {
    console.error('POST /api/logics/:id/signal-rating-precalc', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/logics/:id/signal-rating-precalc', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  res.json(getRatingPrecalcStatus(id));
});

/** История баз OPT / параметров формул для отчёта теста. */
app.get('/api/logics/:id/opt-param-history', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  const runRaw = req.query.run_id;
  const runId =
    runRaw != null && String(runRaw).trim() !== ''
      ? Number(runRaw)
      : null;
  try {
    const { rows } = await pool.query(
      `SELECT logic_opt_param_history_for_report($1, $2) AS h`,
      [id, Number.isInteger(runId) && runId > 0 ? runId : null]
    );
    const raw = rows[0]?.h;
    const history = Array.isArray(raw) ? raw : raw ? [raw] : [];
    res.json({ rows: history });
  } catch (err) {
    console.error('GET /api/logics/:id/opt-param-history', err);
    res.status(500).json({ error: err.message });
  }
});

/** Apply best offline-grid params from last OPT (logic cache or recovered run). */
app.post('/api/logics/:id/opt-grid-apply-best', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  try {
    const found = await resolveLastOptGridResults(pool, id);
    if (!found.results || !Array.isArray(found.results) || found.results.length === 0) {
      res.status(400).json({
        error:
          'Нет сохранённых результатов оптимизации. Запустите тест с «Оптимизировать» ещё раз — после этого они останутся до «Параметры по умолчанию» / «Сброс OPT».',
        source: found.source,
      });
      return;
    }
    const results = found.results;
    const runId = found.run_id;
    const best = [...results].sort(
      (a, b) => Number(b.finres || 0) - Number(a.finres || 0)
    )[0];
    if (!best || best.is_champion || !best.values || Object.keys(best.values).length === 0) {
      // Champion won — still allow "apply" as no-op message, or apply champion values (none).
      if (best?.is_champion) {
        res.json({
          ok: true,
          message: 'Лучший результат — параметры по умолчанию (чемпион). Формулы не менялись.',
          run_id: runId,
          best,
          updated: 0,
          source: found.source,
        });
        return;
      }
      res.status(400).json({ error: 'Не удалось выбрать лучшие параметры' });
      return;
    }

    // Snapshot before rewrite so «Сброс» / reset can restore.
    try {
      if (runId) {
        await pool.query(`SELECT logic_opt_snapshot_params($1, $2, NULL)`, [
          id,
          runId,
        ]);
      }
    } catch (err) {
      console.warn('opt-grid-apply snapshot', err?.message || err);
    }

    const { rows: signals } = await pool.query(
      `SELECT id, formula FROM logic_indicator_signals WHERE logic_id = $1 AND is_active = TRUE`,
      [id]
    );

    const values = best.values;
    let updated = 0;
    for (const sig of signals) {
      const next = rewriteFormulaBasesNode(sig.formula, values);
      if (next !== sig.formula) {
        await pool.query(
          `UPDATE logic_indicator_signals SET formula = $1 WHERE id = $2`,
          [next, sig.id]
        );
        updated++;
      }
    }

    const { rows: outSignals } = await pool.query(
      `
      SELECT
        lis.id, lis.logic_id, lis.indicator_id, lis.position_event, lis.position_side,
        lis.signal_kind, COALESCE(lis.signal_acts_on, 'security') AS signal_acts_on,
        lis.formula, lis.rating, lis.rating_test, lis.display_order, lis.is_active,
        i.code AS indicator_code, i.name AS indicator_name
      FROM logic_indicator_signals lis
      JOIN indicators i ON i.id = lis.indicator_id
      WHERE lis.logic_id = $1
      ORDER BY lis.display_order, lis.id
      `,
      [id]
    );

    res.json({
      ok: true,
      run_id: runId,
      best,
      updated,
      signals: outSignals,
      source: found.source,
    });
  } catch (err) {
    console.error('POST /api/logics/:id/opt-grid-apply-best', err);
    res.status(500).json({ error: err.message });
  }
});


app.get('/api/logics/:id/opt-grid-results', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  try {
    const found = await resolveLastOptGridResults(pool, id);
    if (!found.results) {
      res.json({ run_id: null, results: null, source: found.source });
      return;
    }
    res.json({
      run_id: found.run_id,
      results: found.results,
      source: found.source,
    });
  } catch (err) {
    console.error('GET /api/logics/:id/opt-grid-results', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * Очистка теневой истории: live is_shadow сделки, снятие pause/инверсии,
 * все бумаги логики → is_active; при включённой логике — предрасчёт рейтинга.
 */
app.post('/api/logics/:id/shadow-reset', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  try {
    const { rows: exists } = await pool.query(
      `SELECT id, is_enabled FROM logics WHERE id = $1`,
      [id]
    );
    if (exists.length === 0) {
      res.status(404).json({ error: 'Logic not found' });
      return;
    }

    const cleared = await resetLogicShadowTradingState(pool, id);

    let rating_precalc = null;
    if (exists[0].is_enabled) {
      rating_precalc = await startRatingPrecalc(pool, id);
    }

    res.json({
      ok: true,
      ...cleared,
      rating_precalc,
      message:
        'Теневые сделки очищены, бумаги снова включены в логику' +
        (rating_precalc ? '; запущен предрасчёт рейтинга' : ''),
    });
  } catch (err) {
    console.error('POST /api/logics/:id/shadow-reset', err);
    res.status(500).json({ error: err.message });
  }
});

/** Молния (#960): ручная проверка сигналов логики на последнем ЗАКРЫТОМ баре её ТФ (#990).
 *  Совпадает с боевым циклом: догружаются минутные свечи до текущего момента, резэмплятся
 *  в ТФ логики, и применяются настройки (is_enabled → сделка, use_as_terminal_signal →
 *  сигнал в терминал). Дедуп-маркер уже обработанного бара кнопку не блокирует. */
app.post('/api/logics/:id/lightning', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  try {
    const priceLogSince = new Date(Date.now() - 2 * 60 * 1000);
    // #987: цикл уже держит общий advisory-lock — logic_lightning_run вернёт 'busy'.
    // #990: сначала немного ждём и повторяем (цикл может освободить лок), а если лок
    // так и занят — отдаём снимок с последнего закрытого бара вместо ошибки 409.
    let result;
    for (let attempt = 0; attempt < 6; attempt++) {
      const { rows } = await pool.query(
        `SELECT logic_lightning_run($1, LOCALTIMESTAMP, FALSE) AS result`,
        [id]
      );
      result = rows[0]?.result;
      if (result?.ok === true || result?.reason !== 'busy') break;
      await new Promise((r) => setTimeout(r, 2000));
    }
    // #1022: сбои источников цен (T-Bank и/или MOEX) — в «Мониторинг системы»,
    // даже если fallback на второй источник сработал и данные пришли.
    await logLightningPriceErrorsForLogic(pool, id, priceLogSince);
    if (!result || result.ok !== true) {
      if (result?.reason === 'busy') {
        // #990: цикл занят общим локом (M1 держит его минутами на прогреве цен).
        // Вместо ошибки 409 отдаём снимок с последнего ЗАКРЫТОГО бара — то, что уже
        // посчитал цикл, без захвата лока и без записи.
        const snapRes = await pool.query(
          `SELECT logic_lightning_snapshot($1, LOCALTIMESTAMP) AS result`,
          [id]
        );
        const snap = snapRes.rows[0]?.result;
        if (snap && snap.ok === true) {
          res.json(snap);
        } else {
          res.status(400).json(snap ?? { ok: false, reason: 'no_result' });
        }
        return;
      }
      res.status(400).json(result ?? { ok: false, reason: 'no_result' });
      return;
    }
    res.json(result);
  } catch (err) {
    console.error('POST /api/logics/:id/lightning', err);
    res.status(500).json({ error: err.message });
  }
});

const LIGHTNING_LOCK_KEY = 'multilogictrade_run_trade_cycle';

/** #1022: сбои источников цен в «молнии» — в журнал «Мониторинг системы».
 *  price_load_log фиксирует каждый источник отдельно (T-BANK / MOEX), даже если
 *  затем сработал fallback на второй: строка с error_message появляется у
 *  упавшего источника, и её надо показать как предупреждение, а не терять за
 *  успешной загрузкой с резервного. */
async function logLightningPriceErrors(runner, securityIds, since) {
  if (!Array.isArray(securityIds) || securityIds.length === 0) return 0;
  let logged = 0;
  try {
    const { rows } = await runner.query(
      `SELECT security_id, timeframe_id, source, error_message, loaded_at
         FROM price_load_log
        WHERE security_id = ANY($1::int[])
          AND loaded_at >= $2::timestamp
          AND COALESCE(error_message, '') <> ''
        ORDER BY id DESC
        LIMIT 100`,
      [securityIds, since]
    );
    for (const r of rows) {
      const provider = String(r.source || 'unknown');
      await writeErrorLog(pool, {
        level: 'warning',
        source: 'prices',
        category: 'provider',
        code: `price_provider_${provider.toLowerCase()}`,
        message: `Источник цен ${provider} не отдал данные: ${String(r.error_message).slice(0, 300)}`,
        detail: r.error_message,
        securityId: r.security_id,
        context: { provider, timeframe_id: r.timeframe_id, logged_at: r.loaded_at },
      });
      logged += 1;
    }
  } catch (err) {
    console.warn('lightning price-provider log:', err.message);
  }
  return logged;
}

/** #1022: показать в журнале сбои источников по бумагам одной логики. */
async function logLightningPriceErrorsForLogic(runner, logicId, since) {
  try {
    const { rows } = await runner.query(
      `SELECT security_id FROM logic_securities WHERE logic_id = $1 AND is_active = TRUE`,
      [logicId]
    );
    return await logLightningPriceErrors(
      runner,
      rows.map((r) => r.security_id),
      since
    );
  } catch (err) {
    console.warn('lightning price-provider log (logic):', err.message);
    return 0;
  }
}

// #991: состояние последнего запуска «молнии для всех» — чтобы кнопка «Запросить
// сигналы» могла показать результат и причины (почему сигналов не создано).
// Работа выполняется в фоне, клиент опрашивает статус.
let lightningAllJob = null;

/** #987: фоновая часть lightning-all — прогрев цен и прогон logic_lightning_run
 *  на выделенном соединении под общим advisory-lock с боевым циклом
 *  (api/trade-runner.js, run_trade_cycle). Иначе длинные транзакции «молнии» и
 *  цикла вставляют одни и те же свечи `prices` и ловят дедлоки → запрос зависает. */
async function runLightningAllBackground({ ids, secIds, srcId, today }) {
  const client = await pool.connect();
  const job = lightningAllJob;
  let locked = false;
  try {
    for (let i = 0; i < 60 && !locked; i++) {
      const { rows } = await client.query(
        `SELECT pg_try_advisory_lock(hashtext($1)) AS ok`,
        [LIGHTNING_LOCK_KEY]
      );
      locked = rows[0]?.ok === true;
      if (!locked) await new Promise((r) => setTimeout(r, 2000));
    }
    job.locked = locked;
    if (!locked) {
      // #991: лок так и не освободился — не пропускаем молча, а отдаём снимок с
      // диагностикой по каждой логике (боевой цикл занят, свежий бар ещё считается).
      console.warn('lightning-all: боевой цикл занят — отдаю снимок с диагностикой');
      for (const id of ids) {
        try {
          const { rows } = await client.query(
            `SELECT logic_lightning_snapshot($1, LOCALTIMESTAMP) AS result`,
            [id]
          );
          const r = rows[0]?.result ?? { ok: false, reason: 'no_result' };
          job.results.push({ id, ...r });
        } catch (err) {
          job.results.push({ id, ok: false, error: err.message });
        }
      }
      return;
    }

    // Единый прогрев цен: минутки по каждой уникальной бумаге из этих логик.
    // #993: не перекачиваем уже загруженные минутки — если минутная свеча за сегодня
    // уже есть «до сейчас», HTTP пропускаем (logic_lightning_run затем тоже пропустит).
    for (const s of secIds) {
      try {
        const freshRes = await client.query(
          `SELECT EXISTS (
             SELECT 1 FROM prices
             WHERE security_id = $1
               AND timeframe_id = $2
               AND dt::date = $3::date
               AND dt >= (LOCALTIMESTAMP - INTERVAL '2 minutes')
           ) AS fresh`,
          [s, srcId, today]
        );
        if (freshRes.rows[0]?.fresh) continue;
        await client.query(`CALL load_prices_http($1, $2, $3, $4)`, [s, srcId, today, today]);
      } catch (err) {
        console.warn(`lightning-all prices security=${s}:`, err.message);
        // #1022: оба источника недоступны — это ошибка, а не «нет свечей».
        await writeErrorLog(pool, {
          level: 'error',
          source: 'prices',
          category: 'provider',
          code: 'price_provider_unavailable',
          message: `Цены недоступны (security=${s}): ${err.message}`,
          detail: err.message,
          securityId: s,
        });
      }
    }

    // #1022: ошибки отдельных источников, даже когда fallback спас загрузку.
    await logLightningPriceErrors(client, secIds, new Date(job.startedAt));

    for (const id of ids) {
      try {
        const { rows } = await client.query(
          `SELECT logic_lightning_run($1, LOCALTIMESTAMP, FALSE) AS result`,
          [id]
        );
        const r = rows[0]?.result;
        if (r) {
          job.results.push({ id, ...r });
          if (r.ok === true) {
            job.signals += Number(r.terminal_signals_created ?? 0);
            job.trades += Number(r.trade_created ?? 0);
          } else {
            console.warn(`lightning-all logic=${id}:`, r.reason ?? 'no_result');
          }
        } else {
          job.results.push({ id, ok: false, reason: 'no_result' });
        }
      } catch (err) {
        console.error(`lightning-all logic=${id}`, err.message);
        job.results.push({ id, ok: false, error: err.message });
      }
      try {
        await client.query(`CALL touch_trade_runner_last_ok($1)`, ['lightning']);
      } catch (_e) {
        /* ignore */
      }
    }
    console.log(
      `lightning-all done: logics=${ids.length} signals=${job.signals} trades=${job.trades}`
    );
  } finally {
    if (locked) {
      try {
        await client.query(`SELECT pg_advisory_unlock(hashtext($1))`, [LIGHTNING_LOCK_KEY]);
      } catch (_e) {
        /* ignore */
      }
    }
    job.finishedAt = Date.now();
    client.release();
  }
}

/** Молния для всех логик с включённым сигналом в терминал (#970, #987).
 *  Ответ отдаётся сразу (started=true): прогрев цен и прогон logic_lightning_run
 *  выполняются в фоне на выделенном соединении под общим advisory-lock с боевым
 *  циклом (иначе длинные транзакции конфликтуют на `prices` и запрос зависает). */
app.post('/api/logics/lightning-all', async (req, res) => {
  try {
    const idsQ = await pool.query(`
      SELECT l.id
      FROM logics l
      JOIN accounts a ON a.id = l.account_id
      WHERE COALESCE(l.use_as_terminal_signal, FALSE) = TRUE
        AND a.is_active = TRUE
      ORDER BY l.id
    `);
    const ids = idsQ.rows.map((r) => r.id);
    if (ids.length === 0) {
      res.json({
        ok: true, started: false, ran: 0, sent: 0,
        signals_created: 0, trades_created: 0,
        failed: [], skipped: [],
      });
      return;
    }

    const srcQ = await pool.query(
      `SELECT id, sec FROM timeframes WHERE sec >= 60 AND sec <= 300 ORDER BY sec LIMIT 1`
    );
    const srcId = srcQ.rows[0]?.id;
    if (!srcId) {
      res.status(400).json({ ok: false, reason: 'no_minute_source' });
      return;
    }
    const secsQ = await pool.query(
      `SELECT DISTINCT s.security_id AS id
         FROM logic_securities s
        WHERE s.is_active = TRUE
          AND s.logic_id = ANY($1::int[])
        ORDER BY id`,
      [ids]
    );
    const secIds = secsQ.rows.map((r) => r.id);
    const today = new Date().toISOString().slice(0, 10);

    // #991: запускаем фоновую работу и отдаём id задания. Клиент опрашивает
    // /lightning-all/status, чтобы показать итог и причины (почему 0 сигналов).
    lightningAllJob = {
      id: `lightning-${Date.now()}`,
      startedAt: Date.now(),
      finishedAt: null,
      locked: null,
      ids,
      signals: 0,
      trades: 0,
      results: [],
    };
    res.json({
      ok: true, started: true, ran: ids.length, sent: 0,
      job_id: lightningAllJob.id,
      signals_created: 0, trades_created: 0,
      failed: [], skipped: [],
    });
    runLightningAllBackground({ ids, secIds, srcId, today }).catch((err) => {
      console.error('POST /api/logics/lightning-all (bg)', err);
      if (lightningAllJob) lightningAllJob.finishedAt = Date.now();
    });
  } catch (err) {
    console.error('POST /api/logics/lightning-all', err);
    res.status(500).json({ error: err.message });
  }
});

/** #991: статус последней «молнии для всех» — результат по каждой логике и диагностика
 *  (почему сигналов не создано). Клиент опрашивает после POST /api/logics/lightning-all. */
app.get('/api/logics/lightning-all/status', async (req, res) => {
  if (!lightningAllJob) {
    res.json({ ok: true, started: false, running: false, ran: 0, results: [] });
    return;
  }
  const j = lightningAllJob;
  res.json({
    ok: true,
    started: true,
    running: !j.finishedAt,
    finished: !!j.finishedAt,
    job_id: j.id,
    locked: j.locked,
    ran: j.ids.length,
    signals_created: j.signals,
    trades_created: j.trades,
    started_at: j.startedAt,
    finished_at: j.finishedAt,
    results: j.results,
  });
});

/** #990: финализация отложенных подтверждений (logic_signal_confirm_pending).
 *  Open-сигналы с signal_confirm_sec выдаются не сразу: молния кладёт их в очередь,
 *  а сигнал/сделка создаётся после проверки цены. Кнопка «Запросить сигналы» вызывает
 *  этот эндпоинт по истечении окна, чтобы довести сигналы. Живую цену финализатор
 *  добирает сам (#985). Финализация глобальная (все созревшие строки), id — для вида. */
app.post('/api/logics/:id/confirm-finalize', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  try {
    const { rows } = await pool.query(
      `SELECT logic_signal_confirm_finalize()::int AS created`
    );
    res.json({ ok: true, logic_id: id, created: Number(rows[0]?.created ?? 0) });
  } catch (err) {
    console.error('POST /api/logics/:id/confirm-finalize', err);
    res.status(500).json({ error: err.message });
  }
});

/** Сброс OPT: начальные базы формул + очистка live opt_lane книги. */
app.post('/api/logics/:id/opt-reset', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  try {
    const { rows: exists } = await pool.query(
      'SELECT id FROM logics WHERE id = $1',
      [id]
    );
    if (exists.length === 0) {
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    const { rows } = await pool.query(
      `SELECT logic_opt_reset_to_initial($1) AS r`,
      [id]
    );
    const result = rows[0]?.r ?? {};
    if (result && result.ok === false) {
      res.status(400).json({ error: result.error || 'opt reset failed', ...result });
      return;
    }
    const { rows: signals } = await pool.query(
      `
      SELECT
        lis.id,
        lis.logic_id,
        lis.indicator_id,
        lis.position_event,
        lis.position_side,
        lis.signal_kind,
        lis.formula,
        lis.rating,
        lis.rating_test,
        lis.display_order,
        lis.is_active,
        i.code AS indicator_code,
        i.name AS indicator_name
      FROM logic_indicator_signals lis
      JOIN indicators i ON i.id = lis.indicator_id
      WHERE lis.logic_id = $1
      ORDER BY lis.display_order, lis.id
      `,
      [id]
    );
    res.json({ ...result, signals });
  } catch (err) {
    console.error('POST /api/logics/:id/opt-reset', err);
    res.status(500).json({ error: err.message });
  }
});

app.patch('/api/logics/:id/trading-params', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }

  const parsed = parseLogicTradingParams(req.body);
  if (parsed.error) {
    res.status(400).json({ error: parsed.error });
    return;
  }

  try {
    const { rows: exists } = await pool.query(
      'SELECT id FROM logics WHERE id = $1',
      [id]
    );
    if (exists.length === 0) {
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    const trading = await saveTradingParams(pool, id, parsed);
    res.json({ id, ...trading });
  } catch (err) {
    console.error('PATCH /api/logics/:id/trading-params', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/logic-indicator-signals', async (req, res) => {
  const logicId = Number(req.query.logic_id);
  if (!Number.isInteger(logicId) || logicId <= 0) {
    res.status(400).json({ error: 'logic_id required' });
    return;
  }
  try {
    const { rows } = await pool.query(
      `
      SELECT
        lis.id,
        lis.logic_id,
        lis.indicator_id,
        lis.position_event,
        lis.position_side,
        lis.signal_kind,
        COALESCE(lis.signal_acts_on, 'security') AS signal_acts_on,
        lis.signal_confirm_sec,
        lis.formula,
        lis.rating,
        lis.rating_test,
        lis.display_order,
        lis.is_active,
        i.code AS indicator_code,
        i.name AS indicator_name
      FROM logic_indicator_signals lis
      JOIN indicators i ON i.id = lis.indicator_id
      WHERE lis.logic_id = $1
      ORDER BY lis.display_order, lis.id
    `,
      [logicId]
    );
    res.json(rows);
  } catch (err) {
    console.error('GET /api/logic-indicator-signals', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/logic-signal-ratings/history', async (req, res) => {
  const logicId = Number(req.query.logic_id);
  const isTest = req.query.is_test === '1' || req.query.is_test === 'true';
  const runId = req.query.run_id != null && req.query.run_id !== ''
    ? Number(req.query.run_id)
    : null;
  const signalId = req.query.signal_id != null && req.query.signal_id !== ''
    ? Number(req.query.signal_id)
    : null;
  const securityId = req.query.security_id != null && req.query.security_id !== ''
    ? Number(req.query.security_id)
    : null;
  if (!Number.isInteger(logicId) || logicId <= 0) {
    res.status(400).json({ error: 'logic_id required' });
    return;
  }
  try {
    const { rows: signals } = await pool.query(
      `
      SELECT
        lis.id AS signal_id,
        lis.logic_id,
        lis.position_event,
        lis.position_side,
        lis.signal_kind,
        lis.formula,
        lis.rating,
        lis.rating_test,
        lis.is_active,
        i.code AS indicator_code,
        i.name AS indicator_name
      FROM logic_indicator_signals lis
      JOIN indicators i ON i.id = lis.indicator_id
      WHERE lis.logic_id = $1
        AND ($2::int IS NULL OR lis.id = $2)
      ORDER BY lis.display_order, lis.id
      `,
      [logicId, signalId]
    );

    const histParams = [logicId, isTest];
    let histSql = `
      SELECT h.signal_id, h.bar_dt, h.rating, h.delta, h.security_id, h.run_id
      FROM logic_signal_rating_history h
      WHERE h.logic_id = $1 AND h.is_test = $2
    `;
    if (runId != null && Number.isInteger(runId)) {
      histParams.push(runId);
      histSql += ` AND h.run_id = $${histParams.length}`;
    }
    if (signalId != null && Number.isInteger(signalId)) {
      histParams.push(signalId);
      histSql += ` AND h.signal_id = $${histParams.length}`;
    }
    if (securityId != null && Number.isInteger(securityId)) {
      histParams.push(securityId);
      histSql += ` AND h.security_id = $${histParams.length}`;
    }
    histSql += ' ORDER BY h.signal_id, h.bar_dt, h.id';

    const { rows: hist } = await pool.query(histSql, histParams);
    const bySignal = new Map();
    for (const s of signals) {
      bySignal.set(s.signal_id, {
        ...s,
        // При фильтре по бумаге rating_test в ответе = рейтинг на этой бумаге
        paper_rating: 0,
        points: [],
      });
    }
    for (const h of hist) {
      const row = bySignal.get(h.signal_id);
      if (!row) continue;
      const dt = h.bar_dt;
      const value = Number(h.rating);
      const point = {
        dt,
        value,
        delta: Number(h.delta),
      };
      const pts = row.points;
      const last = pts[pts.length - 1];
      if (last && String(last.dt) === String(dt)) {
        pts[pts.length - 1] = point;
      } else {
        pts.push(point);
      }
      row.paper_rating = value;
    }
    if (securityId != null && Number.isInteger(securityId)) {
      for (const row of bySignal.values()) {
        row.rating_test = row.paper_rating;
      }
    }
    res.json({
      logic_id: logicId,
      is_test: isTest,
      run_id: runId,
      security_id: securityId,
      signals: [...bySignal.values()],
    });
  } catch (err) {
    console.error('GET /api/logic-signal-ratings/history', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/logic-indicator-signals', async (req, res) => {
  const logicId = Number(req.body?.logic_id);
  const indicatorId = Number(req.body?.indicator_id);
  const positionEvent = req.body?.position_event;
  const positionSide = req.body?.position_side;
  const signalKind = req.body?.signal_kind;
  const signalActsOn =
    req.body?.signal_acts_on === 'base_asset'
      ? 'base_asset'
      : req.body?.signal_acts_on === 'contango'
        ? 'contango'
        : 'security';
  const formula = btrimStr(req.body?.formula);
  if (!Number.isInteger(logicId) || logicId <= 0) {
    res.status(400).json({ error: 'logic_id required' });
    return;
  }
  if (!Number.isInteger(indicatorId) || indicatorId <= 0) {
    res.status(400).json({ error: 'indicator_id required' });
    return;
  }
  if (positionEvent !== 'open' && positionEvent !== 'close') {
    res.status(400).json({ error: 'position_event must be open or close' });
    return;
  }
  if (positionSide !== 'long' && positionSide !== 'short') {
    res.status(400).json({ error: 'position_side must be long or short' });
    return;
  }
  if (signalKind !== 'trend' && signalKind !== 'counter') {
    res.status(400).json({ error: 'signal_kind must be trend or counter' });
    return;
  }
  if (!formula) {
    res.status(400).json({ error: 'formula required' });
    return;
  }
  try {
    const optCheck = await validateOptFormulaSave(pool, logicId, formula, null);
    if (!optCheck.ok) {
      res.status(400).json({
        error: optCheck.error,
        opt_existing: optCheck.existing || [],
      });
      return;
    }
    const { rows: orderRows } = await pool.query(
      `SELECT COALESCE(MAX(display_order), 0) + 1 AS next_order
       FROM logic_indicator_signals WHERE logic_id = $1`,
      [logicId]
    );
    const displayOrder = orderRows[0]?.next_order ?? 1;
    const { rows } = await pool.query(
      `
      INSERT INTO logic_indicator_signals
        (logic_id, indicator_id, position_event, position_side, signal_kind, signal_acts_on, formula, display_order)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id, logic_id, indicator_id, position_event, position_side, signal_kind, signal_acts_on, signal_confirm_sec, formula, rating, rating_test, display_order, is_active
    `,
      [logicId, indicatorId, positionEvent, positionSide, signalKind, signalActsOn, formula, displayOrder]
    );
    const row = rows[0];
    const { rows: meta } = await pool.query(
      `SELECT code AS indicator_code, name AS indicator_name FROM indicators WHERE id = $1`,
      [indicatorId]
    );
    res.status(201).json({ ...row, ...meta[0] });
  } catch (err) {
    console.error('POST /api/logic-indicator-signals', err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/logic-indicator-signals/:id', async (req, res) => {
  const id = Number(req.params.id);
  const formula = btrimStr(req.body?.formula);
  const isActive = req.body?.is_active;
  const hasActsOn = Object.prototype.hasOwnProperty.call(req.body || {}, 'signal_acts_on');
  const signalActsOn = hasActsOn
    ? req.body?.signal_acts_on === 'base_asset'
      ? 'base_asset'
      : req.body?.signal_acts_on === 'contango'
        ? 'contango'
        : 'security'
    : null;
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid id' });
    return;
  }
  if (!formula) {
    res.status(400).json({ error: 'formula required' });
    return;
  }
  // #972: подтверждение типа сигнала (0 = не подтверждать).
  const hasConfirm = Object.prototype.hasOwnProperty.call(req.body || {}, 'signal_confirm_sec');
  const signalConfirmSec = hasConfirm ? Number(req.body?.signal_confirm_sec) : null;
  if (signalConfirmSec !== null && (!Number.isInteger(signalConfirmSec) || signalConfirmSec < 0 || signalConfirmSec > 86400)) {
    res.status(400).json({ error: 'signal_confirm_sec must be an integer 0..86400' });
    return;
  }
  // #1012: редактирование сигнала — смена индикатора, действия, стороны, типа.
  const hasIndicator = Object.prototype.hasOwnProperty.call(req.body || {}, 'indicator_id');
  const indicatorId = hasIndicator ? Number(req.body?.indicator_id) : null;
  if (hasIndicator && (!Number.isInteger(indicatorId) || indicatorId <= 0)) {
    res.status(400).json({ error: 'indicator_id must be a positive integer' });
    return;
  }
  const hasEvent = Object.prototype.hasOwnProperty.call(req.body || {}, 'position_event');
  const positionEvent = hasEvent ? String(req.body?.position_event) : null;
  if (hasEvent && positionEvent !== 'open' && positionEvent !== 'close') {
    res.status(400).json({ error: 'position_event must be open or close' });
    return;
  }
  const hasSide = Object.prototype.hasOwnProperty.call(req.body || {}, 'position_side');
  const positionSide = hasSide ? String(req.body?.position_side) : null;
  if (hasSide && positionSide !== 'long' && positionSide !== 'short') {
    res.status(400).json({ error: 'position_side must be long or short' });
    return;
  }
  const hasKind = Object.prototype.hasOwnProperty.call(req.body || {}, 'signal_kind');
  const signalKind = hasKind ? String(req.body?.signal_kind) : null;
  if (hasKind && signalKind !== 'trend' && signalKind !== 'counter') {
    res.status(400).json({ error: 'signal_kind must be trend or counter' });
    return;
  }
  try {
    const { rows: curRows } = await pool.query(
      `SELECT logic_id FROM logic_indicator_signals WHERE id = $1`,
      [id]
    );
    if (curRows.length === 0) {
      res.status(404).json({ error: 'Signal not found' });
      return;
    }
    const optCheck = await validateOptFormulaSave(
      pool,
      curRows[0].logic_id,
      formula,
      id
    );
    if (!optCheck.ok) {
      res.status(400).json({
        error: optCheck.error,
        opt_existing: optCheck.existing || [],
      });
      return;
    }
    const { rows } = await pool.query(
      `
      UPDATE logic_indicator_signals
      SET formula = $2,
          is_active = COALESCE($3::boolean, is_active),
          signal_acts_on = COALESCE($4::varchar, signal_acts_on),
          signal_confirm_sec = COALESCE($5::int, signal_confirm_sec),
          indicator_id = COALESCE($6::int, indicator_id),
          position_event = COALESCE($7::varchar, position_event),
          position_side = COALESCE($8::varchar, position_side),
          signal_kind = COALESCE($9::varchar, signal_kind)
      WHERE id = $1
      RETURNING id, logic_id, indicator_id, position_event, position_side, signal_kind, signal_acts_on, signal_confirm_sec, formula, rating, rating_test, display_order, is_active
    `,
      [id, formula, isActive === undefined ? null : isActive, signalActsOn, signalConfirmSec, indicatorId, positionEvent, positionSide, signalKind]
    );
    const row = rows[0];
    const { rows: meta } = await pool.query(
      `SELECT code AS indicator_code, name AS indicator_name FROM indicators WHERE id = $1`,
      [row.indicator_id]
    );
    res.json({ ...row, ...meta[0] });
  } catch (err) {
    console.error('PUT /api/logic-indicator-signals/:id', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/logic-indicator-signals/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid id' });
    return;
  }
  try {
    const { rowCount } = await pool.query(
      'DELETE FROM logic_indicator_signals WHERE id = $1',
      [id]
    );
    if (rowCount === 0) {
      res.status(404).json({ error: 'Signal not found' });
      return;
    }
    res.json({ ok: true, id });
  } catch (err) {
    console.error('DELETE /api/logic-indicator-signals/:id', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/logic-stops', async (req, res) => {
  const logicId = Number(req.query.logic_id);
  if (!Number.isInteger(logicId) || logicId <= 0) {
    res.status(400).json({ error: 'logic_id required' });
    return;
  }
  try {
    const { rows } = await pool.query(
      `
      SELECT
        id, logic_id, rule_kind, scope_type,
        value::float8 AS value,
        inversion_value::float8 AS inversion_value,
        value_unit,
        display_order, is_active, created_at
      FROM logic_stops
      WHERE logic_id = $1
      ORDER BY rule_kind, display_order, id
      `,
      [logicId]
    );
    res.json(rows);
  } catch (err) {
    console.error('GET /api/logic-stops', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/logic-stops', async (req, res) => {
  const logicId = Number(req.body?.logic_id);
  const ruleKind = btrimStr(req.body?.rule_kind);
  const scopeType = btrimStr(req.body?.scope_type);
  const valueUnit = btrimStr(req.body?.value_unit);
  const value = Number(req.body?.value);
  if (!Number.isInteger(logicId) || logicId <= 0) {
    res.status(400).json({ error: 'logic_id required' });
    return;
  }
  if (ruleKind !== 'stop_loss' && ruleKind !== 'take_profit') {
    res.status(400).json({ error: 'rule_kind must be stop_loss or take_profit' });
    return;
  }
  if (!isScopeValidForRuleKind(ruleKind, scopeType)) {
    res.status(400).json({
      error:
        ruleKind === 'take_profit'
          ? 'scope_type for take_profit must be security or portfolio_ltp_renew'
          : 'scope_type must be security, security_resume, security_inversion, portfolio or portfolio_resume',
    });
    return;
  }
  if (!isScopeChoosableForRuleKind(ruleKind, scopeType)) {
    res.status(400).json({
      error:
        ruleKind === 'take_profit'
          ? 'take_profit by portfolio is not choosable (only security)'
          : 'this stop-loss scope is not choosable (portfolio_resume)',
    });
    return;
  }
  if (valueUnit !== 'percent' && valueUnit !== 'atr') {
    res.status(400).json({ error: 'value_unit must be percent or atr' });
    return;
  }
  if (!Number.isFinite(value) || value <= 0) {
    res.status(400).json({ error: 'value must be a positive number' });
    return;
  }
  try {
    const { rows: orderRows } = await pool.query(
      `SELECT COALESCE(MAX(display_order), 0) + 1 AS next_order
       FROM logic_stops WHERE logic_id = $1 AND rule_kind = $2`,
      [logicId, ruleKind]
    );
    const displayOrder = orderRows[0]?.next_order ?? 1;
    const { rows } = await pool.query(
      `
      INSERT INTO logic_stops
        (logic_id, rule_kind, scope_type, value, inversion_value, value_unit, display_order)
      VALUES ($1, $2, $3, $4, NULL, $5, $6)
      RETURNING id, logic_id, rule_kind, scope_type,
        value::float8 AS value,
        inversion_value::float8 AS inversion_value,
        value_unit, display_order, is_active, created_at
      `,
      [logicId, ruleKind, scopeType, value, valueUnit, displayOrder]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error('POST /api/logic-stops', err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/logic-stops/:id', async (req, res) => {
  const id = Number(req.params.id);
  const scopeType = req.body?.scope_type != null ? btrimStr(req.body.scope_type) : null;
  const valueUnit = req.body?.value_unit != null ? btrimStr(req.body.value_unit) : null;
  const value = req.body?.value != null ? Number(req.body.value) : null;
  const isActive = req.body?.is_active;
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid id' });
    return;
  }
  if (valueUnit && valueUnit !== 'percent' && valueUnit !== 'atr') {
    res.status(400).json({ error: 'value_unit must be percent or atr' });
    return;
  }
  if (value != null && (!Number.isFinite(value) || value <= 0)) {
    res.status(400).json({ error: 'value must be a positive number' });
    return;
  }
  try {
    const { rows: existingRows } = await pool.query(
      'SELECT rule_kind, scope_type FROM logic_stops WHERE id = $1',
      [id]
    );
    if (existingRows.length === 0) {
      res.status(404).json({ error: 'Stop rule not found' });
      return;
    }
    const ruleKind = existingRows[0].rule_kind;
    if (scopeType) {
      if (!isScopeValidForRuleKind(ruleKind, scopeType)) {
        res.status(400).json({
          error:
            ruleKind === 'take_profit'
              ? 'scope_type for take_profit must be security, portfolio or portfolio_ltp_renew'
              : 'scope_type must be security, security_resume, security_inversion, portfolio or portfolio_resume',
        });
        return;
      }
      if (!isScopeChoosableForRuleKind(ruleKind, scopeType)) {
        res.status(400).json({
          error:
            ruleKind === 'take_profit'
              ? 'take_profit by portfolio is not choosable (only security)'
              : 'this stop-loss scope is not choosable (portfolio_resume)',
        });
        return;
      }
      // #1044: защита от случайного сброса TP «по бумаге» на портфельный —
      // смена на portfolio_ltp_renew требует явного подтверждения.
      if (
        ruleKind === 'take_profit' &&
        scopeType === 'portfolio_ltp_renew' &&
        existingRows[0].scope_type !== 'portfolio_ltp_renew' &&
        req.body?.confirm_scope_change !== true
      ) {
        res.status(400).json({
          error:
            'Смена типа TP на портфельный требует подтверждения (confirm_scope_change)',
        });
        return;
      }
    }

    const updateSql = `
      UPDATE logic_stops
      SET scope_type = COALESCE($2, scope_type),
          value = COALESCE($3, value),
          value_unit = COALESCE($4, value_unit),
          is_active = COALESCE($5::boolean, is_active),
          inversion_value = NULL
      WHERE id = $1
      RETURNING id, logic_id, rule_kind, scope_type,
        value::float8 AS value,
        inversion_value::float8 AS inversion_value,
        value_unit, display_order, is_active, created_at
      `;
    const updateParams = [
      id,
      scopeType || null,
      value != null ? value : null,
      valueUnit || null,
      isActive === undefined ? null : isActive,
    ];
    // #1046: смена TP на портфельный разрешена только с подтверждением —
    // выставляем сессионный флаг для guard-триггера в той же транзакции.
    let rows;
    if (req.body?.confirm_scope_change === true && scopeType === 'portfolio_ltp_renew') {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        await client.query(`SET LOCAL app.allow_tp_scope_change = '1'`);
        ({ rows } = await client.query(updateSql, updateParams));
        await client.query('COMMIT');
      } catch (errUpdate) {
        await client.query('ROLLBACK').catch(() => {});
        throw errUpdate;
      } finally {
        client.release();
      }
    } else {
      ({ rows } = await pool.query(updateSql, updateParams));
    }
    if (rows.length === 0) {
      res.status(404).json({ error: 'Stop rule not found' });
      return;
    }
    res.json(rows[0]);
  } catch (err) {
    console.error('PUT /api/logic-stops/:id', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/logic-stops/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid id' });
    return;
  }
  try {
    const { rowCount } = await pool.query('DELETE FROM logic_stops WHERE id = $1', [id]);
    if (rowCount === 0) {
      res.status(404).json({ error: 'Stop rule not found' });
      return;
    }
    res.json({ ok: true, id });
  } catch (err) {
    console.error('DELETE /api/logic-stops/:id', err);
    res.status(500).json({ error: err.message });
  }
});

const LOGIC_SECURITY_SELECT = `
  SELECT
    ls.id,
    ls.logic_id,
    ls.security_id,
    ls.display_order,
    ls.is_active,
    ls.created_at,
    ls.real_trading_paused,
    ls.real_trading_paused_long,
    ls.real_trading_paused_short,
    ls.real_trading_inverted,
    ls.stop_resume_equity::float8 AS stop_resume_equity,
    ls.stop_resume_baseline::float8 AS stop_resume_baseline,
    ls.stop_resume_triggered_at,
    ls.stop_resume_equity_long::float8 AS stop_resume_equity_long,
    ls.stop_resume_baseline_long::float8 AS stop_resume_baseline_long,
    ls.stop_resume_triggered_at_long,
    ls.stop_resume_equity_short::float8 AS stop_resume_equity_short,
    ls.stop_resume_baseline_short::float8 AS stop_resume_baseline_short,
    ls.stop_resume_triggered_at_short,
    s.name AS security_name,
    s.lot_size,
    st.name AS security_type,
    sp.prefix,
    sp.instrument_market,
    sp.underlying_security_id,
    und.name AS underlying_security_name,
    und_sp.prefix AS underlying_prefix,
    sp.exchange_id,
    e.name AS exchange_name
  FROM logic_securities ls
  JOIN securities s ON s.id = ls.security_id
  JOIN security_types st ON st.id = s.security_type_id
  LEFT JOIN LATERAL (
    SELECT prefix, instrument_market, exchange_id, underlying_security_id
    FROM security_prefixes
    WHERE security_id = s.id
    ORDER BY exchange_id
    LIMIT 1
  ) sp ON TRUE
  LEFT JOIN securities und ON und.id = sp.underlying_security_id
  LEFT JOIN LATERAL (
    SELECT prefix
    FROM security_prefixes
    WHERE security_id = und.id
    ORDER BY exchange_id
    LIMIT 1
  ) und_sp ON TRUE
  LEFT JOIN exchanges e ON e.id = sp.exchange_id
`;

app.get('/api/logic-securities', async (req, res) => {
  const logicId = Number(req.query.logic_id);
  if (!Number.isInteger(logicId) || logicId <= 0) {
    res.status(400).json({ error: 'logic_id required' });
    return;
  }
  try {
    const { rows } = await pool.query(
      `${LOGIC_SECURITY_SELECT}
       WHERE ls.logic_id = $1
       ORDER BY ls.display_order, ls.id`,
      [logicId]
    );
    res.json(rows);
  } catch (err) {
    console.error('GET /api/logic-securities', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/logic-securities/bulk', async (req, res) => {
  const logicId = Number(req.body?.logic_id);
  const rawIds = req.body?.security_ids;
  if (!Number.isInteger(logicId) || logicId <= 0) {
    res.status(400).json({ error: 'logic_id required' });
    return;
  }
  if (!Array.isArray(rawIds) || rawIds.length === 0) {
    res.status(400).json({ error: 'security_ids array required' });
    return;
  }
  const securityIds = [
    ...new Set(
      rawIds
        .map((x) => Number(x))
        .filter((id) => Number.isInteger(id) && id > 0)
    ),
  ];
  if (securityIds.length === 0) {
    res.status(400).json({ error: 'No valid security_ids' });
    return;
  }
  try {
    const { rows: logicRows } = await pool.query(
      'SELECT id FROM logics WHERE id = $1',
      [logicId]
    );
    if (logicRows.length === 0) {
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    const { rows: inserted } = await pool.query(
      `
      INSERT INTO logic_securities (logic_id, security_id, display_order)
      SELECT
        $1,
        sid,
        COALESCE(
          (SELECT MAX(display_order) FROM logic_securities WHERE logic_id = $1),
          0
        ) + row_number() OVER ()
      FROM unnest($2::int[]) AS sid
      ON CONFLICT (logic_id, security_id) DO UPDATE SET is_active = TRUE
      RETURNING id
      `,
      [logicId, securityIds]
    );
    const ids = inserted.map((r) => r.id);
    if (ids.length === 0) {
      res.json([]);
      return;
    }
    const { rows } = await pool.query(
      `${LOGIC_SECURITY_SELECT} WHERE ls.id = ANY($1::int[]) ORDER BY ls.display_order, ls.id`,
      [ids]
    );
    res.status(201).json(rows);
  } catch (err) {
    console.error('POST /api/logic-securities/bulk', err);
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/logic-securities/:id', async (req, res) => {
  const id = Number(req.params.id);
  const isActive = req.body?.is_active;
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid id' });
    return;
  }
  if (typeof isActive !== 'boolean') {
    res.status(400).json({ error: 'is_active boolean required' });
    return;
  }
  try {
    const { rows } = await pool.query(
      `UPDATE logic_securities SET is_active = $2 WHERE id = $1 RETURNING id`,
      [id, isActive]
    );
    if (rows.length === 0) {
      res.status(404).json({ error: 'Logic security not found' });
      return;
    }
    const { rows: full } = await pool.query(
      `${LOGIC_SECURITY_SELECT} WHERE ls.id = $1`,
      [id]
    );
    res.json(full[0]);
  } catch (err) {
    console.error('PUT /api/logic-securities/:id', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/logic-securities/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid id' });
    return;
  }
  try {
    const { rowCount } = await pool.query(
      'DELETE FROM logic_securities WHERE id = $1',
      [id]
    );
    if (rowCount === 0) {
      res.status(404).json({ error: 'Logic security not found' });
      return;
    }
    res.json({ ok: true, id });
  } catch (err) {
    console.error('DELETE /api/logic-securities/:id', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/logics/:id/non-trading-periods', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  try {
    await pool.query('SELECT logic_ensure_non_trading_periods($1)', [id]);
    const { rows } = await pool.query(
      `
      SELECT
        id,
        logic_id,
        day_of_week,
        to_char(time_from, 'HH24:MI') AS time_from,
        to_char(time_to, 'HH24:MI') AS time_to,
        note,
        display_order,
        is_active
      FROM logic_non_trading_intervals
      WHERE logic_id = $1
      ORDER BY day_of_week, time_from, id
      `,
      [id]
    );
    const trading = await getTradingParams(pool, id);
    res.json({
      logic_id: id,
      non_trading_periods_mode: trading.non_trading_periods_mode,
      use_non_trading_periods: trading.use_non_trading_periods !== false,
      intervals: rows,
    });
  } catch (err) {
    console.error('GET /api/logics/:id/non-trading-periods', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/logics/:id/non-trading-periods/moex-defaults', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  try {
    const { rows: exists } = await pool.query('SELECT id FROM logics WHERE id = $1', [id]);
    if (exists.length === 0) {
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    const { rows } = await pool.query(
      'SELECT logic_apply_moex_non_trading_periods($1::INTEGER) AS n',
      [id]
    );
    const { rows: intervals } = await pool.query(
      `
      SELECT
        id,
        logic_id,
        day_of_week,
        to_char(time_from, 'HH24:MI') AS time_from,
        to_char(time_to, 'HH24:MI') AS time_to,
        note,
        display_order,
        is_active
      FROM logic_non_trading_intervals
      WHERE logic_id = $1
      ORDER BY day_of_week, time_from, id
      `,
      [id]
    );
    const trading = await getTradingParams(pool, id);
    await writeTechLogEvent(pool, {
      threadKey: `logic:${id}:sessions`,
      operation: 'logic.non_trading.moex_defaults',
      message: 'Неторговые периоды установлены как на MOEX',
      source: 'api',
      logicId: id,
      payload: { count: rows[0]?.n ?? intervals.length },
    });
    res.json({
      logic_id: id,
      applied: Number(rows[0]?.n ?? 0),
      non_trading_periods_mode: trading.non_trading_periods_mode,
      use_non_trading_periods: trading.use_non_trading_periods !== false,
      intervals,
    });
  } catch (err) {
    console.error('POST /api/logics/:id/non-trading-periods/moex-defaults', err);
    res.status(500).json({ error: err.message });
  }
});


app.post('/api/logics/:id/non-trading-periods', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid logic id' });
    return;
  }
  const day = Math.round(Number(req.body?.day_of_week));
  const timeFrom = parseTimeHm(req.body?.time_from);
  const timeTo = parseTimeHm(req.body?.time_to);
  const note =
    req.body?.note == null || req.body?.note === ''
      ? null
      : String(req.body.note).trim().slice(0, 200);
  if (!Number.isInteger(day) || day < 1 || day > 7) {
    res.status(400).json({ error: 'day_of_week: целое 1…7 (Пн…Вс)' });
    return;
  }
  if (!timeFrom || !timeTo) {
    res.status(400).json({ error: 'time_from / time_to: формат ЧЧ:ММ' });
    return;
  }
  if (timeFrom > timeTo) {
    res.status(400).json({ error: 'time_from не позже time_to' });
    return;
  }
  try {
    const { rows: exists } = await pool.query('SELECT id FROM logics WHERE id = $1', [id]);
    if (exists.length === 0) {
      res.status(404).json({ error: 'Logic not found' });
      return;
    }
    const { rows: ord } = await pool.query(
      `
      SELECT COALESCE(MAX(display_order), 0) + 1 AS n
      FROM logic_non_trading_intervals
      WHERE logic_id = $1
      `,
      [id]
    );
    await pool.query(
      `
      INSERT INTO logic_non_trading_intervals (
        logic_id, day_of_week, time_from, time_to, note, display_order, is_active
      )
      VALUES ($1, $2, $3::time, $4::time, $5, $6, TRUE)
      `,
      [id, day, timeFrom, timeTo, note, Number(ord[0]?.n ?? 1)]
    );
    const trading = await getTradingParams(pool, id);
    res.status(201).json({
      logic_id: id,
      non_trading_periods_mode: trading.non_trading_periods_mode,
      use_non_trading_periods: trading.use_non_trading_periods !== false,
      intervals: await fetchNonTradingIntervals(pool, id),
    });
  } catch (err) {
    console.error('POST /api/logics/:id/non-trading-periods', err);
    res.status(500).json({ error: err.message });
  }
});

app.patch('/api/logic-non-trading-intervals/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid interval id' });
    return;
  }
  const patches = [];
  const vals = [];
  let n = 1;
  if (req.body?.day_of_week !== undefined) {
    const day = Math.round(Number(req.body.day_of_week));
    if (!Number.isInteger(day) || day < 1 || day > 7) {
      res.status(400).json({ error: 'day_of_week: целое 1…7' });
      return;
    }
    patches.push(`day_of_week = $${n++}`);
    vals.push(day);
  }
  if (req.body?.time_from !== undefined) {
    const t = parseTimeHm(req.body.time_from);
    if (!t) {
      res.status(400).json({ error: 'time_from: ЧЧ:ММ' });
      return;
    }
    patches.push(`time_from = $${n++}::time`);
    vals.push(t);
  }
  if (req.body?.time_to !== undefined) {
    const t = parseTimeHm(req.body.time_to);
    if (!t) {
      res.status(400).json({ error: 'time_to: ЧЧ:ММ' });
      return;
    }
    patches.push(`time_to = $${n++}::time`);
    vals.push(t);
  }
  if (req.body?.note !== undefined) {
    const note =
      req.body.note == null || req.body.note === ''
        ? null
        : String(req.body.note).trim().slice(0, 200);
    patches.push(`note = $${n++}`);
    vals.push(note);
  }
  if (req.body?.is_active !== undefined) {
    patches.push(`is_active = $${n++}`);
    vals.push(Boolean(req.body.is_active));
  }
  if (patches.length === 0) {
    res.status(400).json({ error: 'Нечего обновлять' });
    return;
  }
  vals.push(id);
  try {
    const { rows } = await pool.query(
      `
      UPDATE logic_non_trading_intervals
      SET ${patches.join(', ')}
      WHERE id = $${n}
      RETURNING logic_id
      `,
      vals
    );
    if (rows.length === 0) {
      res.status(404).json({ error: 'Interval not found' });
      return;
    }
    const logicId = rows[0].logic_id;
    const trading = await getTradingParams(pool, logicId);
    res.json({
      logic_id: logicId,
      non_trading_periods_mode: trading.non_trading_periods_mode,
      use_non_trading_periods: trading.use_non_trading_periods !== false,
      intervals: await fetchNonTradingIntervals(pool, logicId),
    });
  } catch (err) {
    console.error('PATCH /api/logic-non-trading-intervals/:id', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/logic-non-trading-intervals/:id', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ error: 'Invalid interval id' });
    return;
  }
  try {
    const { rows } = await pool.query(
      `
      DELETE FROM logic_non_trading_intervals
      WHERE id = $1
      RETURNING logic_id
      `,
      [id]
    );
    if (rows.length === 0) {
      res.status(404).json({ error: 'Interval not found' });
      return;
    }
    const logicId = rows[0].logic_id;
    const trading = await getTradingParams(pool, logicId);
    res.json({
      ok: true,
      logic_id: logicId,
      non_trading_periods_mode: trading.non_trading_periods_mode,
      use_non_trading_periods: trading.use_non_trading_periods !== false,
      intervals: await fetchNonTradingIntervals(pool, logicId),
    });
  } catch (err) {
    console.error('DELETE /api/logic-non-trading-intervals/:id', err);
    res.status(500).json({ error: err.message });
  }
});
};
